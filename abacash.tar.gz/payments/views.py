"""
payments/views.py
=================
Payment recording and receipt generation for ABA Uganda.
"""

from decimal import Decimal
from datetime import date
import logging
import re

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db import connection, transaction
from django.db.models import Sum
from django.http import Http404, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify

from loans.models import Loan, LoanSchedule
from loans.utils import calculate_penalty, penalty_periods_elapsed
from accounts.models import AuditLog, Branch, CompanySettings
from accounts.audit import log_action
from accounts.branch_scope import scope_to_branch, can_access_branch_object, scope_to_branch_request
from accounts.signatures import selected_signatory
from common.pdf_utils import render_pdf_response
from clients.models import CreditTransaction
from .models import Payment, Receipt, TRANSFER_REF_PREFIX

logger = logging.getLogger("payments")


def _assess_schedule_penalty(entry, loan, payment_date, company_settings):
    days_overdue = max(
        (payment_date - entry.due_date).days - company_settings.grace_period_days,
        0,
    )
    periods_overdue = penalty_periods_elapsed(days_overdue, loan.penalty_frequency)
    if periods_overdue <= entry.penalty_periods_processed:
        return Decimal("0")

    previous_periods = entry.penalty_periods_processed
    entry.penalty_periods_processed = periods_overdue
    if not company_settings.penalties_enabled or not loan.penalty_enabled:
        return Decimal("0")

    amount_paid_toward_installment = max(
        entry.amount_paid - entry.penalty_paid,
        Decimal("0"),
    )
    overdue_balance = max(
        entry.total_payment - amount_paid_toward_installment,
        Decimal("0"),
    )
    newly_accrued = calculate_penalty(
        overdue_balance,
        loan.penalty_rate_monthly,
        days_overdue,
        loan.penalty_frequency,
        periods_already_assessed=previous_periods,
    )
    entry.penalty_due += newly_accrued
    return newly_accrued


def _receipt_document_basename(company_name, client_name, tenant_slug):
    parts = []
    for value in (company_name, client_name, tenant_slug):
        normalized = re.sub(r"[\W_]+", "-", value, flags=re.UNICODE) if value else ""
        slug = slugify(normalized)
        if slug:
            parts.append(slug)
    return "-".join(parts) or "receipt"


def _receipt_document_title(request, client_name):
    company_name = CompanySettings.get().company_name or "Company"
    tenant = getattr(request, "tenant", None)
    tenant_slug = getattr(tenant, "schema_name", "") or getattr(connection, "schema_name", "")
    basename = _receipt_document_basename(company_name, client_name, tenant_slug)
    title = " - ".join(part for part in (company_name, client_name, tenant_slug) if part)
    return title, basename


@login_required
def payment_list(request):
    # Handle modal form POST submitted from the list page
    if request.method == "POST" and request.POST.get("_from_list"):
        return record_payment(request)

    qs = Payment.objects.select_related("loan__client", "recorded_by").order_by("-payment_date")
    qs = scope_to_branch_request(qs, request, "loan__branch")

    search = request.GET.get("q", "").strip()
    if search:
        qs = qs.filter(loan__loan_number__icontains=search) | \
             qs.filter(loan__client__last_name__icontains=search)

    branch_filter = request.GET.get("branch", "").strip()
    if branch_filter:
        qs = qs.filter(loan__branch_id=branch_filter)

    total_amount = qs.aggregate(total=Sum("amount_received"))["total"] or Decimal("0")

    active_loans = scope_to_branch(
        Loan.objects.filter(status="ACTIVE"), request.user
    ).select_related("client").order_by("client__last_name")
    return render(request, "payments/payment_list.html", {
        "payments": qs[:100],
        "total_amount": total_amount,
        "search": search,
        "active_loans": active_loans,
        "today": date.today(),
        "branches": Branch.objects.filter(is_active=True).order_by("name") if request.user.is_ceo else None,
        "selected_branch": request.GET.get("branch", ""),
    })


@login_required
def record_payment(request, loan_pk=None):
    """Record a repayment from a client."""
    loan = None
    if loan_pk:
        loan = get_object_or_404(Loan, pk=loan_pk, status=Loan.Status.ACTIVE)
        if not can_access_branch_object(request.user, loan):
            messages.error(request, "That loan belongs to a different branch.")
            return redirect("payments:list")

    active_loans = scope_to_branch(
        Loan.objects.filter(status="ACTIVE"), request.user
    ).select_related("client").order_by("client__last_name")
    selected_loan = None
    payment_error = None

    if request.method == "POST":
        try:
            loan_id     = request.POST.get("loan_id") or loan_pk

            # Validate loan selection
            if not loan_id:
                raise ValueError("Please select a loan.")

            amount_str  = request.POST.get("amount", "0").strip()
            method      = request.POST.get("payment_method", "CASH")
            reference   = request.POST.get("reference_number", "")
            pay_date_str= request.POST.get("payment_date", str(date.today()))

            # Validate and convert amount
            if not amount_str:
                raise ValueError("Payment amount is required.")

            try:
                amount = Decimal(amount_str)
            except Exception:
                raise ValueError(f"Invalid amount format: '{amount_str}'. Please enter a valid number.")

            if amount < 0:
                raise ValueError("Payment amount cannot be negative.")

            if amount == 0:
                raise ValueError("Payment amount must be greater than zero.")

            try:
                pay_date = date.fromisoformat(pay_date_str)
            except Exception:
                raise ValueError(f"Invalid date format: '{pay_date_str}'.")

            # prepare transfer variables
            transfer_payment = None
            transfer_receipt = None

            with transaction.atomic():
                # Lock the loan row for the life of this transaction. Without
                # this, two payments recorded at the same time on the same
                # loan can both read the same outstanding_balance and pending
                # schedule entries, then both write back their own version —
                # a classic lost-update race that would silently drop money
                # from the ledger.
                selected_loan = get_object_or_404(
                    Loan.objects.select_for_update(), pk=loan_id, status=Loan.Status.ACTIVE
                )
                if not can_access_branch_object(request.user, selected_loan):
                    raise ValueError("That loan belongs to a different branch.")
                # Snapshot balance before payment
                balance_before = selected_loan.outstanding_balance
                client = selected_loan.client
                company_settings = CompanySettings.get()

                # Optional: transfer existing client credit to another loan before applying it to this payment
                transfer_target_id = request.POST.get('transfer_target_loan')
                transfer_amount_str = request.POST.get('transfer_amount', '').strip()
                transfer_payment = None
                transfer_receipt = None
                if transfer_target_id:
                    try:
                        target_loan = get_object_or_404(Loan, pk=transfer_target_id, status=Loan.Status.ACTIVE, client=client)
                        credit_available = client.credit_balance
                        if transfer_amount_str:
                            transfer_amount = Decimal(transfer_amount_str)
                        else:
                            transfer_amount = credit_available
                        transfer_amount = max(Decimal('0'), min(transfer_amount, credit_available))
                        if transfer_amount > 0:
                            # Allocate the transferred credit to the target loan's pending schedule entries
                            remaining_transfer = transfer_amount
                            t_interest_paid = Decimal('0')
                            t_principal_paid = Decimal('0')
                            t_penalty_paid = Decimal('0')

                            target_pending = LoanSchedule.objects.filter(
                                loan=target_loan,
                                status__in=["PENDING", "OVERDUE", "PARTIAL"],
                            ).order_by('period_number')
                            target_pending = list(target_pending)
                            transfer_penalties_assessed = Decimal("0")
                            for t_entry in target_pending:
                                old_periods = t_entry.penalty_periods_processed
                                transfer_penalties_assessed += _assess_schedule_penalty(
                                    t_entry, target_loan, pay_date, company_settings
                                )
                                if t_entry.penalty_periods_processed != old_periods:
                                    t_entry.save(update_fields=[
                                        "penalty_due",
                                        "penalty_periods_processed",
                                    ])

                            for t_entry in target_pending:
                                if remaining_transfer <= 0:
                                    break
                                t_amount_due = t_entry.total_payment + t_entry.penalty_due - t_entry.amount_paid
                                if remaining_transfer >= t_amount_due:
                                    t_interest_paid += t_entry.interest_due
                                    t_principal_paid += t_entry.principal_due
                                    pending_penalty = max(
                                        t_entry.penalty_due - t_entry.penalty_paid,
                                        Decimal("0"),
                                    )
                                    t_penalty_paid += pending_penalty
                                    t_entry.penalty_paid += pending_penalty
                                    remaining_transfer -= t_amount_due
                                    t_entry.amount_paid = t_entry.total_payment + t_entry.penalty_due
                                    t_entry.status = LoanSchedule.Status.PAID
                                    t_entry.paid_date = pay_date
                                else:
                                    allocated = remaining_transfer
                                    pending_penalty = max(
                                        t_entry.penalty_due - t_entry.penalty_paid,
                                        Decimal("0"),
                                    )
                                    if remaining_transfer >= pending_penalty:
                                        t_penalty_paid += pending_penalty
                                        t_entry.penalty_paid += pending_penalty
                                        remaining_transfer -= pending_penalty
                                    else:
                                        t_penalty_paid += remaining_transfer
                                        t_entry.penalty_paid += remaining_transfer
                                        remaining_transfer = Decimal('0')
                                    if remaining_transfer >= t_entry.interest_due:
                                        t_interest_paid += t_entry.interest_due
                                        remaining_transfer -= t_entry.interest_due
                                    else:
                                        t_interest_paid += remaining_transfer
                                        remaining_transfer = Decimal('0')
                                    t_principal_paid += remaining_transfer
                                    remaining_transfer = Decimal('0')
                                    t_entry.amount_paid += allocated
                                    t_entry.status = LoanSchedule.Status.PARTIAL
                                t_entry.save()

                            applied = transfer_amount - remaining_transfer
                            # Update target loan totals
                            target_balance_before = (
                                target_loan.outstanding_balance + transfer_penalties_assessed
                            )
                            target_loan.total_paid += applied
                            target_loan.total_penalties += transfer_penalties_assessed
                            target_loan.outstanding_balance = max(
                                target_balance_before - applied,
                                Decimal("0"),
                            )
                            if target_loan.outstanding_balance == 0:
                                target_loan.status = Loan.Status.COMPLETED
                                target_loan.completion_date = pay_date
                            target_loan.save()

                            if applied > 0:
                                try:
                                    # create transfer payment & receipt for audit
                                    transfer_payment = Payment.objects.create(
                                        loan=target_loan,
                                        client=client,
                                        recorded_by=request.user,
                                        amount_received=applied,
                                        principal_paid=t_principal_paid,
                                        interest_paid=t_interest_paid,
                                        penalty_paid=t_penalty_paid,
                                        overpayment=Decimal('0'),
                                        payment_method=Payment.PaymentMethod.OTHER,
                                        reference_number=f"{TRANSFER_REF_PREFIX}{request.user.pk}",
                                        payment_date=pay_date,
                                        status=Payment.Status.ALLOCATED,
                                    )

                                    transfer_receipt = Receipt.objects.create(
                                        payment=transfer_payment,
                                        balance_before=target_balance_before,
                                        balance_after=target_loan.outstanding_balance,
                                        amount_received=transfer_payment.amount_received,
                                        principal_paid=transfer_payment.principal_paid,
                                        interest_paid=transfer_payment.interest_paid,
                                        penalty_paid=transfer_payment.penalty_paid,
                                        overpayment=transfer_payment.overpayment,
                                    )

                                    # adjust client credit balance and ledger
                                    client.credit_balance = credit_available - applied
                                    client.save(update_fields=['credit_balance'])

                                    CreditTransaction.objects.create(
                                        client=client,
                                        tx_type=CreditTransaction.TxType.APPLIED,
                                        amount=-applied,
                                        balance_after=client.credit_balance,
                                        loan=target_loan,
                                        payment=transfer_payment,
                                        created_by=request.user,
                                        notes=f"Transferred to loan {target_loan.loan_number} by {request.user.get_full_name()}",
                                    )
                                except Exception:
                                    # If anything in recording transfer records fails, log but continue the main flow
                                    logger.exception("Failed to record transfer payment/receipt for client=%s target=%s", client, target_loan.pk)
                    except Exception:
                        # Fail softly: do not block the main payment flow for transfer errors
                        logger.exception("Credit transfer failed for client=%s target=%s", client, transfer_target_id)

                # After optional transfer, auto-apply remaining client credit to this payment
                credit_before = client.credit_balance
                credit_to_use = min(credit_before, amount)
                if credit_to_use > 0:
                    client.credit_balance = max(Decimal("0"), credit_before - credit_to_use)
                    client.save(update_fields=["credit_balance"])
                    CreditTransaction.objects.create(
                        client=client,
                        tx_type=CreditTransaction.TxType.APPLIED,
                        amount=-credit_to_use,
                        balance_after=client.credit_balance,
                        loan=selected_loan,
                        created_by=request.user,
                        notes=f"Applied to payment on {pay_date}",
                    )

                amount_to_apply = amount + credit_to_use

                # Create the payment record
                payment = Payment.objects.create(
                    loan             = selected_loan,
                    client           = selected_loan.client,
                    recorded_by      = request.user,
                    amount_received  = amount,
                    payment_method   = method,
                    reference_number = reference,
                    payment_date     = pay_date,
                    status           = Payment.Status.PENDING,
                )

                # Allocate payment to schedule entries
                remaining = amount_to_apply
                interest_paid   = Decimal("0")
                principal_paid  = Decimal("0")
                penalty_paid    = Decimal("0")

                pending_entries = LoanSchedule.objects.filter(
                    loan=selected_loan,
                    status__in=["PENDING", "OVERDUE", "PARTIAL"],
                ).order_by("period_number")
                pending_entries = list(pending_entries)
                penalties_assessed = Decimal("0")
                for entry in pending_entries:
                    old_periods = entry.penalty_periods_processed
                    penalties_assessed += _assess_schedule_penalty(
                        entry, selected_loan, pay_date, company_settings
                    )
                    if entry.penalty_periods_processed != old_periods:
                        entry.save(update_fields=[
                            "penalty_due",
                            "penalty_periods_processed",
                        ])
                balance_before += penalties_assessed

                for entry in pending_entries:
                    if remaining <= 0:
                        break

                    amount_due = entry.total_payment + entry.penalty_due - entry.amount_paid

                    if remaining >= amount_due:
                        # Full payment of this entry
                        interest_paid  += entry.interest_due
                        principal_paid += entry.principal_due
                        pending_penalty = max(
                            entry.penalty_due - entry.penalty_paid,
                            Decimal("0"),
                        )
                        penalty_paid   += pending_penalty
                        entry.penalty_paid += pending_penalty
                        remaining      -= amount_due
                        entry.amount_paid = entry.total_payment + entry.penalty_due
                        entry.status   = LoanSchedule.Status.PAID
                        entry.paid_date = pay_date
                    else:
                        # Partial payment — allocate: penalty first, then interest, then principal
                        allocated = remaining
                        pending_penalty = max(
                            entry.penalty_due - entry.penalty_paid,
                            Decimal("0"),
                        )
                        if remaining >= pending_penalty:
                            penalty_paid += pending_penalty
                            entry.penalty_paid += pending_penalty
                            remaining    -= pending_penalty
                        else:
                            penalty_paid += remaining
                            entry.penalty_paid += remaining
                            remaining     = Decimal("0")
                        if remaining >= entry.interest_due:
                            interest_paid += entry.interest_due
                            remaining     -= entry.interest_due
                        else:
                            interest_paid += remaining
                            remaining      = Decimal("0")
                        principal_paid += remaining
                        remaining       = Decimal("0")
                        entry.amount_paid += allocated
                        entry.status = LoanSchedule.Status.PARTIAL

                    entry.save()

                # Handle overpayment
                overpayment = max(remaining, Decimal("0"))

                # Update payment allocation breakdown
                payment.principal_paid  = principal_paid
                payment.interest_paid   = interest_paid
                payment.penalty_paid    = penalty_paid
                payment.overpayment     = overpayment
                payment.status          = Payment.Status.ALLOCATED
                payment.save()

                net_applied = amount_to_apply - overpayment

                if overpayment > 0:
                    client.credit_balance += overpayment
                    client.save(update_fields=["credit_balance"])
                    CreditTransaction.objects.create(
                        client=client,
                        tx_type=CreditTransaction.TxType.OVERPAYMENT,
                        amount=overpayment,
                        balance_after=client.credit_balance,
                        loan=selected_loan,
                        payment=payment,
                        created_by=request.user,
                        notes=f"Overpayment on {pay_date}",
                    )

                # Update loan totals
                selected_loan.total_paid        += net_applied
                selected_loan.total_penalties   += penalties_assessed
                selected_loan.outstanding_balance = max(
                    selected_loan.outstanding_balance + penalties_assessed - net_applied,
                    Decimal("0"),
                )
                if selected_loan.outstanding_balance == 0:
                    selected_loan.status          = Loan.Status.COMPLETED
                    selected_loan.completion_date = pay_date
                selected_loan.save()

                    # Create receipt (snapshot allocation values so receipt remains accurate)
                receipt = Receipt.objects.create(
                    payment        = payment,
                    balance_before = balance_before,
                    balance_after  = selected_loan.outstanding_balance,
                    amount_received = payment.amount_received,
                    principal_paid  = payment.principal_paid,
                    interest_paid   = payment.interest_paid,
                    penalty_paid    = payment.penalty_paid,
                    overpayment     = payment.overpayment,
                )

            credit_note = f" and UGX {overpayment:,.0f} stored as client credit" if overpayment > 0 else ""
            messages.success(request, f"Payment of UGX {amount:,.0f} recorded{credit_note}. Receipt: {receipt.receipt_number}")

            log_action(request.user, AuditLog.Action.PAYMENT, payment, request=request,
                       changes={"amount": str(amount), "loan": selected_loan.loan_number,
                                "principal": str(principal_paid), "interest": str(interest_paid),
                                "penalty": str(penalty_paid), "receipt": receipt.receipt_number},
                       remarks=f"Payment recorded by {request.user.full_name}")

            # If a transfer occurred and produced a transfer_receipt, render a combined receipt view
            try:
                if transfer_receipt is not None:
                    if request.headers.get("HX-Request") == "true":
                        return HttpResponse(
                            status=204,
                            headers={
                                "HX-Redirect": reverse(
                                    "payments:combined_receipt",
                                    kwargs={"transfer_pk": transfer_receipt.pk, "payment_pk": receipt.pk},
                                )
                            },
                        )
                    # Render combined receipts for printing/viewing
                    signatories, _ = selected_signatory(request)
                    document_title, _ = _receipt_document_title(
                        request, receipt.payment.client.full_name,
                    )
                    return render(request, "payments/combined_receipt.html", {
                        "receipts": [transfer_receipt, receipt],
                        "auto_print": False,
                        "receipt_document_title": document_title,
                        "signatories": signatories,
                        "selected_signatory": None,
                    })
            except Exception:
                # If something goes wrong rendering combined receipts, fall back to single receipt redirect
                logger.exception("Failed to render combined receipt for payment=%s", payment.pk)

            if request.headers.get("HX-Request") == "true":
                return HttpResponse(
                    status=204,
                    headers={"HX-Redirect": reverse("payments:receipt", kwargs={"pk": receipt.pk})},
                )
            return redirect("payments:receipt", pk=receipt.pk)

        except ValueError as e:
            payment_error = f"Payment Error: {e}"
            messages.error(request, f"Payment Error: {str(e)}")
        except TypeError as e:
            payment_error = f"Invalid input: {e}"
            messages.error(request, f"Invalid input: {str(e)}")
        except Exception as e:
            logger.exception(
                "Payment recording failed for loan=%s user=%s amount=%s",
                loan_id,
                request.user,
                request.POST.get("amount", ""),
            )
            payment_error = "Unexpected server error while recording payment. The issue has been logged."
            messages.error(request, "Unexpected server error while recording payment. The issue has been logged.")

        # If submitted from the list-page modal, re-render the list with the modal open
        if request.POST.get("_from_list"):
            qs = Payment.objects.select_related("loan__client", "recorded_by").order_by("-payment_date")
            qs = scope_to_branch(qs, request.user, "loan__branch")
            total_amount = qs.aggregate(total=Sum("amount_received"))["total"] or Decimal("0")
            active_loans = scope_to_branch(
                Loan.objects.filter(status="ACTIVE"), request.user
            ).select_related("client").order_by("client__last_name")
            return render(request, "payments/payment_list.html", {
                "payments": qs[:100],
                "total_amount": total_amount,
                "search": "",
                "active_loans": active_loans,
                "today": date.today(),
                "selected_loan_id": request.POST.get("loan_id", ""),
                "posted_amount": request.POST.get("amount", ""),
            })

    # Prepare client other loans list for the transfer UI (only when a loan is selected)
    client_other_loans = []
    if selected_loan or loan:
        l = selected_loan or loan
        try:
            client_other_loans = l.client.loans.filter(status=Loan.Status.ACTIVE).exclude(pk=l.pk).select_related('product').order_by('created_at')
        except Exception:
            client_other_loans = []

    return render(request, "payments/record_payment.html", {
        "loan":         selected_loan or loan,
        "active_loans": active_loans,
        "today":        date.today(),
        "client_other_loans": client_other_loans,
        "payment_error": payment_error,
        "posted_amount": request.POST.get("amount", ""),
        "posted_payment_date": request.POST.get("payment_date", ""),
        "posted_payment_method": request.POST.get("payment_method", "CASH"),
        "posted_reference_number": request.POST.get("reference_number", ""),
        "selected_loan_id": request.POST.get("loan_id", ""),
    })


@login_required
def receipt_view(request, pk):
    receipt = get_object_or_404(
        Receipt.objects.select_related(
            "payment__loan__client",
            "payment__loan__product",
            "payment__loan__branch",
            "payment__recorded_by",
        ),
        pk=pk,
    )
    loan = receipt.payment.loan
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That receipt belongs to a different branch.")
        return redirect("payments:list")
    guarantees = loan.guarantees.select_related('guarantor').all()
    collateral_items = loan.collateral_items.all()
    signatories, chosen_signatory = selected_signatory(request, loan.branch_id)

    # Receipt design: classic (letterhead + line-item table) or modern
    # (G-Loan style card, now the default). Resolution order:
    #   1. ?style=classic|modern on the URL — lets someone switch/preview
    #      the design right from the receipt page.
    #   2. The last style chosen this session, so it "sticks" as they
    #      move between receipts without re-picking every time.
    #   3. A per-company default, if you add one (see TODO below).
    #   4. "modern" as the final fallback.
    VALID_RECEIPT_STYLES = ("classic", "modern")
    requested_style = request.GET.get("style")

    if requested_style in VALID_RECEIPT_STYLES:
        receipt_style = requested_style
        request.session["receipt_style"] = receipt_style
    else:
        # TODO: once there's a persisted per-company preference (e.g. a
        # `receipt_template` field on your company/branch settings model),
        # swap the "classic" default below for that value, e.g.:
        #   company_default = getattr(loan.branch, "receipt_template", "classic")
        company_default = "classic"
        receipt_style = request.session.get("receipt_style", company_default)
        if receipt_style not in VALID_RECEIPT_STYLES:
            receipt_style = "classic"

    context = {
        "receipt": receipt,
        "guarantees": guarantees,
        "collateral_items": collateral_items,
        "receipt_style": receipt_style,
        "receipt_style_options": VALID_RECEIPT_STYLES,
        "signatories": signatories,
        "selected_signatory": chosen_signatory,
    }
    document_title, document_basename = _receipt_document_title(
        request, receipt.payment.client.full_name,
    )
    context["receipt_document_title"] = document_title
    if request.GET.get("format") == "pdf":
        filename = f"{document_basename}.pdf"
        return render_pdf_response(request, "payments/receipt.html", context, filename=filename)
    return render(request, "payments/receipt.html", context)


@login_required
def combined_receipt_view(request, transfer_pk, payment_pk):
    receipts = list(
        Receipt.objects.select_related(
            "payment__loan__client",
            "payment__loan__product",
            "payment__loan__branch",
            "payment__recorded_by",
        ).filter(pk__in=[transfer_pk, payment_pk])
    )
    receipts_by_id = {receipt.pk: receipt for receipt in receipts}
    transfer_receipt = receipts_by_id.get(transfer_pk)
    payment_receipt = receipts_by_id.get(payment_pk)
    if not transfer_receipt or not payment_receipt:
        raise Http404
    if (
        transfer_receipt.payment.client_id != payment_receipt.payment.client_id
        or not can_access_branch_object(request.user, transfer_receipt.payment.loan)
        or not can_access_branch_object(request.user, payment_receipt.payment.loan)
    ):
        messages.error(request, "Those receipts cannot be viewed together.")
        return redirect("payments:list")
    signatories, chosen_signatory = selected_signatory(request)
    document_title, _ = _receipt_document_title(
        request, payment_receipt.payment.client.full_name,
    )
    return render(request, "payments/combined_receipt.html", {
        "receipts": [transfer_receipt, payment_receipt],
        "auto_print": chosen_signatory is not None,
        "receipt_document_title": document_title,
        "signatories": signatories,
        "selected_signatory": chosen_signatory,
    })


@login_required
def payment_history(request, loan_pk):
    loan     = get_object_or_404(Loan, pk=loan_pk)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("payments:list")
    payments = Payment.objects.filter(loan=loan).select_related("recorded_by").order_by("-payment_date")
    return render(request, "payments/payment_history.html", {"loan": loan, "payments": payments})

@login_required
def credit_refund(request, client_pk):
    """CEO refunds a client's credit balance (cash payout of stored credit)."""
    from clients.models import Client

    if request.user.role != "CEO":
        messages.error(request, "Only the CEO can process refunds.")
        return redirect("clients:detail", pk=client_pk)

    client = get_object_or_404(Client, pk=client_pk)
    if not can_access_branch_object(request.user, client):
        messages.error(request, "That client belongs to a different branch.")
        return redirect("clients:list")

    if request.method == "POST":
        try:
            amount = Decimal(request.POST.get("amount", "0").strip())
            if amount <= 0:
                raise ValueError("Refund amount must be greater than zero.")
            if amount > client.credit_balance:
                raise ValueError(
                    f"Refund amount UGX {amount:,.0f} exceeds credit balance UGX {client.credit_balance:,.0f}."
                )
            notes = request.POST.get("notes", "").strip()
            with transaction.atomic():
                client.credit_balance -= amount
                client.save(update_fields=["credit_balance"])
                CreditTransaction.objects.create(
                    client=client,
                    tx_type=CreditTransaction.TxType.REFUNDED,
                    amount=-amount,
                    balance_after=client.credit_balance,
                    created_by=request.user,
                    notes=notes or f"Cash refund authorised by {request.user.full_name}",
                )
            messages.success(
                request,
                f"UGX {amount:,.0f} refunded to {client.full_name}. Remaining credit: UGX {client.credit_balance:,.0f}.",
            )
        except ValueError as e:
            messages.error(request, str(e))
        return redirect("clients:detail", pk=client_pk)

    return render(request, "payments/credit_refund.html", {"client": client})