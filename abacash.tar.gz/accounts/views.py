"""
accounts/views.py
=================
Authentication, role-based dashboard routing, and comprehensive admin panel for ABA Uganda.
"""

from datetime import datetime, timedelta
from decimal import Decimal, ROUND_HALF_UP
from urllib.parse import urlencode

from django.contrib import messages
from django.contrib.auth import login, logout, get_user_model
from django.contrib.auth.decorators import login_required
from django.contrib.auth.hashers import make_password
from django.core.paginator import Paginator
from django.forms import ImageField
from django.db import transaction
from django.db.models import F, Q, Sum, Count
from django.db.models.functions import TruncDay, TruncMonth
from django.shortcuts import render, redirect, get_object_or_404
from django.urls import reverse
from django.utils import timezone
from django.utils.dateparse import parse_date
from django.http import HttpResponse, JsonResponse
from django.views.decorators.http import require_POST
from django.core.mail import send_mail
from django.conf import settings
from dateutil.relativedelta import relativedelta

from loans.models import Loan, LoanFee, LoanSchedule, LoanProduct, Guarantor
from loans.utils import penalty_periods_elapsed
from payments.models import Payment
from clients.models import Client
from .models import CompanySettings, Branch, Expense, CapitalInjection, Investor, InvestorDrawing, FeeType, Holiday, AuditLog, User, TransactionCategory, ExpenseType, BankAccount, BankTransaction
from .branch_scope import (
    scope_to_branch,
    effective_branch_id,
    resolve_branch_for_write,
    get_single_active_branch_id,
)
from .cash import cash_movement, recent_cash_transactions
from .permissions import PERMISSIONS, ALL_GROUPS
from .audit import log_action
from .forms import EmailOrUsernameAuthenticationForm
from .terms import sanitize_loan_terms

User = get_user_model()


def _quick_form_saved(request):
    if request.headers.get("HX-Request") == "true":
        return HttpResponse(
            status=204,
            headers={"HX-Trigger": '{"quickFormSaved": null, "quickFormNotice": {"message": "Saved successfully."}}'},
        )
    return None


def _validated_signature_upload(upload):
    if not upload:
        return None
    if upload.size > 2 * 1024 * 1024:
        raise ValueError("Signature images must be 2 MB or smaller.")
    return ImageField().clean(upload)


def _permission_required(codename):
    """
    Decorator factory: restrict a view to users with the given app
    permission (see accounts/permissions.py for the full list and which
    Group/role gets each one by default). Replaces the old
    _ceo_required/_manager_required decorators, which hard-coded role
    checks instead of going through the permission system.
    """
    from functools import wraps
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def wrapper(request, *args, **kwargs):
            if not request.user.can(codename):
                messages.error(request, "You do not have permission to access that page.")
                return redirect("accounts:dashboard")
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


def _ceo_required(view_func):
    from functools import wraps
    @wraps(view_func)
    @login_required
    def wrapper(request, *args, **kwargs):
        if not request.user.is_ceo:
            messages.error(request, "Only the CEO can access the admin panel.")
            return redirect("accounts:dashboard")
        return view_func(request, *args, **kwargs)
    return wrapper


def _manager_required(view_func):
    from functools import wraps
    @wraps(view_func)
    @login_required
    def wrapper(request, *args, **kwargs):
        if request.user.is_cashier:
            messages.error(request, "This feature is available to Managers and CEO only.")
            return redirect("accounts:dashboard")
        return view_func(request, *args, **kwargs)
    return wrapper


# ------------------------------------------------------------------ #
# Authentication                                                       #
# ------------------------------------------------------------------ #

def login_view(request):
    if request.user.is_authenticated:
        return redirect("accounts:dashboard")

    form = EmailOrUsernameAuthenticationForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        login(request, form.get_user())
        return redirect(request.GET.get("next", "accounts:dashboard"))

    return render(request, "accounts/login.html", {
        "form": form,
        "company": CompanySettings.get(),
    })


def contact_chatbot(request):
    """Public contact form on the login page — routes to email, sales, or WhatsApp."""
    if request.method == "POST":
        name = (request.POST.get("name") or "").strip()
        phone = (request.POST.get("phone") or "").strip()
        message = (request.POST.get("message") or "").strip()

        destination = (request.POST.get('destination') or 'whatsapp').lower()

        detail_parts = []
        if name:
            detail_parts.append(f"Name: {name}")
        if phone:
            detail_parts.append(f"Phone: {phone}")
        if message:
            detail_parts.append(f"Message: {message}")
        else:
            detail_parts.append("Message: Hello, I would like help.")

        text = " | ".join(detail_parts)

        if destination == 'email':
            settings_obj = CompanySettings.objects.first()
            to_addr = settings_obj.company_email if settings_obj and settings_obj.company_email else None
            subject = f"Website contact: {name or phone or 'Anonymous'}"
            body = text
            from_addr = getattr(settings, 'DEFAULT_FROM_EMAIL', 'no-reply@example.com')
            if to_addr:
                try:
                    send_mail(subject, body, from_addr, [to_addr])
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'status': 'ok', 'message': 'Email sent to support.'})
                    messages.success(request, 'Your message was sent to support by email.')
                except Exception:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'status': 'error', 'message': 'Failed to send email.'})
                    messages.error(request, 'Failed to send email. Please try again later.')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'status': 'error', 'message': 'No support email configured.'})
                messages.error(request, 'Support email not configured.')
            return redirect('accounts:login')

        if destination == 'sales':
            settings_obj = CompanySettings.objects.first()
            to_addr = settings_obj.company_email if settings_obj and settings_obj.company_email else None
            subject = f"Sales lead: {name or phone or 'Anonymous'}"
            body = text
            from_addr = getattr(settings, 'DEFAULT_FROM_EMAIL', 'no-reply@example.com')
            if to_addr:
                try:
                    send_mail(subject, body, from_addr, [to_addr])
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'status': 'ok', 'message': 'Sales team notified internally.'})
                    messages.success(request, 'Sales team notified internally.')
                except Exception:
                    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                        return JsonResponse({'status': 'error', 'message': 'Failed to notify sales.'})
                    messages.error(request, 'Failed to notify sales. Please try again later.')
            else:
                if request.headers.get('x-requested-with') == 'XMLHttpRequest':
                    return JsonResponse({'status': 'error', 'message': 'No sales address configured.'})
                messages.error(request, 'Sales contact not configured.')
            return redirect('accounts:login')

        # default: whatsapp
        encoded_text = urlencode({"text": text})
        whatsapp_url = f"https://wa.me/256785230670?{encoded_text}"
        if request.headers.get('x-requested-with') == 'XMLHttpRequest':
            return JsonResponse({'status': 'ok', 'redirect_url': whatsapp_url, 'message': 'Opening WhatsApp chat...', 'ack_message': 'We will follow up shortly.'})
        return redirect(whatsapp_url)

    return redirect("accounts:login")


def logout_view(request):
    logout(request)
    return redirect("accounts:login")


# ------------------------------------------------------------------ #
# Dashboard                                                            #
# ------------------------------------------------------------------ #

@login_required
def dashboard(request):
    """Route to the correct dashboard based on user role."""
    user = request.user
    today = timezone.localdate()

    if user.is_ceo:
        return _ceo_dashboard(request, today)
    elif user.is_manager:
        return _manager_dashboard(request, today)
    else:
        return _cashier_dashboard(request, today)


def _cashier_dashboard(request, today):
    user = request.user
    month_start = today.replace(day=1)

    # Schedules due today or overdue, limited to the cashier's branch.
    # Overdue rows are included so missed payments stay visible.
    schedules = scope_to_branch(
        LoanSchedule.objects.filter(
            due_date__lte=today,
            status__in=[LoanSchedule.Status.PENDING,
                        LoanSchedule.Status.OVERDUE,
                        LoanSchedule.Status.PARTIAL],
            loan__status__in=["ACTIVE", "RESTRUCTURED"],
        ),
        user, "loan__branch",
    ).select_related("loan__client")

    due_count = schedules.count()  # count BEFORE slicing
    due_list = list(schedules.order_by("loan__client__last_name")[:20])
    for entry in due_list:
        # Same formula as Loan.next_due_amount: unpaid balance on this period.
        entry.balance_due = entry.total_payment + entry.penalty_due - entry.amount_paid

    # Branch-wide cash payments, not just this cashier's own receipts.
    payments = scope_to_branch(
        Payment.objects.cash_receipts().filter(status=Payment.Status.ALLOCATED),
        user, "loan__branch",
    )
    collected_today = payments.filter(payment_date=today).aggregate(
        total=Sum("amount_received"))["total"] or 0
    recent_payments = payments.select_related("client", "loan").order_by("-created_at")[:10]

    cash_now = cash_movement(user=user)
    cash_month = cash_movement(user=user, start_date=month_start, end_date=today)

    context = {
        "due_today": due_list,
        "due_today_count": due_count,
        "collected_today_total": collected_today,
        "collected_this_month": cash_month["payments"],
        "cash_at_hand": cash_now["cash_at_hand"],
        "recent_payments": recent_payments,
        # Cashiers get payments and disbursements only, not owner-level entries.
        "recent_cash": recent_cash_transactions(
            user=user, limit=10, include_owner_entries=False),
    }
    return render(request, "accounts/dashboard_cashier.html", context)


def _build_dashboard_performance(current, previous):
    """Build a weighted operating-quality indicator from collection outcomes."""
    definitions = (
        ("loan_charges", "New loan fees and interest", 1),
        ("interest_income", "Interest collected", 1),
        ("disbursements", "Loans given out", 1),
        ("expenses", "Expenses paid", -1),
        ("injections", "Money added to the business", 1),
        ("overdue_recoveries", "Overdue payments collected", 1),
        ("overdue_balance", "Unpaid overdue amount", -1),
        ("on_time_rate", "Payments made on time", 1),
    )
    score_weights = {
        "on_time_rate": Decimal("0.45"),
        "overdue_balance": Decimal("0.35"),
        "interest_income": Decimal("0.20"),
    }
    metrics = {}
    for key, label, direction in definitions:
        current_decimal = Decimal(str(current[key] or 0))
        previous_decimal = Decimal(str(previous[key] or 0))
        current_value = float(current_decimal)
        previous_value = float(previous_decimal)
        observed = key != "on_time_rate" or current.get("paid_schedule_count", 0) > 0
        if not observed:
            change_percent = None
            change_label = "No observations"
        elif previous_decimal:
            change_percent_decimal = (
                (current_decimal - previous_decimal)
                / abs(previous_decimal)
                * Decimal("100")
            ).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
            change_percent = float(change_percent_decimal)
            change_label = (
                f"{(current_decimal - previous_decimal).quantize(Decimal('0.1'), rounding=ROUND_HALF_UP):+.1f} pp"
                if key == "on_time_rate"
                else f"{change_percent:+.1f}%"
            )
        elif current_value:
            change_percent = None
            change_label = "New"
        else:
            change_percent = 0.0
            change_label = "0.0%"

        metrics[key] = {
            "label": label,
            "current": current_value,
            "previous": previous_value,
            "change_percent": change_percent,
            "change_label": change_label,
            "direction": (
                "neutral" if not observed
                else "positive" if direction * (current_decimal - previous_decimal) > 0
                else "negative" if direction * (current_decimal - previous_decimal) < 0
                else "neutral"
            ),
            "observed": observed,
            "contributes_to_score": key in score_weights,
            "score_weight": score_weights.get(key, Decimal("0")) * 100,
            "current_count": current.get("paid_schedule_count", 0) if key == "on_time_rate" else None,
            "previous_count": previous.get("paid_schedule_count", 0) if key == "on_time_rate" else None,
        }

    def trend_score(current_value, previous_value, direction):
        if not previous_value:
            return Decimal("0") if direction < 0 and current_value else Decimal("50")
        change_percent = (
            (current_value - previous_value)
            / abs(previous_value)
            * Decimal("100")
        )
        return max(
            Decimal("0"),
            min(Decimal("100"), Decimal("50") + direction * change_percent / Decimal("2")),
        )

    on_time_score = (
        Decimal(str(current["on_time_rate"] or 0))
        if current.get("paid_schedule_count", 0) > 0
        else Decimal("50")
    )
    overdue_score = trend_score(
        Decimal(str(current["overdue_balance"] or 0)),
        Decimal(str(previous["overdue_balance"] or 0)),
        -1,
    )
    interest_score = trend_score(
        Decimal(str(current["interest_income"] or 0)),
        Decimal(str(previous["interest_income"] or 0)),
        1,
    )
    score = (
        on_time_score * score_weights["on_time_rate"]
        + overdue_score * score_weights["overdue_balance"]
        + interest_score * score_weights["interest_income"]
    ).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP)
    recommendations = []
    for key in score_weights:
        metric = metrics[key]
        if metric["direction"] != "negative":
            continue
        recommendations.append({
            "level": "warning",
            "title": f"{metric['label']} got worse",
            "detail": (
                f"{metric['change_label']} compared with the previous period. "
                "Check the related loans and payments to understand why."
            ),
        })
    if not recommendations:
        recommendations.append({
            "level": "positive",
            "title": "Performance is steady or improving",
            "detail": "None of the measures used in the score got worse than in the previous period.",
        })
    return {
        "score": float(score),
        "metrics": metrics,
        "recommendations": recommendations,
    }


def _on_time_schedule_payment_filter():
    return Q(paid_date__lte=F("due_date"))


def _unpaid_overdue_schedule_filter(as_of_date):
    return Q(
        due_date__lt=as_of_date,
        status__in=[
            LoanSchedule.Status.PENDING,
            LoanSchedule.Status.PARTIAL,
            LoanSchedule.Status.OVERDUE,
        ],
    )


def _dashboard_performance_period(user, date_from, date_to, branch_id=None):
    period_days = (date_to - date_from).days + 1
    previous_to = date_from - timedelta(days=1)
    previous_from = previous_to - timedelta(days=period_days - 1)

    def collect_period(start, end):
        loans = scope_to_branch(
            Loan.objects.filter(
                disbursement_date__range=(start, end),
                status__in=[
                    Loan.Status.ACTIVE, Loan.Status.COMPLETED, Loan.Status.DEFAULTED,
                    Loan.Status.WRITTEN_OFF, Loan.Status.RESTRUCTURED,
                ],
            ),
            user,
        )
        payments = scope_to_branch(
            Payment.objects.filter(
                payment_date__range=(start, end),
                status=Payment.Status.ALLOCATED,
            ),
            user,
            "loan__branch",
        )
        expenses = scope_to_branch(
            Expense.objects.filter(
                expense_date__range=(start, end),
                status=Expense.Status.APPROVED,
            ),
            user,
        )
        schedules = scope_to_branch(
            LoanSchedule.objects.filter(
                status=LoanSchedule.Status.PAID,
                paid_date__range=(start, end),
            ),
            user,
            "loan__branch",
        )
        overdue_schedules = scope_to_branch(
            LoanSchedule.objects.filter(_unpaid_overdue_schedule_filter(end)),
            user,
            "loan__branch",
        )
        if branch_id is not None:
            loans = loans.filter(branch_id=branch_id)
            payments = payments.filter(loan__branch_id=branch_id)
            expenses = expenses.filter(branch_id=branch_id)
            schedules = schedules.filter(loan__branch_id=branch_id)
            overdue_schedules = overdue_schedules.filter(loan__branch_id=branch_id)

        loan_totals = loans.aggregate(
            disbursements=Sum("principal_amount"),
            interest=Sum("total_interest"),
            fees=Sum("processing_fee"),
        )
        schedule_totals = schedules.aggregate(
            count=Count("pk"),
            # A settlement before its due date is on time as well.
            on_time=Count("pk", filter=_on_time_schedule_payment_filter()),
            overdue_recoveries=Sum(
                "total_payment",
                filter=Q(due_date__lt=start),
            ),
            overdue_penalties=Sum(
                "penalty_due",
                filter=Q(due_date__lt=start),
            ),
        )
        overdue_totals = overdue_schedules.aggregate(
            scheduled=Sum("total_payment"),
            penalties=Sum("penalty_due"),
            paid=Sum("amount_paid"),
        )
        paid_count = schedule_totals["count"] or 0
        return {
            "loan_charges": (loan_totals["interest"] or Decimal("0"))
            + (loan_totals["fees"] or Decimal("0")),
            "interest_income": payments.aggregate(total=Sum("interest_paid"))["total"]
            or Decimal("0"),
            "disbursements": loan_totals["disbursements"] or Decimal("0"),
            "expenses": expenses.aggregate(total=Sum("amount"))["total"]
            or Decimal("0"),
            # Capital injections remain company-wide, as in the cash summary.
            "injections": CapitalInjection.objects.filter(
                injected_date__range=(start, end),
            ).aggregate(total=Sum("amount"))["total"] or Decimal("0"),
            "overdue_recoveries": (schedule_totals["overdue_recoveries"] or Decimal("0"))
            + (schedule_totals["overdue_penalties"] or Decimal("0")),
            "overdue_balance": max(
                Decimal("0"),
                (overdue_totals["scheduled"] or Decimal("0"))
                + (overdue_totals["penalties"] or Decimal("0"))
                - (overdue_totals["paid"] or Decimal("0")),
            ),
            "on_time_rate": (
                schedule_totals["on_time"] / paid_count * 100 if paid_count else 0
            ),
            "paid_schedule_count": paid_count,
        }

    current = collect_period(date_from, date_to)
    previous = collect_period(previous_from, previous_to)
    comparison_period = f"{previous_from:%d %b %Y} – {previous_to:%d %b %Y}"
    return _build_dashboard_performance(current, previous), comparison_period


def _manager_dashboard(request, today):
    # Pending approvals
    pending_loans = scope_to_branch(Loan.objects.filter(
        status="PENDING"
    ), request.user).select_related("client", "product", "applied_by").order_by("application_date")[:20]

    # Overdue loans
    overdue_schedules = scope_to_branch(LoanSchedule.objects.filter(
        due_date__lt=today,
        status__in=["PENDING", "OVERDUE", "PARTIAL"],
        loan__status__in=["ACTIVE", "RESTRUCTURED"],
    ), request.user, "loan__branch").select_related("loan__client").order_by("due_date")[:20]

    # Portfolio metrics
    active_loans       = scope_to_branch(Loan.objects.filter(status__in=["ACTIVE", "RESTRUCTURED"]), request.user)
    total_portfolio    = active_loans.aggregate(total=Sum("principal_amount"))["total"] or 0
    total_outstanding  = active_loans.aggregate(total=Sum("outstanding_balance"))["total"] or 0

    month_start = today.replace(day=1)
    performance, performance_comparison_period = _dashboard_performance_period(
        request.user, month_start, today,
    )
    performance_period = "This month"
    collected_month = scope_to_branch(Payment.objects.cash_receipts().filter(
        payment_date__gte=month_start,
        status="ALLOCATED",
    ), request.user, "loan__branch").aggregate(total=Sum("amount_received"))["total"] or 0

    # Risk metrics
    par_30_count = scope_to_branch(Loan.objects.filter(
        status__in=["ACTIVE", "RESTRUCTURED"],
        schedule__due_date__lt=today,
        schedule__status__in=["PENDING", "OVERDUE", "PARTIAL"],
    ), request.user).distinct().count()

    staff_performance = []
    branch_staff = User.objects.filter(is_active=True)
    if not request.user.can("can_view_all_branches"):
        branch_staff = branch_staff.filter(branch_id=request.user.branch_id) if request.user.branch_id else branch_staff.none()
    for staff in branch_staff.order_by("first_name", "last_name", "username"):
        if staff.is_ceo:
            continue
        applied_loans = Loan.objects.filter(applied_by=staff)
        collections_this_month = Payment.objects.cash_receipts().filter(
            recorded_by=staff,
            payment_date__gte=month_start,
            status="ALLOCATED",
        ).aggregate(total=Sum("amount_received"))["total"] or Decimal("0")
        staff_performance.append({
            "user": staff,
            "applications_count": applied_loans.count(),
            "active_loans_count": applied_loans.filter(status__in=["ACTIVE", "RESTRUCTURED"]).count(),
            "collections_this_month": collections_this_month,
        })

    staff_performance.sort(
        key=lambda item: (-item["applications_count"], -item["collections_this_month"], item["user"].full_name)
    )

    can_view_all_branches = request.user.can("can_view_all_branches")
    cash_at_hand = cash_movement(user=request.user)["cash_at_hand"]
    recent_cash = recent_cash_transactions(user=request.user)

    context = {
        "pending_loans":        pending_loans,
        "overdue_schedules":    overdue_schedules,
        "total_portfolio":      total_portfolio,
        "total_outstanding":    total_outstanding,
        "collected_month":      collected_month,
        "performance":          performance,
        "performance_period":   performance_period,
        "performance_comparison_period": performance_comparison_period,
        "overdue_count":        overdue_schedules.count(),
        "active_loan_count":    active_loans.count(),
        "pending_count":        pending_loans.count(),
        "par_30_count":         par_30_count,
        "staff_performance":   staff_performance[:8],
        "cash_at_hand":         cash_at_hand,
        "recent_cash":          recent_cash,
        "can_view_all_branches": can_view_all_branches,
    }
    return render(request, "accounts/dashboard_manager.html", context)


def _ceo_dashboard(request, today):
    period = request.GET.get("period", "6")
    if period not in {"week", "month", "3", "6", "12"}:
        period = "6"

    date_from = parse_date(request.GET.get("date_from", ""))
    date_to = parse_date(request.GET.get("date_to", ""))
    has_custom_range = bool(request.GET.get("date_from") or request.GET.get("date_to"))
    date_error = ""
    if has_custom_range and (
        date_from is None or date_to is None or date_from > date_to or date_to > today
    ):
        date_error = "Enter a valid date range ending today or earlier."
        if request.headers.get("x-requested-with") == "XMLHttpRequest":
            return JsonResponse({"error": date_error}, status=400)
        date_from = date_to = None
        has_custom_range = False

    if has_custom_range:
        period_start = date_from
    elif period == "week":
        period_start = today - timedelta(days=today.weekday())
    elif period == "month":
        period_start = today.replace(day=1)
    else:
        period_start = (today - relativedelta(months=int(period) - 1)).replace(day=1)
    period_end = date_to if has_custom_range else today

    daily_activity = not has_custom_range and period in {"week", "month"}
    activity_buckets = []
    bucket_start = period_start if daily_activity else period_start.replace(day=1)
    while bucket_start <= period_end:
        activity_buckets.append(bucket_start)
        bucket_start += timedelta(days=1) if daily_activity else relativedelta(months=1)

    # CEO's nav-switcher branch selection (None = all branches). This makes
    # the dashboard consistent with Loans/Clients/Payments/Reports, which
    # all honour the same switcher via effective_branch_id/scope_to_branch.
    branch_id = effective_branch_id(request)
    performance, performance_comparison_period = _dashboard_performance_period(
        request.user, period_start, period_end, branch_id=branch_id,
    )
    performance_period = "Selected range" if has_custom_range else (
        "This week" if period == "week" else
        "This month" if period == "month" else
        f"Last {period} months"
    )

    all_active = Loan.objects.filter(
        status__in=["ACTIVE", "RESTRUCTURED"],
        disbursement_date__gte=period_start,
        disbursement_date__lte=period_end,
    )
    allocated_period = Payment.objects.filter(
        payment_date__gte=period_start,
        payment_date__lte=period_end,
        status="ALLOCATED",
    )
    overdue_30 = Loan.objects.filter(
        status__in=["ACTIVE", "RESTRUCTURED"],
        schedule__due_date__gte=period_start,
        schedule__due_date__lte=period_end,
        schedule__status__in=["PENDING", "OVERDUE", "PARTIAL"],
    ).distinct()
    total_clients_qs = Client.objects.filter(is_active=True)
    pending_loans_qs = Loan.objects.filter(
        status="PENDING",
        application_date__gte=period_start,
        application_date__lte=period_end,
    )
    recent_loans_qs = Loan.objects.filter(status__in=["ACTIVE", "RESTRUCTURED", "COMPLETED"])
    risk_base_qs = Loan.objects.filter(
        status__in=["ACTIVE", "RESTRUCTURED"],
        disbursement_date__gte=period_start,
        disbursement_date__lte=period_end,
    )

    if branch_id is not None:
        all_active = all_active.filter(branch_id=branch_id)
        allocated_period = allocated_period.filter(loan__branch_id=branch_id)
        overdue_30 = overdue_30.filter(branch_id=branch_id)
        total_clients_qs = total_clients_qs.filter(branch_id=branch_id)
        pending_loans_qs = pending_loans_qs.filter(branch_id=branch_id)
        recent_loans_qs = recent_loans_qs.filter(branch_id=branch_id)
        risk_base_qs = risk_base_qs.filter(branch_id=branch_id)

    total_portfolio = all_active.aggregate(total=Sum("principal_amount"))["total"] or 0
    total_outstanding = all_active.aggregate(total=Sum("outstanding_balance"))["total"] or 0
    total_interest = all_active.aggregate(total=Sum("total_interest"))["total"] or 0

    # Cash collected excludes internal credit transfers (cash already counted when
    # the overpayment arrived); interest income includes them (real allocation).
    collected_total = allocated_period.cash_receipts().aggregate(total=Sum("amount_received"))["total"] or 0
    interest_income = allocated_period.aggregate(total=Sum("interest_paid"))["total"] or 0

    overdue_count = overdue_30.count()
    total_clients = total_clients_qs.count()
    pending_count = pending_loans_qs.count()

    # Aggregate chart values in two queries regardless of the selected range length.
    payments_by_month = Payment.objects.cash_receipts().filter(
        payment_date__gte=period_start,
        payment_date__lte=period_end,
        status="ALLOCATED",
    )
    expenses_by_month = Expense.objects.filter(
        expense_date__gte=period_start,
        expense_date__lte=period_end,
        status=Expense.Status.APPROVED,
    )
    if branch_id is not None:
        payments_by_month = payments_by_month.filter(loan__branch_id=branch_id)
        expenses_by_month = expenses_by_month.filter(branch_id=branch_id)

    bucket_truncation = TruncDay if daily_activity else TruncMonth
    bucket_format = "%Y-%m-%d" if daily_activity else "%Y-%m"
    payment_activity_totals = {
        row["bucket"].strftime(bucket_format): row
        for row in payments_by_month.annotate(bucket=bucket_truncation("payment_date"))
        .values("bucket")
        .annotate(
            collected=Sum("amount_received"),
            interest=Sum("interest_paid"),
        )
    }
    expense_activity_totals = {
        row["bucket"].strftime(bucket_format): row["total"]
        for row in expenses_by_month.annotate(bucket=bucket_truncation("expense_date"))
        .values("bucket")
        .annotate(total=Sum("amount"))
    }

    monthly_data = []
    expense_history = []
    for bucket_start in activity_buckets:
        bucket_key = bucket_start.strftime(bucket_format)
        payment_totals = payment_activity_totals.get(bucket_key, {})
        bucket_label = (
            bucket_start.strftime("%a %d" if period == "week" else "%d %b")
            if daily_activity else bucket_start.strftime("%b %Y")
        )
        monthly_data.append({
            "label": bucket_label,
            "collected": float(payment_totals.get("collected") or 0),
            "interest": float(payment_totals.get("interest") or 0),
        })
        expense_history.append({
            "label": bucket_label,
            "value": float(expense_activity_totals.get(bucket_key) or 0),
        })

    expenses = Expense.objects.filter(
        expense_date__gte=period_start,
        expense_date__lte=period_end,
        status=Expense.Status.APPROVED,
    )
    if branch_id is not None:
        expenses = expenses.filter(branch_id=branch_id)
    total_expenses = expenses.aggregate(total=Sum("amount"))["total"] or 0
    # Group by TransactionCategory name
    from collections import defaultdict
    cat_totals = defaultdict(float)
    for expense in expenses.select_related("category"):
        label = expense.category.name if expense.category else "Uncategorised"
        cat_totals[label] += float(expense.amount)
    expense_data = [{"label": k, "value": v} for k, v in cat_totals.items() if v > 0]
    # Capital injections are company-wide (not tied to a branch), so they
    # deliberately stay unfiltered regardless of the branch switcher.
    injections = CapitalInjection.objects.filter(injected_date__gte=period_start, injected_date__lte=period_end)
    total_injections = injections.aggregate(total=Sum("amount"))["total"] or 0

    # Recent loans for loan book table
    recent_loans = recent_loans_qs.filter(
        disbursement_date__gte=period_start,
        disbursement_date__lte=period_end,
    ).select_related("client", "product").order_by("-disbursement_date")[:20]

    # Branch performance — when a single branch is selected, show just that
    # branch instead of the full company-wide comparison table.
    branches_qs = Branch.objects.filter(is_active=True)
    if branch_id is not None:
        branches_qs = branches_qs.filter(pk=branch_id)
    branches = branches_qs.annotate(
        loan_count=Count(
            "loans",
            filter=Q(
                loans__status__in=["ACTIVE", "RESTRUCTURED"],
                loans__disbursement_date__gte=period_start,
                loans__disbursement_date__lte=period_end,
            ),
        ),
        total_disbursed=Sum(
            "loans__principal_amount",
            filter=Q(
                loans__disbursement_date__gte=period_start,
                loans__disbursement_date__lte=period_end,
            ),
        ),
    )

    # Risk distribution
    risk_distribution = {
        rating: risk_base_qs.filter(risk_rating=rating).count()
        for rating in ["LOW", "NORMAL", "WATCH", "SUBSTANDARD", "DOUBTFUL", "LOSS"]
    }

    is_ajax_request = request.headers.get("x-requested-with") == "XMLHttpRequest"
    selected_cash = cash_movement(
        user=request.user,
        branch_id=branch_id,
        start_date=period_start,
        end_date=period_end,
    )["cash_at_hand"]
    selected_recent_cash = recent_cash_transactions(
        user=request.user,
        branch_id=branch_id,
        start_date=period_start,
        end_date=period_end,
    )
    cash_switch_data = [
        {
            "id": selected_id,
            "label": label,
            "balance": str(cash_movement(
                user=request.user,
                branch_id=selected_id,
                start_date=period_start,
                end_date=period_end,
            )["cash_at_hand"]),
            "transactions": [
                {
                    **transaction,
                    "date": transaction["date"].isoformat(),
                    "timestamp": transaction["timestamp"].strftime("%d %b %Y at %H:%M"),
                    "amount": str(transaction["amount"]),
                }
                for transaction in recent_cash_transactions(
                    user=request.user,
                    branch_id=selected_id,
                    start_date=period_start,
                    end_date=period_end,
                )
            ],
        }
        for selected_id, label in [(None, "All")] + list(
            Branch.objects.filter(is_active=True).values_list("pk", "code")
        )
    ]

    context = {
        "total_portfolio": total_portfolio,
        "total_outstanding": total_outstanding,
        "total_interest": total_interest,
        "collected_period": collected_total,
        "interest_income": interest_income,
        "overdue_count": overdue_count,
        "total_clients": total_clients,
        "pending_count": pending_count,
        "monthly_data": monthly_data,
        "expense_history": expense_history,
        "recent_loans": recent_loans,
        "active_count": all_active.count(),
        "branches": branches,
        "risk_distribution": risk_distribution,
        "expense_data": expense_data,
        "total_expenses": total_expenses,
        "performance": performance,
        "performance_period": performance_period,
        "performance_comparison_period": performance_comparison_period,
        "total_injections": total_injections,
        "cash_at_hand": selected_cash,
        "recent_cash": selected_recent_cash,
        "cash_switch_data": cash_switch_data,
        "cash_branch_id": branch_id,
        "branch_id": branch_id,
        "branch_options": Branch.objects.filter(is_active=True).order_by("name"),
        "period": period,
        "period_label": (
            "This week" if period == "week" else
            "This month" if period == "month" else
            f"Last {period} months"
        ),
        "period_options": ["week", "month", 3, 6, 12],
        "date_from": date_from if has_custom_range else None,
        "date_to": date_to if has_custom_range else None,
        "date_error": date_error,
        "today": today,
    }
    if is_ajax_request:
        return JsonResponse({
            "period": period,
            "period_label": context["period_label"],
            "date_from": period_start.isoformat(),
            "date_to": period_end.isoformat(),
            "custom_date_from": date_from.isoformat() if has_custom_range else "",
            "custom_date_to": date_to.isoformat() if has_custom_range else "",
            "date_label": (
                f"{period_start:%d %b %Y} – {period_end:%d %b %Y}"
                if has_custom_range or period in {"week", "month"} else context["period_label"]
            ),
            "custom_range": has_custom_range,
            "currency_symbol": CompanySettings.get().currency_symbol or "UGX",
            "branch_label": (
                Branch.objects.filter(pk=branch_id).values_list("name", flat=True).first() or "Selected branch"
                if branch_id is not None else "All branches"
            ),
            "metrics": {
                "total_portfolio": float(total_portfolio),
                "total_outstanding": float(total_outstanding),
                "collected_period": float(collected_total),
                "interest_income": float(interest_income),
                "total_expenses": float(total_expenses),
                "total_injections": float(total_injections),
                "overdue_count": overdue_count,
                "pending_count": pending_count,
                "cash_at_hand": float(selected_cash),
            },
            "performance": performance,
            "performance_period": performance_period,
            "performance_comparison_period": performance_comparison_period,
            "monthly_data": monthly_data,
            "expense_history": expense_history,
            "expense_data": expense_data,
            "risk_distribution": risk_distribution,
            "recent_loans": [
                {
                    "loan_number": loan.loan_number,
                    "loan_url": reverse("loans:detail", kwargs={"pk": loan.pk}),
                    "client_name": loan.client.full_name,
                    "client_url": reverse("clients:detail", kwargs={"pk": loan.client.pk}),
                    "product_name": loan.product.name,
                    "principal": float(loan.principal_amount),
                    "outstanding": float(loan.outstanding_balance),
                    "next_due": loan.next_due_date.isoformat() if loan.next_due_date else "",
                    "status": loan.get_status_display(),
                    "status_code": loan.status,
                }
                for loan in recent_loans
            ],
            "active_count": context["active_count"],
            "recent_cash": [
                {
                    "type": item["type"],
                    "description": item["description"],
                    "date": item["date"].isoformat(),
                    "timestamp": item["timestamp"].strftime("%H:%M"),
                    "direction": item["direction"],
                    "amount": float(item["amount"]),
                }
                for item in selected_recent_cash
            ],
            "cash_switch_data": cash_switch_data,
        })
    return render(request, "accounts/dashboard_ceo.html", context)

@_permission_required("can_view_admin_panel")

def admin_dashboard(request):
    context = {
        "total_users":    User.objects.count(),
        "active_users":   User.objects.filter(is_active=True).count(),
        "users_by_role":  {
            "Cashier": User.objects.filter(role="CASHIER").count(),
            "Manager": User.objects.filter(role="MANAGER").count(),
            "CEO":     User.objects.filter(role="CEO").count(),
        },
        "total_clients":  Client.objects.count(),
        "total_loans":    Loan.objects.count(),
        "total_guarantors": Guarantor.objects.filter(is_active=True).count(),
        "total_branches": Branch.objects.filter(is_active=True).count(),
        "settings":       CompanySettings.get(),
        "recent_users":   User.objects.order_by("-date_joined")[:5],
        "recent_loans":   Loan.objects.select_related("client").order_by("-created_at")[:5],
    }
    return render(request, "accounts/admin_dashboard.html", context)


@_permission_required("can_view_financial_overview")
def financial_overview(request):
    """CEO-only financial overview: disbursements, repayments, expenses, injections."""
    from django.db.models import Sum
    period = request.GET.get("period", "30")
    try:
        days = int(period)
    except Exception:
        days = 30

    today = timezone.localdate()
    start_date = today - relativedelta(days=days)

    movement = cash_movement(user=request.user, start_date=start_date, end_date=today)
    disbursed = movement["disbursements"]
    repayments = movement["payments"]
    expenses = movement["expenses"]
    injections = movement["injections"]
    net_cash = movement["cash_at_hand"]

    # Allow CSV export of ledger rows for the period
    if request.GET.get("export") == "csv":
        import csv
        from django.http import HttpResponse

        rows = []
        for l in Loan.objects.filter(disbursement_date__gte=start_date, disbursement_date__lte=today).order_by("disbursement_date"):
            rows.append((l.disbursement_date, "Disbursement", l.loan_number or "", float(l.principal_amount)))
        for p in Payment.objects.cash_receipts().filter(payment_date__gte=start_date, payment_date__lte=today, status="ALLOCATED", payment_method=Payment.PaymentMethod.CASH).order_by("payment_date"):
            rows.append((p.payment_date, "Repayment", p.loan.loan_number if p.loan else "", float(p.amount_received)))
        for e in Expense.objects.filter(expense_date__gte=start_date, expense_date__lte=today, status=Expense.Status.APPROVED, payment_method=Expense.PaymentMethod.CASH).order_by("expense_date"):
            rows.append((e.expense_date, "Expense", e.reference_number or "", float(e.amount)))
        for ci in CapitalInjection.objects.filter(injected_date__gte=start_date, injected_date__lte=today, payment_method=CapitalInjection.PaymentMethod.CASH).order_by("injected_date"):
            rows.append((ci.injected_date, "Injection", ci.source, float(ci.amount)))

        rows.sort(key=lambda r: r[0])

        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = f"attachment; filename=financials_{start_date}_{today}.csv"
        writer = csv.writer(response)
        writer.writerow(["date", "type", "reference", "amount"])
        for r in rows:
            date_val = r[0].isoformat() if hasattr(r[0], "isoformat") else r[0]
            writer.writerow([date_val, r[1], r[2], f"{r[3]:.2f}"])
        return response

    context = {
        "disbursed": disbursed,
        "repayments": repayments,
        "expenses": expenses,
        "injections": injections,
        "net_cash": net_cash,
        "start_date": start_date,
        "end_date": today,
        "period": days,
    }
    return render(request, "accounts/admin_financials.html", context)


# ------------------------------------------------------------------ #
# User Management                                                      #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_users")
def user_list(request):
    qs = User.objects.select_related("branch").order_by("role", "first_name")
    q  = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(first_name__icontains=q) | Q(last_name__icontains=q) | Q(email__icontains=q))
    role = request.GET.get("role", "")
    if role:
        qs = qs.filter(role=role)
    branch = request.GET.get("branch", "")
    if branch:
        qs = qs.filter(branch_id=branch)

    # Pagination
    paginator = Paginator(qs, 25)
    page = request.GET.get("page", 1)
    users = paginator.get_page(page)

    return render(request, "accounts/user_list.html", {
        "users":       users,
        "q":           q,
        "role_filter": role,
        "branch_filter": branch,
        "role_choices": User.Role.choices,
        "branches": Branch.objects.filter(is_active=True),
    })


@_permission_required("can_manage_users")
def user_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            if User.objects.filter(username=d["username"].strip()).exists():
                raise ValueError("Username already taken.")
            if User.objects.filter(email=d["email"].strip()).exists():
                raise ValueError("Email already registered.")
            if d["password1"] != d["password2"]:
                raise ValueError("Passwords do not match.")
            signature = _validated_signature_upload(request.FILES.get("signature"))
            user = User.objects.create(
                username   = d["username"].strip(),
                first_name = d["first_name"].strip(),
                last_name  = d["last_name"].strip(),
                email      = d["email"].strip(),
                phone      = d.get("phone", "").strip(),
                role       = d["role"],
                branch_id  = d.get("branch") or get_single_active_branch_id(),
                commission_rate = d.get("commission_rate", "0.00"),
                is_active  = True,
                signature = signature,
                password   = make_password(d["password1"]),
            )
            log_action(request.user, AuditLog.Action.CREATE, user, request=request,
                       changes={"role": user.role, "email": user.email},
                       remarks=f"User {user.full_name} created")
            messages.success(request, f"User {user.full_name} created successfully.")
            return redirect("accounts:user_list")
        except Exception as e:
            messages.error(request, str(e))

    return render(request, "accounts/user_form.html", {
        "title":       "Add New User",
        "action":      "create",
        "role_choices": User.Role.choices,
        "branches": Branch.objects.filter(is_active=True),
        "selected_branch_id": (
            request.POST.get("branch") or get_single_active_branch_id()
        ),
    })


@_permission_required("can_manage_users")
def user_edit(request, pk):
    staff = get_object_or_404(User, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            # Never leave the organisation without an active CEO.
            new_role = d["role"]
            stays_active_ceo = new_role == "CEO" and d.get("is_active") == "on"
            if staff.role == "CEO" and not stays_active_ceo:
                if not User.objects.filter(role="CEO", is_active=True).exclude(pk=staff.pk).exists():
                    raise ValueError("You can't demote or deactivate the only active CEO. Make someone else CEO first.")
            staff.first_name = d["first_name"].strip()
            staff.last_name  = d["last_name"].strip()
            staff.email      = d["email"].strip()
            staff.phone      = d.get("phone", "").strip()
            staff.role       = d["role"]
            if staff.role != "CEO":
                # Superuser bypasses every permission check; only CEOs may hold it.
                staff.is_superuser = False
            staff.branch_id  = d.get("branch") or None
            staff.commission_rate = d.get("commission_rate", "0.00")
            staff.is_active  = d.get("is_active") == "on"
            signature = _validated_signature_upload(request.FILES.get("signature"))
            old_signature_name = None
            if signature:
                old_signature_name = staff.signature.name if staff.signature else None
                staff.signature = signature
            elif d.get("remove_signature") == "on" and staff.signature:
                old_signature_name = staff.signature.name
                staff.signature = None
            # Only change password if provided
            if d.get("password1"):
                if d["password1"] != d["password2"]:
                    raise ValueError("Passwords do not match.")
                staff.password = make_password(d["password1"])
            staff.save()

            # Per-user extra permissions, on top of whatever their role's
            # Group already grants. Only a user with can_manage_permissions
            # can grant/revoke these — user_edit itself only needs
            # can_manage_users, so re-check here before touching anything.
            if request.user.can("can_manage_permissions"):
                from django.contrib.auth.models import Permission, Group
                selected = set(d.getlist("extra_permissions"))
                all_codenames = {codename for codename, _label, _groups in PERMISSIONS}
                valid_selected = selected & all_codenames
                perms_qs = Permission.objects.filter(
                    content_type__app_label="accounts", codename__in=all_codenames
                )
                to_grant = perms_qs.filter(codename__in=valid_selected)
                to_revoke = perms_qs.exclude(codename__in=valid_selected)
                staff.user_permissions.remove(*to_revoke)
                staff.user_permissions.add(*to_grant)

                # Custom (non-built-in) group memberships — e.g. a role
                # like "Loan Officer" created on the Roles & Permissions
                # page. Built-in role membership (Cashier/Manager/CEO) is
                # NOT touched here — that's driven entirely by the `role`
                # field above via accounts.signals.sync_role_group.
                custom_group_ids = set(d.getlist("extra_groups"))
                custom_groups_qs = Group.objects.exclude(name__in=ALL_GROUPS)
                selected_custom = custom_groups_qs.filter(pk__in=custom_group_ids)
                unselected_custom = custom_groups_qs.exclude(pk__in=custom_group_ids)
                staff.groups.remove(*unselected_custom)
                staff.groups.add(*selected_custom)

            log_action(request.user, AuditLog.Action.UPDATE, staff, request=request,
                       changes={"role": staff.role, "is_active": staff.is_active},
                       remarks=f"User {staff.full_name} updated")
            if old_signature_name:
                staff._meta.get_field("signature").storage.delete(old_signature_name)
            messages.success(request, f"User {staff.full_name} updated.")
            return redirect("accounts:user_list")
        except Exception as e:
            messages.error(request, str(e))

    # Group-granted permissions (from their role) vs their own extra grants,
    # so the template can show "already have this via role" separately from
    # "extra, granted specifically to this person".
    group_codenames = set(
        staff.groups.filter(name__in=["Cashier", "Manager", "CEO"])
        .values_list("permissions__codename", flat=True)
    ) - {None}
    own_codenames = set(staff.user_permissions.values_list("codename", flat=True))

    from django.contrib.auth.models import Group
    custom_groups = Group.objects.exclude(name__in=ALL_GROUPS).order_by("name")
    staff_custom_group_ids = set(
        staff.groups.exclude(name__in=ALL_GROUPS).values_list("pk", flat=True)
    )

    return render(request, "accounts/user_form.html", {
        "title":       f"Edit — {staff.full_name}",
        "action":      "edit",
        "staff":       staff,
        "role_choices": User.Role.choices,
        "branches": Branch.objects.filter(is_active=True),
        "can_manage_permissions": request.user.can("can_manage_permissions"),
        "all_permissions": PERMISSIONS,
        "group_codenames": group_codenames,
        "own_codenames": own_codenames,
        "custom_groups": custom_groups,
        "staff_custom_group_ids": staff_custom_group_ids,
    })


@_ceo_required
@require_POST
def user_toggle_active(request, pk):
    staff = get_object_or_404(User, pk=pk)
    if staff == request.user:
        messages.error(request, "You cannot deactivate your own account.")
        return redirect("accounts:user_list")
    staff.is_active = not staff.is_active
    staff.save()
    state = "activated" if staff.is_active else "deactivated"
    messages.success(request, f"{staff.full_name} has been {state}.")
    return redirect("accounts:user_list")


# ------------------------------------------------------------------ #
# Branch Management                                                    #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_branches")
def branch_list(request):
    qs = Branch.objects.annotate(
        staff_count=Count("staff_members", filter=Q(staff_members__is_active=True)),
        active_loans=Count("loans", filter=Q(loans__status__in=["ACTIVE", "RESTRUCTURED"])),
    ).order_by("name")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(code__icontains=q))

    return render(request, "accounts/branch_list.html", {
        "branches": qs,
        "q": q,
    })


@_permission_required("can_manage_branches")
def branch_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            if Branch.objects.filter(code=d["code"].strip().upper()).exists():
                raise ValueError("Branch code already exists.")
            branch = Branch.objects.create(
                name=d["name"].strip(),
                code=d["code"].strip().upper(),
                address=d.get("address", "").strip(),
                phone=d.get("phone", "").strip(),
                email=d.get("email", "").strip(),
                manager_id=d.get("manager") or None,
                approval_limit=d.get("approval_limit", "10000000"),
                is_active=True,
            )
            messages.success(request, f"Branch '{branch.name}' created.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:branch_list")
        except Exception as e:
            messages.error(request, f"Could not create branch: {e}")

    return render(request, "accounts/branch_form.html", {
        "title": "Create Branch",
        "action": "create",
        "managers": User.objects.filter(is_active=True).order_by("first_name", "last_name", "username"),
    })


@_permission_required("can_manage_branches")
def branch_edit(request, pk):
    branch = get_object_or_404(Branch, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            branch.name = d["name"].strip()
            branch.code = d["code"].strip().upper()
            branch.address = d.get("address", "").strip()
            branch.phone = d.get("phone", "").strip()
            branch.email = d.get("email", "").strip()
            branch.manager_id = d.get("manager") or None
            branch.approval_limit = d.get("approval_limit", "10000000")
            branch.is_active = d.get("is_active") == "on"
            branch.save()
            messages.success(request, f"Branch '{branch.name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:branch_list")
        except Exception as e:
            messages.error(request, f"Could not update branch: {e}")

    return render(request, "accounts/branch_form.html", {
        "title": f"Edit Branch — {branch.name}",
        "action": "edit",
        "branch": branch,
        "managers": User.objects.filter(is_active=True).order_by("first_name", "last_name", "username"),
    })


@_permission_required("can_manage_branches")
def branch_detail(request, pk):
    """CEO-only detail/summary page for a single branch."""
    branch = get_object_or_404(Branch, pk=pk)
    from datetime import date
    today = date.today()
    month_start = today.replace(day=1)

    staff = User.objects.filter(branch=branch, is_active=True).order_by("first_name", "last_name", "username")

    active_loans = Loan.objects.filter(branch=branch, status__in=["ACTIVE", "RESTRUCTURED"])
    portfolio_amount    = active_loans.aggregate(t=Sum("principal_amount"))["t"] or Decimal("0")
    portfolio_outstanding = active_loans.aggregate(t=Sum("outstanding_balance"))["t"] or Decimal("0")
    active_loan_count   = active_loans.count()
    client_count        = Client.objects.filter(branch=branch, is_active=True).count()

    pending_loans = Loan.objects.filter(branch=branch, status="PENDING").select_related("client", "product").order_by("application_date")[:10]

    overdue_schedules = LoanSchedule.objects.filter(
        due_date__lt=today,
        status__in=["PENDING", "OVERDUE", "PARTIAL"],
        loan__branch=branch,
        loan__status__in=["ACTIVE", "RESTRUCTURED"],
    ).select_related("loan__client").order_by("due_date")[:20]
    overdue_count = LoanSchedule.objects.filter(
        due_date__lt=today, status__in=["PENDING", "OVERDUE", "PARTIAL"],
        loan__branch=branch, loan__status__in=["ACTIVE", "RESTRUCTURED"],
    ).count()

    par_30_count = active_loans.filter(
        schedule__due_date__lt=today,
        schedule__status__in=["PENDING", "OVERDUE", "PARTIAL"],
    ).distinct().count()

    collected_month = Payment.objects.cash_receipts().filter(
        loan__branch=branch, payment_date__gte=month_start, status="ALLOCATED",
    ).aggregate(t=Sum("amount_received"))["t"] or Decimal("0")

    expenses_month = Expense.objects.filter(
        branch=branch, expense_date__gte=month_start, status="APPROVED",
    ).aggregate(t=Sum("amount"))["t"] or Decimal("0")

    written_off_count = Loan.objects.filter(branch=branch, status="WRITTEN_OFF").count()

    staff_performance = []
    for s in staff:
        if s.is_ceo:
            continue
        applied_loans = Loan.objects.filter(applied_by=s)
        collections_this_month = Payment.objects.cash_receipts().filter(
            recorded_by=s, payment_date__gte=month_start, status="ALLOCATED",
        ).aggregate(total=Sum("amount_received"))["total"] or Decimal("0")
        staff_performance.append({
            "user": s,
            "applications_count": applied_loans.count(),
            "active_loans_count": applied_loans.filter(status__in=["ACTIVE", "RESTRUCTURED"]).count(),
            "collections_this_month": collections_this_month,
        })

    return render(request, "accounts/branch_detail.html", {
        "branch": branch,
        "today": today,
        "staff": staff,
        "staff_performance": staff_performance,
        "portfolio_amount": portfolio_amount,
        "portfolio_outstanding": portfolio_outstanding,
        "active_loan_count": active_loan_count,
        "client_count": client_count,
        "pending_loans": pending_loans,
        "overdue_schedules": overdue_schedules,
        "overdue_count": overdue_count,
        "par_30_count": par_30_count,
        "collected_month": collected_month,
        "expenses_month": expenses_month,
        "written_off_count": written_off_count,
    })


# ------------------------------------------------------------------ #
# Fee Type Management                                                  #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_loan_products")
def fee_type_list(request):
    qs = FeeType.objects.all().order_by("name")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(name__icontains=q) | Q(description__icontains=q))

    applied_to = request.GET.get("applied_to", "")
    if applied_to:
        qs = qs.filter(applied_to=applied_to)

    processing_fee_search_text = (
        "processing fee loan disbursement system-managed "
        "automatically calculated from company settings"
    )
    return render(request, "accounts/fee_type_list.html", {
        "fee_types": qs,
        "q": q,
        "applied_to_filter": applied_to,
        "applied_to_choices": FeeType.AppliedTo.choices,
        "processing_fee_settings": CompanySettings.get(),
        "show_processing_fee": (
            (not applied_to or applied_to == FeeType.AppliedTo.LOAN_DISBURSEMENT)
            and (not q or q.casefold() in processing_fee_search_text)
        ),
    })


@_permission_required("can_manage_loan_products")
def fee_type_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            fee = FeeType.objects.create(
                name=d["name"].strip(),
                description=d.get("description", "").strip(),
                applied_to=d["applied_to"],
                calculation_method=d["calculation_method"],
                amount=d.get("amount", "0"),
                is_active=d.get("is_active") == "on",
                is_mandatory=d.get("is_mandatory") == "on",
                min_amount=d.get("min_amount", "0"),
                max_amount=d.get("max_amount", "0"),
            )
            messages.success(request, f"Fee type '{fee.name}' created.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:fee_type_list")
        except Exception as e:
            messages.error(request, f"Could not create fee type: {e}")

    return render(request, "accounts/fee_type_form.html", {
        "title": "Create Fee Type",
        "action": "create",
        "calculation_choices": FeeType.CalculationMethod.choices,
        "applied_to_choices": FeeType.AppliedTo.choices,
    })


@_permission_required("can_manage_loan_products")
def fee_type_edit(request, pk):
    fee_type = get_object_or_404(FeeType, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            fee_type.name = d["name"].strip()
            fee_type.description = d.get("description", "").strip()
            fee_type.applied_to = d["applied_to"]
            fee_type.calculation_method = d["calculation_method"]
            fee_type.amount = d.get("amount", "0")
            fee_type.is_active = d.get("is_active") == "on"
            fee_type.is_mandatory = d.get("is_mandatory") == "on"
            fee_type.min_amount = d.get("min_amount", "0")
            fee_type.max_amount = d.get("max_amount", "0")
            fee_type.save()
            messages.success(request, f"Fee type '{fee_type.name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:fee_type_list")
        except Exception as e:
            messages.error(request, f"Could not update fee type: {e}")

    return render(request, "accounts/fee_type_form.html", {
        "title": f"Edit Fee Type — {fee_type.name}",
        "action": "edit",
        "fee_type": fee_type,
        "calculation_choices": FeeType.CalculationMethod.choices,
        "applied_to_choices": FeeType.AppliedTo.choices,
    })


# ------------------------------------------------------------------ #
# Holiday Management                                                   #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_system_settings")
def holiday_list(request):
    qs = Holiday.objects.all().order_by("-date")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(Q(name__icontains=q))

    return render(request, "accounts/holiday_list.html", {
        "holidays": qs,
        "q": q,
    })


@_permission_required("can_manage_system_settings")
def holiday_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            holiday = Holiday.objects.create(
                name=d["name"].strip(),
                date=d["date"],
                is_recurring=d.get("is_recurring") == "on",
                description=d.get("description", "").strip(),
                is_active=d.get("is_active") == "on",
            )
            messages.success(request, f"Holiday '{holiday.name}' created.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:holiday_list")
        except Exception as e:
            messages.error(request, f"Could not create holiday: {e}")

    return render(request, "accounts/holiday_form.html", {
        "title": "Create Holiday",
        "action": "create",
    })


@_permission_required("can_manage_system_settings")
def holiday_edit(request, pk):
    holiday = get_object_or_404(Holiday, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            holiday.name = d["name"].strip()
            holiday.date = d["date"]
            holiday.is_recurring = d.get("is_recurring") == "on"
            holiday.description = d.get("description", "").strip()
            holiday.is_active = d.get("is_active") == "on"
            holiday.save()
            messages.success(request, f"Holiday '{holiday.name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:holiday_list")
        except Exception as e:
            messages.error(request, f"Could not update holiday: {e}")

    return render(request, "accounts/holiday_form.html", {
        "title": f"Edit Holiday — {holiday.name}",
        "action": "edit",
        "holiday": holiday,
    })


# ------------------------------------------------------------------ #
# Company Settings                                                     #
# ------------------------------------------------------------------ #

def _skip_penalty_periods_through_today(settings_obj):
    today = timezone.localdate()
    schedules = LoanSchedule.objects.filter(
        loan__status__in=(Loan.Status.ACTIVE, Loan.Status.RESTRUCTURED),
        status__in=(
            LoanSchedule.Status.PENDING,
            LoanSchedule.Status.OVERDUE,
            LoanSchedule.Status.PARTIAL,
        ),
    ).select_related("loan")

    for schedule in schedules.iterator(chunk_size=500):
        days_overdue = max(
            (today - schedule.due_date).days - settings_obj.grace_period_days,
            0,
        )
        current_period = penalty_periods_elapsed(
            days_overdue,
            schedule.loan.penalty_frequency,
        )
        if current_period > schedule.penalty_periods_processed:
            schedule.penalty_periods_processed = current_period
            schedule.save(update_fields=["penalty_periods_processed"])


@_permission_required("can_manage_company_settings")
def company_settings(request):
    settings_obj = CompanySettings.get()

    if request.method == "POST":
        d = request.POST
        try:
            previous_penalties_enabled = settings_obj.penalties_enabled
            # Company Information
            settings_obj.company_name           = d["company_name"].strip()
            settings_obj.company_address        = d.get("company_address", "").strip()
            settings_obj.company_phone          = d.get("company_phone", "").strip()
            settings_obj.company_email          = d.get("company_email", "").strip()
            settings_obj.company_website        = d.get("company_website", "").strip()
            settings_obj.company_registration   = d.get("company_registration", "").strip()
            settings_obj.tax_identification     = d.get("tax_identification", "").strip()
            settings_obj.currency_symbol        = d.get("currency_symbol", "UGX").strip() or "UGX"
            settings_obj.loan_terms_and_conditions = sanitize_loan_terms(
                d.get("loan_terms_and_conditions", "")
            )

            def _dec(key, default):
                v = d.get(key, "").strip()
                return v if v else default

            def _int(key, default):
                v = d.get(key, "").strip()
                return int(v) if v else default

            def _disbursement_limit(key):
                value = Decimal(_dec(key, "0"))
                if value < 0:
                    raise ValueError(f"{key.replace('_', ' ').capitalize()} cannot be negative.")
                return value

            def _disbursement_scope(key):
                value = d.get(key, "ALL")
                if value not in dict(CompanySettings.DisbursementLimitScope.choices):
                    raise ValueError(f"Invalid staff scope for {key.replace('_', ' ')}.")
                return value

            # Loan Business Rules
            settings_obj.manager_approval_limit = _dec("manager_approval_limit", "5000000")
            settings_obj.penalties_enabled      = d.get("penalties_enabled") == "on"
            penalty_frequency = d.get(
                "penalty_frequency",
                CompanySettings.PenaltyFrequency.MONTHLY,
            )
            if penalty_frequency not in CompanySettings.PenaltyFrequency.values:
                raise ValueError("Select a valid penalty frequency.")
            settings_obj.penalty_frequency    = penalty_frequency
            settings_obj.default_penalty_rate   = _dec("default_penalty_rate", "2")
            settings_obj.income_multiplier      = _dec("income_multiplier", "3")
            settings_obj.collateral_haircut     = _dec("collateral_haircut", "50")

            # Disbursement Limits
            settings_obj.daily_disbursement_limit = _disbursement_limit("daily_disbursement_limit")
            settings_obj.daily_disbursement_limit_scope = _disbursement_scope("daily_disbursement_limit_scope")
            settings_obj.weekly_disbursement_limit = _disbursement_limit("weekly_disbursement_limit")
            settings_obj.weekly_disbursement_limit_scope = _disbursement_scope("weekly_disbursement_limit_scope")
            settings_obj.monthly_disbursement_limit = _disbursement_limit("monthly_disbursement_limit")
            settings_obj.monthly_disbursement_limit_scope = _disbursement_scope("monthly_disbursement_limit_scope")

            # Fee Settings
            settings_obj.default_processing_fee_percent  = _dec("default_processing_fee_percent", "1")
            settings_obj.processing_fee_method           = d.get("processing_fee_method", "PERCENTAGE")
            settings_obj.processing_fee_ranges           = d.get("processing_fee_ranges", "").strip()
            settings_obj.early_repayment_penalty_percent = _dec("early_repayment_penalty_percent", "0")
            settings_obj.loan_restructure_fee            = _dec("loan_restructure_fee", "10000")
            settings_obj.max_active_loans_per_client     = _int("max_active_loans_per_client", 3)

            # SMS Settings
            settings_obj.sms_reminders_enabled  = d.get("sms_reminders_enabled") == "on"
            settings_obj.reminder_days_before   = _int("reminder_days_before", 3)
            settings_obj.sms_sender_id          = d.get("sms_sender_id", "ABA Uganda").strip() or "ABA Uganda"

            # Due Date Settings
            settings_obj.adjust_due_dates_for_holidays = d.get("adjust_due_dates_for_holidays") == "on"
            settings_obj.grace_period_days      = _int("grace_period_days", 3)

            # Savings Settings
            settings_obj.savings_enabled             = d.get("savings_enabled") == "on"
            settings_obj.default_savings_interest_rate = _dec("default_savings_interest_rate", "3")
            settings_obj.minimum_savings_balance     = _dec("minimum_savings_balance", "10000")

            # Share Settings
            settings_obj.shares_enabled      = d.get("shares_enabled") == "on"
            settings_obj.share_price         = _dec("share_price", "50000")
            settings_obj.minimum_shares      = _int("minimum_shares", 10)
            settings_obj.maximum_shares      = _int("maximum_shares", 1000)
            settings_obj.dividend_frequency  = d.get("dividend_frequency", "ANNUALLY")

            # Risk Management
            settings_obj.max_portfolio_at_risk_percent = _dec("max_portfolio_at_risk_percent", "5")
            settings_obj.auto_write_off_days           = _int("auto_write_off_days", 180)

            settings_obj.updated_by             = request.user
            if request.FILES.get("company_logo"):
                settings_obj.company_logo = request.FILES["company_logo"]
            with transaction.atomic():
                settings_obj.save()
                if previous_penalties_enabled != settings_obj.penalties_enabled:
                    _skip_penalty_periods_through_today(settings_obj)
            log_action(request.user, AuditLog.Action.UPDATE, settings_obj, request=request,
                       changes={"company_name": settings_obj.company_name},
                       remarks="Company settings updated")
            messages.success(request, "Company settings saved.")
            return redirect("accounts:company_settings")
        except Exception as e:
            messages.error(request, f"Error saving settings: {e}")

    disbursement_limit_periods = [
        {
            "key": "daily",
            "label": "Daily",
            "limit": settings_obj.daily_disbursement_limit,
            "scope": settings_obj.daily_disbursement_limit_scope,
        },
        {
            "key": "weekly",
            "label": "Weekly",
            "limit": settings_obj.weekly_disbursement_limit,
            "scope": settings_obj.weekly_disbursement_limit_scope,
        },
        {
            "key": "monthly",
            "label": "Monthly",
            "limit": settings_obj.monthly_disbursement_limit,
            "scope": settings_obj.monthly_disbursement_limit_scope,
        },
    ]
    return render(request, "accounts/company_settings.html", {
        "s": settings_obj,
        "penalty_frequency_choices": CompanySettings.PenaltyFrequency.choices,
        "disbursement_limit_periods": disbursement_limit_periods,
        "disbursement_limit_scopes": CompanySettings.DisbursementLimitScope.choices,
    })


# ------------------------------------------------------------------ #
# Guarantor Management                                                 #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_guarantors")
def guarantor_list(request):
    qs = Guarantor.objects.select_related("verified_by").order_by("-created_at")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(
            Q(first_name__icontains=q) |
            Q(last_name__icontains=q) |
            Q(phone_primary__icontains=q) |
            Q(nin__icontains=q)
        )

    gtype = request.GET.get("type", "")
    if gtype:
        qs = qs.filter(guarantor_type=gtype)

    # Pagination
    paginator = Paginator(qs, 25)
    page = request.GET.get("page", 1)
    guarantors = paginator.get_page(page)

    return render(request, "accounts/guarantor_list.html", {
        "guarantors": guarantors,
        "q": q,
        "type_filter": gtype,
        "type_choices": Guarantor.Type.choices,
    })


@_permission_required("can_manage_guarantors")
def guarantor_detail(request, pk):
    guarantor = get_object_or_404(Guarantor, pk=pk)
    guarantees = guarantor.guarantees.select_related("loan__client").order_by("-created_at")

    return render(request, "accounts/guarantor_detail.html", {
        "guarantor": guarantor,
        "guarantees": guarantees,
    })


@_permission_required("can_manage_guarantors")
def guarantor_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            guarantor = Guarantor.objects.create(
                first_name=d["first_name"].strip(),
                last_name=d["last_name"].strip(),
                other_names=d.get("other_names", "").strip(),
                company_name=d.get("company_name", "").strip(),
                registration_number=d.get("registration_number", "").strip(),
                guarantor_type=d.get("guarantor_type", "INDIVIDUAL"),
                nin=d.get("nin", "").strip().upper(),
                phone_primary=d["phone_primary"].strip(),
                phone_secondary=d.get("phone_secondary", "").strip(),
                email=d.get("email", "").strip(),
                physical_address=d["physical_address"].strip(),
                district=d.get("district", "Kampala").strip(),
                employer_name=d.get("employer_name", "").strip(),
                job_title=d.get("job_title", "").strip(),
                monthly_income=d.get("monthly_income", "0"),
                max_liability=d.get("max_liability", "0"),
                notes=d.get("notes", "").strip(),
            )
            messages.success(request, f"Guarantor '{guarantor.full_name}' created.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:guarantor_detail", pk=guarantor.pk)
        except Exception as e:
            messages.error(request, f"Could not create guarantor: {e}")

    return render(request, "accounts/guarantor_form.html", {
        "title": "Create Guarantor",
        "action": "create",
        "type_choices": Guarantor.Type.choices,
    })


@login_required
def guarantor_create_ajax(request):
    """AJAX endpoint to create a guarantor and return JSON {id, full_name}.
    Allowed for managers and CEOs only (not cashiers).
    """
    if not request.user.can("can_manage_guarantors"):
        return JsonResponse({"error": "Insufficient permissions."}, status=403)

    if request.method != "POST":
        return JsonResponse({"error": "POST required."}, status=400)

    d = request.POST
    try:
        guarantor = Guarantor.objects.create(
            first_name=d.get("first_name", "").strip(),
            last_name=d.get("last_name", "").strip(),
            other_names=d.get("other_names", "").strip(),
            company_name=d.get("company_name", "").strip(),
            registration_number=d.get("registration_number", "").strip(),
            guarantor_type=d.get("guarantor_type", "INDIVIDUAL"),
            nin=d.get("nin", "").strip().upper(),
            phone_primary=d.get("phone_primary", "").strip(),
            phone_secondary=d.get("phone_secondary", "").strip(),
            email=d.get("email", "").strip(),
            physical_address=d.get("physical_address", "").strip(),
            district=d.get("district", "Kampala").strip(),
            employer_name=d.get("employer_name", "").strip(),
            job_title=d.get("job_title", "").strip(),
            monthly_income=d.get("monthly_income", "0") or "0",
            max_liability=d.get("max_liability", "0") or "0",
            notes=d.get("notes", "").strip(),
        )
        return JsonResponse({"id": guarantor.pk, "text": guarantor.full_name})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=400)


@_permission_required("can_manage_guarantors")
def guarantor_edit(request, pk):
    guarantor = get_object_or_404(Guarantor, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            guarantor.first_name = d["first_name"].strip()
            guarantor.last_name = d["last_name"].strip()
            guarantor.other_names = d.get("other_names", "").strip()
            guarantor.company_name = d.get("company_name", "").strip()
            guarantor.registration_number = d.get("registration_number", "").strip()
            guarantor.guarantor_type = d.get("guarantor_type", "INDIVIDUAL")
            guarantor.nin = d.get("nin", "").strip().upper()
            guarantor.phone_primary = d["phone_primary"].strip()
            guarantor.phone_secondary = d.get("phone_secondary", "").strip()
            guarantor.email = d.get("email", "").strip()
            guarantor.physical_address = d["physical_address"].strip()
            guarantor.district = d.get("district", "Kampala").strip()
            guarantor.employer_name = d.get("employer_name", "").strip()
            guarantor.job_title = d.get("job_title", "").strip()
            guarantor.monthly_income = d.get("monthly_income", "0")
            guarantor.max_liability = d.get("max_liability", "0")
            guarantor.notes = d.get("notes", "").strip()

            # Users with verification authority can verify
            if request.user.can("can_verify_guarantors") and d.get("is_verified"):
                guarantor.is_verified = True
                guarantor.verification_date = timezone.localdate()
                guarantor.verified_by = request.user

            guarantor.save()
            messages.success(request, f"Guarantor '{guarantor.full_name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:guarantor_detail", pk=guarantor.pk)
        except Exception as e:
            messages.error(request, f"Could not update guarantor: {e}")

    return render(request, "accounts/guarantor_form.html", {
        "title": f"Edit Guarantor — {guarantor.full_name}",
        "action": "edit",
        "guarantor": guarantor,
        "type_choices": Guarantor.Type.choices,
    })


# ------------------------------------------------------------------ #
# Audit Log                                                            #
# ------------------------------------------------------------------ #

@_permission_required("can_view_audit_log")
def audit_log(request):
    qs = AuditLog.objects.select_related("user").order_by("-created_at")

    entity_type = request.GET.get("entity_type", "").strip()
    if entity_type:
        qs = qs.filter(entity_type__icontains=entity_type)

    action = request.GET.get("action", "")
    if action:
        qs = qs.filter(action=action)

    user_filter = request.GET.get("user", "").strip()
    if user_filter:
        qs = qs.filter(
            Q(user__first_name__icontains=user_filter) |
            Q(user__last_name__icontains=user_filter) |
            Q(user__email__icontains=user_filter)
        )

    date_from = request.GET.get("date_from", "")
    if date_from:
        qs = qs.filter(created_at__date__gte=date_from)

    date_to = request.GET.get("date_to", "")
    if date_to:
        qs = qs.filter(created_at__date__lte=date_to)

    paginator = Paginator(qs, 50)
    logs = paginator.get_page(request.GET.get("page", 1))

    return render(request, "accounts/audit_log.html", {
        "logs": logs,
        "entity_type_filter": entity_type,
        "action_filter": action,
        "user_filter": user_filter,
        "date_from": date_from,
        "date_to": date_to,
        "action_choices": AuditLog.Action.choices,
        "total_count": qs.count(),
    })


# ------------------------------------------------------------------ #
# Roles & Permissions                                                  #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_permissions")
def permissions_manage(request):
    """
    Lets a CEO see/edit which permissions each Group (role) grants, and
    create new custom Groups (e.g. "Senior Cashier", "Loan Officer") with
    their own permission set — without any code change or deploy.

    The three built-in groups (Cashier/Manager/CEO) stay in sync with the
    `role` field on each user via accounts.signals.sync_role_group, so
    editing their permissions here changes what everyone with that role can
    do; custom groups are opt-in per user via the "Extra groups" field on
    their edit page (kept simple for now — group *membership* management
    beyond the built-in three lives on the user's own edit page, this page
    is about what each group *grants*).
    """
    from django.contrib.auth.models import Group, Permission

    if request.method == "POST":
        action = request.POST.get("form_action")

        if action == "create_group":
            name = request.POST.get("new_group_name", "").strip()
            if not name:
                messages.error(request, "Group name is required.")
            elif Group.objects.filter(name=name).exists():
                messages.error(request, f'A group named "{name}" already exists.')
            else:
                Group.objects.create(name=name)
                messages.success(request, f'Group "{name}" created. Set its permissions below.')
            return redirect("accounts:permissions_manage")

        if action == "update_group":
            group_id = request.POST.get("group_id")
            group = get_object_or_404(Group, pk=group_id)
            all_codenames = {codename for codename, _label, _groups in PERMISSIONS}
            selected = set(request.POST.getlist("permissions")) & all_codenames
            perms_qs = Permission.objects.filter(
                content_type__app_label="accounts", codename__in=all_codenames
            )
            group.permissions.set(perms_qs.filter(codename__in=selected))
            messages.success(request, f'Updated permissions for "{group.name}".')
            return redirect("accounts:permissions_manage")

        if action == "delete_group":
            group_id = request.POST.get("group_id")
            group = get_object_or_404(Group, pk=group_id)
            if request.user.role != "CEO":
                messages.error(request, "Only the CEO can delete permission groups.")
            elif group.name in ALL_GROUPS:
                messages.error(request, f'"{group.name}" is a built-in role and can\'t be deleted.')
            else:
                name = group.name
                group.delete()
                messages.success(request, f'Group "{name}" deleted.')
            return redirect("accounts:permissions_manage")

    groups = Group.objects.all().order_by("name").prefetch_related("permissions")
    groups_data = [
        {
            "group": g,
            "is_builtin": g.name in ALL_GROUPS,
            "granted": set(g.permissions.filter(
                content_type__app_label="accounts"
            ).values_list("codename", flat=True)),
            "member_count": g.user_set.count(),
        }
        for g in groups
    ]

    return render(request, "accounts/permissions_manage.html", {
        "groups_data": groups_data,
        "all_permissions": PERMISSIONS,
    })


@_permission_required("can_manage_expense_categories")
def expense_types_list(request):
    """Manage transaction categories and expense types on one page."""
    cat_error = et_error = None

    if request.method == "POST":
        action = request.POST.get("_action", "")
        if action == "save_category":
            name = request.POST.get("name", "").strip()
            if not name:
                cat_error = "Name is required."
            elif TransactionCategory.objects.filter(name__iexact=name).exists():
                cat_error = "Category already exists."
            else:
                TransactionCategory.objects.create(
                    name=name,
                    color=request.POST.get("color", "amber"),
                    description=request.POST.get("description", "").strip(),
                )
                messages.success(request, f"Category '{name}' created.")
                return redirect("accounts:expense_types_list")
        elif action == "save_expense_type":
            cat_id = request.POST.get("category_id", "")
            name   = request.POST.get("name", "").strip()
            if not cat_id or not name:
                et_error = "Category and name are required."
            else:
                try:
                    cat = TransactionCategory.objects.get(pk=cat_id)
                    if ExpenseType.objects.filter(category=cat, name__iexact=name).exists():
                        et_error = "Type already exists in this category."
                    else:
                        ExpenseType.objects.create(
                            category=cat, name=name,
                            description=request.POST.get("description", "").strip(),
                        )
                        messages.success(request, f"Expense type '{name}' created.")
                        return redirect("accounts:expense_types_list")
                except TransactionCategory.DoesNotExist:
                    et_error = "Category not found."
        elif action == "toggle_category":
            cat = get_object_or_404(TransactionCategory, pk=request.POST.get("pk"))
            cat.is_active = not cat.is_active
            cat.save()
            return redirect("accounts:expense_types_list")
        elif action == "toggle_expense_type":
            et = get_object_or_404(ExpenseType, pk=request.POST.get("pk"))
            et.is_active = not et.is_active
            et.save()
            return redirect("accounts:expense_types_list")

    categories = TransactionCategory.objects.prefetch_related("expense_types").order_by("name")
    return render(request, "accounts/expense_types_list.html", {
        "categories": categories,
        "color_choices": ["teal", "amber", "red", "green", "blue", "purple"],
        "cat_error": cat_error,
        "et_error": et_error,
    })


@_permission_required("can_manage_expense_categories")
def transaction_category_create_ajax(request):
    """AJAX: create a TransactionCategory, return {id, name}."""
    if request.method != "POST":
        return JsonResponse({"error": "POST required."}, status=400)
    name = request.POST.get("name", "").strip()
    if not name:
        return JsonResponse({"error": "Name is required."}, status=400)
    if TransactionCategory.objects.filter(name__iexact=name).exists():
        return JsonResponse({"error": "Category already exists."}, status=400)
    cat = TransactionCategory.objects.create(
        name=name,
        description=request.POST.get("description", "").strip(),
        color=request.POST.get("color", "amber"),
    )
    return JsonResponse({"id": cat.pk, "name": cat.name})


@_permission_required("can_manage_expense_categories")
def expense_type_create_ajax(request):
    """AJAX: create an ExpenseType under a category, return {id, name, category_id}."""
    if request.method != "POST":
        return JsonResponse({"error": "POST required."}, status=400)
    category_id = request.POST.get("category_id", "")
    name = request.POST.get("name", "").strip()
    if not category_id or not name:
        return JsonResponse({"error": "Category and name are required."}, status=400)
    try:
        category = TransactionCategory.objects.get(pk=category_id)
    except TransactionCategory.DoesNotExist:
        return JsonResponse({"error": "Category not found."}, status=400)
    if ExpenseType.objects.filter(category=category, name__iexact=name).exists():
        return JsonResponse({"error": "Expense type already exists in this category."}, status=400)
    et = ExpenseType.objects.create(
        category=category,
        name=name,
        description=request.POST.get("description", "").strip(),
    )
    return JsonResponse({"id": et.pk, "name": et.name, "category_id": category.pk})


@_permission_required("can_manage_expense_categories")
def expense_types_for_category(request):
    """AJAX: return expense types for a given category_id."""
    category_id = request.GET.get("category_id", "")
    if not category_id:
        return JsonResponse({"types": []})
    types = list(
        ExpenseType.objects.filter(category_id=category_id, is_active=True)
        .values("id", "name")
    )
    return JsonResponse({"types": types})


# ------------------------------------------------------------------ #
# Expense Management                                                   #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_expenses")
def expense_list(request):
    form_data = {
        "category": "", "expense_type": "", "amount": "",
        "expense_date": timezone.localdate().isoformat(),
        "vendor": "", "payment_method": "CASH", "receipt_number": "", "description": "", "branch": "",
    }
    show_modal = False

    if request.method == "POST":
        d = request.POST
        for k in form_data:
            form_data[k] = d.get(k, form_data[k])
        try:
            from datetime import date as _date
            exp_date = _date.fromisoformat(form_data["expense_date"]) if form_data["expense_date"] else _date.today()
            amount_val = Decimal(str(form_data["amount"] or "0"))
            if amount_val <= 0:
                raise ValueError("Amount must be greater than zero.")
            Expense.objects.create(
                category_id=form_data["category"] or None,
                expense_type_id=form_data["expense_type"] or None,
                branch_id=resolve_branch_for_write(request, form_data["branch"]),
                amount=amount_val,
                expense_date=exp_date,
                vendor=form_data["vendor"],
                payment_method=form_data["payment_method"],
                receipt_number=form_data["receipt_number"],
                description=form_data["description"],
                status="APPROVED",
                approved_by=request.user,
                approved_at=timezone.now(),
                created_by=request.user,
            )
            messages.success(request, "Expense recorded successfully.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:expense_list")
        except Exception as e:
            messages.error(request, f"Could not save expense: {e}")
            show_modal = True

    qs = Expense.objects.select_related("category", "expense_type", "created_by", "branch").order_by("-expense_date")

    category = request.GET.get("category", "")
    if category:
        qs = qs.filter(category_id=category)
    status_f = request.GET.get("status", "")
    if status_f:
        qs = qs.filter(status=status_f)
    date_from = request.GET.get("date_from", "")
    if date_from:
        qs = qs.filter(expense_date__gte=date_from)
    date_to = request.GET.get("date_to", "")
    if date_to:
        qs = qs.filter(expense_date__lte=date_to)

    paginator = Paginator(qs, 25)
    expenses = paginator.get_page(request.GET.get("page", 1))
    total_amount = qs.aggregate(total=Sum("amount"))["total"] or 0
    categories = TransactionCategory.objects.filter(is_active=True).prefetch_related("expense_types")

    return render(request, "accounts/expense_list.html", {
        "expenses": expenses,
        "category_filter": category,
        "status_filter": status_f,
        "date_from": date_from,
        "date_to": date_to,
        "total_amount": total_amount,
        "categories": categories,
        "form_data": form_data,
        "show_modal": show_modal,
        "color_choices": ["teal", "amber", "red", "green", "blue", "purple"],
        "status_choices": Expense.Status.choices,
        "payment_method_choices": Expense.PaymentMethod.choices,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
    })


@_permission_required("can_manage_expenses")
def expense_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            amount_raw = (d.get("amount") or "").strip()
            if not amount_raw:
                raise ValueError("Amount is required.")
            amount_val = Decimal(amount_raw)
            if amount_val <= 0:
                raise ValueError("Amount must be greater than zero.")
            if not d.get("expense_date"):
                raise ValueError("Date is required.")
            from datetime import date as _date
            expense_date = _date.fromisoformat(d["expense_date"])
            expense = Expense.objects.create(
                category_id=d.get("category") or None,
                expense_type_id=d.get("expense_type") or None,
                branch_id=resolve_branch_for_write(request, d.get("branch")),
                amount=amount_val,
                expense_date=expense_date,
                vendor=d.get("vendor", "").strip(),
                payment_method=d.get("payment_method", "CASH"),
                receipt_number=d.get("receipt_number", "").strip(),
                description=d.get("description", "").strip(),
                status="APPROVED",
                approved_by=request.user,
                approved_at=timezone.now(),
                created_by=request.user,
            )
            messages.success(request, f"Expense {expense.reference_number} recorded.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:expense_list")
        except Exception as e:
            messages.error(request, f"Could not create expense: {e}")

    categories = TransactionCategory.objects.filter(is_active=True).prefetch_related("expense_types")
    return render(request, "accounts/expense_form.html", {
        "title": "Record Expense", "action": "create",
        "categories": categories,
        "payment_method_choices": Expense.PaymentMethod.choices,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
    })


@_permission_required("can_manage_expenses")
def expense_edit(request, pk):
    expense = get_object_or_404(Expense, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            amount_raw = (d.get("amount") or "").strip()
            if not amount_raw:
                raise ValueError("Amount is required.")
            amount_val = Decimal(amount_raw)
            if amount_val <= 0:
                raise ValueError("Amount must be greater than zero.")
            if not d.get("expense_date"):
                raise ValueError("Date is required.")
            from datetime import date as _date
            expense.category_id = d.get("category") or None
            expense.expense_type_id = d.get("expense_type") or None
            expense.branch_id = resolve_branch_for_write(request, d.get("branch"))
            expense.amount = amount_val
            expense.expense_date = _date.fromisoformat(d["expense_date"])
            expense.vendor = d.get("vendor", "").strip()
            expense.payment_method = d.get("payment_method", "CASH")
            expense.receipt_number = d.get("receipt_number", "").strip()
            expense.description = d.get("description", "").strip()
            expense.save()
            messages.success(request, "Expense updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:expense_list")
        except Exception as e:
            messages.error(request, f"Could not update expense: {e}")

    categories = TransactionCategory.objects.filter(is_active=True).prefetch_related("expense_types")
    return render(request, "accounts/expense_form.html", {
        "title": "Edit Expense", "action": "edit",
        "expense": expense,
        "categories": categories,
        "payment_method_choices": Expense.PaymentMethod.choices,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
    })


@_ceo_required
def expense_delete(request, pk):
    expense = get_object_or_404(Expense, pk=pk)
    if request.method == "POST":
        expense.delete()
        messages.success(request, "Expense deleted.")
        return redirect("accounts:expense_list")
    return render(request, "accounts/expense_confirm_delete.html", {"expense": expense})


# ------------------------------------------------------------------ #
# Capital Injection Management                                        #
# ------------------------------------------------------------------ #

def _capital_injection_investor_choices():
    registered = list(
        Investor.objects.filter(
            status__in=[Investor.Status.ACTIVE, Investor.Status.PROSPECT]
        ).order_by("name")
    )
    registered_names = {investor.name.casefold() for investor in registered}
    previous_names = []
    for name in CapitalInjection.objects.filter(
        investor_record__isnull=True
    ).exclude(investor="").values_list("investor", flat=True).distinct().order_by("investor"):
        if name.casefold() not in registered_names:
            previous_names.append(name)
    return registered, previous_names


def _resolve_capital_injection_investor(request, data, amount, injected_date, payment_method, branch_id):
    investor_record_id = data.get("investor_record") or ""
    investor_name = data.get("investor", "").strip()
    register_investor = data.get("register_investor") == "1"

    if investor_record_id == "new":
        investor_record_id = ""
        if not investor_name:
            raise ValueError("Enter the new investor's name before recording the injection.")

    if investor_record_id.startswith("legacy:"):
        investor_name = investor_record_id[7:].strip()
        investor_record_id = ""

    if register_investor and investor_name and not investor_record_id:
        investor = Investor.objects.filter(name__iexact=investor_name).first()
        if investor is None:
            investor = Investor.objects.create(
                name=investor_name,
                committed_amount=amount,
                investment_date=injected_date,
                payment_method=payment_method,
                phone=data.get("new_investor_phone", "").strip(),
                email=data.get("new_investor_email", "").strip(),
                branch_id=branch_id,
                created_by=request.user,
            )
        investor_record_id = investor.pk
        investor_name = ""

    return investor_record_id or None, investor_name


def _capital_injection_interest(data, existing=None):
    attracts_interest = data.get("attracts_interest") == "1"
    if not attracts_interest:
        return False, Decimal("0")
    if existing and existing.attracts_interest and existing.interest_rate_annual:
        return True, existing.interest_rate_annual
    return True, CompanySettings.get().default_savings_interest_rate


@_permission_required("can_manage_capital")
def capital_injection_list(request):
    qs = CapitalInjection.objects.select_related("created_by", "investor_record").order_by("-injected_date")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(
            Q(source__icontains=q)
            | Q(investor__icontains=q)
            | Q(investor_record__name__icontains=q)
        )

    date_from = request.GET.get("date_from", "")
    if date_from:
        qs = qs.filter(injected_date__gte=date_from)

    date_to = request.GET.get("date_to", "")
    if date_to:
        qs = qs.filter(injected_date__lte=date_to)

    # Pagination
    paginator = Paginator(qs, 25)
    page = request.GET.get("page", 1)
    injections = paginator.get_page(page)

    total_amount = qs.aggregate(total=Sum("amount"))["total"] or 0

    return render(request, "accounts/capital_injection_list.html", {
        "injections": injections,
        "q": q,
        "date_from": date_from,
        "date_to": date_to,
        "total_amount": total_amount,
    })


@_permission_required("can_manage_capital")
def capital_injection_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            amount_value = d.get("amount", "")
            payment_method = d.get("payment_method", CapitalInjection.PaymentMethod.CASH)
            branch_id = resolve_branch_for_write(request, d.get("branch"))
            with transaction.atomic():
                investor_record_id, investor_name = _resolve_capital_injection_investor(
                    request, d, amount_value, d["injected_date"], payment_method, branch_id
                )
                attracts_interest, interest_rate_annual = _capital_injection_interest(d)
                injection = CapitalInjection.objects.create(
                    source=d["source"].strip(),
                    amount=amount_value,
                    injected_date=d["injected_date"],
                    payment_method=payment_method,
                    branch_id=branch_id,
                    investor_record_id=investor_record_id,
                    investor=investor_name,
                    attracts_interest=attracts_interest,
                    interest_rate_annual=interest_rate_annual,
                    notes=d.get("notes", "").strip(),
                    created_by=request.user,
                )
            amount_display = f"{injection.amount:,.2f}".rstrip("0").rstrip(".") if hasattr(injection.amount, "quantize") else str(injection.amount)
            messages.success(request, f"Capital injection recorded: UGX {amount_display} from {injection.source}")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:capital_injection_list")
        except Exception as e:
            messages.error(request, f"Could not create capital injection: {e}")

    investors, previous_investors = _capital_injection_investor_choices()
    return render(request, "accounts/capital_injection_form.html", {
        "title": "Record Capital Injection",
        "action": "create",
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "investors": investors,
        "previous_investors": previous_investors,
        "default_savings_interest_rate": CompanySettings.get().default_savings_interest_rate,
    })


@_permission_required("can_manage_capital")
def capital_injection_edit(request, pk):
    injection = get_object_or_404(CapitalInjection, pk=pk)

    if request.method == "POST":
        d = request.POST
        try:
            injection.source = d["source"].strip()
            injection.amount = d["amount"]
            injection.injected_date = d["injected_date"]
            injection.payment_method = d.get("payment_method", CapitalInjection.PaymentMethod.CASH)
            injection.branch_id = resolve_branch_for_write(request, d.get("branch"))
            investor_record_id, investor_name = _resolve_capital_injection_investor(
                request,
                d,
                d["amount"],
                d["injected_date"],
                injection.payment_method,
                injection.branch_id,
            )
            injection.investor_record_id = investor_record_id
            injection.investor = investor_name
            injection.attracts_interest, injection.interest_rate_annual = _capital_injection_interest(d, injection)
            injection.notes = d.get("notes", "").strip()
            injection.save()
            messages.success(request, f"Capital injection updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:capital_injection_list")
        except Exception as e:
            messages.error(request, f"Could not update capital injection: {e}")

    investors, previous_investors = _capital_injection_investor_choices()
    return render(request, "accounts/capital_injection_form.html", {
        "title": f"Edit Capital Injection — {injection.source}",
        "action": "edit",
        "injection": injection,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "investors": investors,
        "previous_investors": previous_investors,
        "default_savings_interest_rate": CompanySettings.get().default_savings_interest_rate,
    })


@_ceo_required
def capital_injection_delete(request, pk):
    injection = get_object_or_404(CapitalInjection, pk=pk)
    if request.method == "POST":
        injection.delete()
        messages.success(request, "Capital injection deleted.")
        return redirect("accounts:capital_injection_list")
    return render(request, "accounts/capital_injection_confirm_delete.html", {"injection": injection})


# ------------------------------------------------------------------ #
# Investor Management                                                  #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_investors")
def investor_list(request):
    qs = Investor.objects.select_related("branch", "created_by").order_by("name")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(
            Q(name__icontains=q)
            | Q(phone__icontains=q)
            | Q(email__icontains=q)
            | Q(national_id__icontains=q)
        )

    investor_type = request.GET.get("investor_type", "")
    if investor_type:
        qs = qs.filter(investor_type=investor_type)
    status = request.GET.get("status", "")
    if status:
        qs = qs.filter(status=status)
    branch = request.GET.get("branch", "")
    if branch:
        qs = qs.filter(branch_id=branch)
    date_from = request.GET.get("date_from", "")
    if date_from:
        qs = qs.filter(investment_date__gte=date_from)
    date_to = request.GET.get("date_to", "")
    if date_to:
        qs = qs.filter(investment_date__lte=date_to)

    if request.GET.get("export") == "csv":
        import csv

        response = HttpResponse(content_type="text/csv")
        response["Content-Disposition"] = "attachment; filename=investors.csv"
        writer = csv.writer(response)
        writer.writerow([
            "name", "investor_type", "phone", "email", "national_id", "address",
            "committed_amount", "investment_date", "maturity_date",
            "payment_method", "status", "branch", "notes",
        ])
        for investor in qs:
            writer.writerow([
                investor.name,
                investor.get_investor_type_display(),
                investor.phone,
                investor.email,
                investor.national_id,
                investor.address,
                f"{investor.committed_amount:.2f}",
                investor.investment_date.isoformat() if investor.investment_date else "",
                investor.maturity_date.isoformat() if investor.maturity_date else "",
                investor.get_payment_method_display(),
                investor.get_status_display(),
                investor.branch.name if investor.branch else "",
                investor.notes,
            ])
        return response

    investors = Paginator(qs, 25).get_page(request.GET.get("page", 1))
    totals = qs.aggregate(total=Sum("committed_amount"), count=Count("id"))
    return render(request, "accounts/investor_list.html", {
        "investors": investors,
        "total_amount": totals["total"] or 0,
        "total_count": totals["count"],
        "q": q,
        "investor_type": investor_type,
        "status": status,
        "branch": branch,
        "date_from": date_from,
        "date_to": date_to,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "investor_type_choices": Investor.InvestorType.choices,
        "status_choices": Investor.Status.choices,
    })


def _investor_statement(investor):
    injections = list(investor.capital_injections.order_by("-injected_date", "-created_at"))
    drawings = list(investor.drawings.order_by("-drawing_date", "-created_at"))
    total_injected = sum((item.amount for item in injections), Decimal("0"))
    total_drawn = sum((item.amount for item in drawings), Decimal("0"))
    today = timezone.localdate()
    interest_total = Decimal("0")
    for injection in injections:
        if injection.attracts_interest and injection.interest_rate_annual:
            days = max((today - injection.injected_date).days, 0)
            interest_total += (
                injection.amount
                * injection.interest_rate_annual
                / Decimal("100")
                * Decimal(days)
                / Decimal("365")
            )
    return {
        "injections": injections,
        "drawings": drawings,
        "total_injected": total_injected,
        "total_drawn": total_drawn,
        "interest_total": interest_total.quantize(Decimal("0.01")),
        "balance": total_injected - total_drawn,
    }


@_permission_required("can_manage_investors")
def investor_detail(request, pk):
    investor = get_object_or_404(
        Investor.objects.select_related("branch", "created_by"), pk=pk
    )
    return render(request, "accounts/investor_detail.html", {
        "investor": investor,
        **_investor_statement(investor),
        "company_settings": CompanySettings.get(),
    })


@_permission_required("can_manage_investors")
def investor_drawing_create(request, pk):
    investor = get_object_or_404(Investor, pk=pk)
    if request.method == "POST":
        d = request.POST
        try:
            InvestorDrawing.objects.create(
                investor=investor,
                amount=d["amount"],
                drawing_date=d["drawing_date"],
                payment_method=d.get("payment_method", CapitalInjection.PaymentMethod.BANK),
                purpose=d.get("purpose", "").strip(),
                notes=d.get("notes", "").strip(),
                created_by=request.user,
            )
            messages.success(request, f"Drawing recorded for {investor.name}.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:investor_detail", pk=pk)
        except Exception as e:
            messages.error(request, f"Could not record drawing: {e}")
    return render(request, "accounts/investor_drawing_form.html", {
        "investor": investor,
        "payment_method_choices": CapitalInjection.PaymentMethod.choices,
    })


@_permission_required("can_manage_investors")
def investor_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            investor = Investor.objects.create(
                name=d["name"].strip(),
                investor_type=d.get("investor_type", Investor.InvestorType.INDIVIDUAL),
                phone=d.get("phone", "").strip(),
                email=d.get("email", "").strip(),
                national_id=d.get("national_id", "").strip(),
                address=d.get("address", "").strip(),
                committed_amount=d.get("committed_amount", "0") or "0",
                investment_date=d.get("investment_date") or None,
                maturity_date=d.get("maturity_date") or None,
                payment_method=d.get("payment_method", CapitalInjection.PaymentMethod.BANK),
                status=d.get("status", Investor.Status.ACTIVE),
                branch_id=resolve_branch_for_write(request, d.get("branch")),
                notes=d.get("notes", "").strip(),
                created_by=request.user,
            )
            messages.success(request, f"Investor '{investor.name}' added.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:investor_list")
        except Exception as e:
            messages.error(request, f"Could not create investor: {e}")

    return render(request, "accounts/investor_form.html", {
        "title": "Add Investor",
        "action": "create",
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "investor_type_choices": Investor.InvestorType.choices,
        "status_choices": Investor.Status.choices,
        "payment_method_choices": CapitalInjection.PaymentMethod.choices,
    })


@_permission_required("can_manage_investors")
def investor_edit(request, pk):
    investor = get_object_or_404(Investor, pk=pk)
    if request.method == "POST":
        d = request.POST
        try:
            investor.name = d["name"].strip()
            investor.investor_type = d.get("investor_type", Investor.InvestorType.INDIVIDUAL)
            investor.phone = d.get("phone", "").strip()
            investor.email = d.get("email", "").strip()
            investor.national_id = d.get("national_id", "").strip()
            investor.address = d.get("address", "").strip()
            investor.committed_amount = d.get("committed_amount", "0") or "0"
            investor.investment_date = d.get("investment_date") or None
            investor.maturity_date = d.get("maturity_date") or None
            investor.payment_method = d.get("payment_method", CapitalInjection.PaymentMethod.BANK)
            investor.status = d.get("status", Investor.Status.ACTIVE)
            investor.branch_id = resolve_branch_for_write(request, d.get("branch"))
            investor.notes = d.get("notes", "").strip()
            investor.save()
            messages.success(request, f"Investor '{investor.name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:investor_list")
        except Exception as e:
            messages.error(request, f"Could not update investor: {e}")

    return render(request, "accounts/investor_form.html", {
        "title": f"Edit Investor — {investor.name}",
        "action": "edit",
        "investor": investor,
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "investor_type_choices": Investor.InvestorType.choices,
        "status_choices": Investor.Status.choices,
        "payment_method_choices": CapitalInjection.PaymentMethod.choices,
    })


@_ceo_required
def investor_delete(request, pk):
    investor = get_object_or_404(Investor, pk=pk)
    if request.method == "POST":
        investor.delete()
        messages.success(request, "Investor deleted.")
        return redirect("accounts:investor_list")
    return render(request, "accounts/investor_confirm_delete.html", {"investor": investor})


# ------------------------------------------------------------------ #
# Bank Account Management                                              #
# ------------------------------------------------------------------ #

@_permission_required("can_manage_bank_accounts")
def bank_account_list(request):
    accounts = BankAccount.objects.all().order_by("bank_name", "account_name")
    total_balance = accounts.filter(is_active=True).aggregate(total=Sum("current_balance"))["total"] or 0
    return render(request, "accounts/bank_account_list.html", {
        "bank_accounts": accounts,
        "total_balance": total_balance,
    })


@_permission_required("can_manage_bank_accounts")
def bank_account_create(request):
    if request.method == "POST":
        d = request.POST
        try:
            acc = BankAccount.objects.create(
                account_name=d["account_name"].strip(),
                account_number=d["account_number"].strip(),
                bank_name=d["bank_name"].strip(),
                branch_name=d.get("branch_name", "").strip(),
                account_type=d.get("account_type", "CURRENT"),
                currency=d.get("currency", "UGX").strip() or "UGX",
                opening_balance=d.get("opening_balance", "0") or "0",
                current_balance=d.get("opening_balance", "0") or "0",
                notes=d.get("notes", "").strip(),
                is_active=d.get("is_active") == "on",
            )
            messages.success(request, f"Bank account '{acc.account_name}' added.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:bank_account_list")
        except Exception as e:
            messages.error(request, f"Could not create bank account: {e}")

    return render(request, "accounts/bank_account_form.html", {
        "title": "Add Bank Account", "action": "create",
        "account_type_choices": BankAccount.AccountType.choices,
    })


@_permission_required("can_manage_bank_accounts")
def bank_account_edit(request, pk):
    acc = get_object_or_404(BankAccount, pk=pk)
    if request.method == "POST":
        d = request.POST
        try:
            acc.account_name  = d["account_name"].strip()
            acc.account_number = d["account_number"].strip()
            acc.bank_name     = d["bank_name"].strip()
            acc.branch_name   = d.get("branch_name", "").strip()
            acc.account_type  = d.get("account_type", "CURRENT")
            acc.currency      = d.get("currency", "UGX").strip() or "UGX"
            acc.current_balance = d.get("current_balance", acc.current_balance)
            acc.notes         = d.get("notes", "").strip()
            acc.is_active     = d.get("is_active") == "on"
            acc.save()
            messages.success(request, f"Bank account '{acc.account_name}' updated.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:bank_account_list")
        except Exception as e:
            messages.error(request, f"Could not update bank account: {e}")

    return render(request, "accounts/bank_account_form.html", {
        "title": f"Edit — {acc.account_name}", "action": "edit",
        "account": acc,
        "account_type_choices": BankAccount.AccountType.choices,
    })


@_permission_required("can_manage_bank_accounts")
def bank_transaction_list(request):
    qs = BankTransaction.objects.select_related("branch", "bank_account", "created_by").order_by("-transaction_date")
    branch_filter = request.GET.get("branch", "")
    type_filter = request.GET.get("type", "")
    q = request.GET.get("q", "").strip()
    date_from = request.GET.get("date_from", "")
    date_to = request.GET.get("date_to", "")

    if branch_filter:
        qs = qs.filter(branch_id=branch_filter)
    if type_filter:
        qs = qs.filter(transaction_type=type_filter)
    if date_from:
        qs = qs.filter(transaction_date__date__gte=date_from)
    if date_to:
        qs = qs.filter(transaction_date__date__lte=date_to)
    if q:
        qs = qs.filter(
            Q(category__icontains=q)
            | Q(reference_number__icontains=q)
            | Q(bank_account__account_name__icontains=q)
            | Q(bank_account__bank_name__icontains=q)
        )

    paginator = Paginator(qs, 25)
    transactions = paginator.get_page(request.GET.get("page", 1))
    total_amount = qs.aggregate(total=Sum("amount"))["total"] or 0
    branches = Branch.objects.filter(is_active=True).order_by("name")
    query_string = urlencode({k: v for k, v in request.GET.items() if k != "page" and v})

    return render(request, "accounts/bank_transaction_list.html", {
        "transactions": transactions,
        "branches": branches,
        "branch_filter": branch_filter,
        "type_filter": type_filter,
        "date_from": date_from,
        "date_to": date_to,
        "q": q,
        "total_amount": total_amount,
        "transaction_type_choices": BankTransaction.TransactionType.choices,
        "query_string": query_string,
    })


@_permission_required("can_manage_bank_accounts")
def bank_transaction_create(request):
    transaction = None
    if request.method == "POST":
        d = request.POST
        try:
            branch_id = resolve_branch_for_write(request, d.get("branch"))
            bank_account = get_object_or_404(BankAccount, pk=d["bank_account"])
            transaction_type = d.get("transaction_type", BankTransaction.TransactionType.CREDIT)
            amount = Decimal(d["amount"])
            transaction_date_value = d.get("transaction_date", "")
            if transaction_date_value:
                transaction_date = datetime.fromisoformat(transaction_date_value)
                if transaction_date.tzinfo is None:
                    transaction_date = timezone.make_aware(transaction_date)
            else:
                transaction_date = timezone.now()

            transaction = BankTransaction.objects.create(
                branch_id=branch_id,
                bank_account=bank_account,
                category=d.get("category", "").strip(),
                transaction_type=transaction_type,
                amount=amount,
                transaction_date=transaction_date,
                reference_number=d.get("reference_number", "").strip(),
                notes=d.get("notes", "").strip(),
                created_by=request.user,
            )

            if transaction_type == BankTransaction.TransactionType.CREDIT:
                bank_account.current_balance += amount
            else:
                bank_account.current_balance -= amount
            bank_account.save()

            messages.success(request, "Bank transaction recorded successfully.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:bank_transaction_list")
        except Exception as e:
            messages.error(request, f"Could not save bank transaction: {e}")

    return render(request, "accounts/bank_transaction_form.html", {
        "title": "Add Bank Transaction",
        "action": "create",
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "bank_accounts": BankAccount.objects.filter(is_active=True).order_by("bank_name", "account_name"),
        "transaction_type_choices": BankTransaction.TransactionType.choices,
        "transaction": transaction,
        "now": timezone.localtime(),
    })


@_permission_required("can_manage_bank_accounts")
def bank_transaction_edit(request, pk):
    transaction = get_object_or_404(BankTransaction, pk=pk)
    if request.method == "POST":
        d = request.POST
        try:
            old_account = transaction.bank_account
            old_type = transaction.transaction_type
            old_amount = transaction.amount

            transaction.branch_id = resolve_branch_for_write(request, d.get("branch"))
            transaction.bank_account = get_object_or_404(BankAccount, pk=d["bank_account"])
            transaction.category = d.get("category", "").strip()
            transaction.transaction_type = d.get("transaction_type", BankTransaction.TransactionType.CREDIT)
            transaction.amount = Decimal(d["amount"])
            transaction_date_value = d.get("transaction_date", "")
            if transaction_date_value:
                updated_date = datetime.fromisoformat(transaction_date_value)
                if updated_date.tzinfo is None:
                    updated_date = timezone.make_aware(updated_date)
                transaction.transaction_date = updated_date
            transaction.reference_number = d.get("reference_number", "").strip()
            transaction.notes = d.get("notes", "").strip()
            transaction.save()

            if old_type == BankTransaction.TransactionType.CREDIT:
                old_account.current_balance -= old_amount
            else:
                old_account.current_balance += old_amount
            old_account.save()

            if transaction.transaction_type == BankTransaction.TransactionType.CREDIT:
                transaction.bank_account.current_balance += transaction.amount
            else:
                transaction.bank_account.current_balance -= transaction.amount
            transaction.bank_account.save()

            messages.success(request, "Bank transaction updated successfully.")
            response = _quick_form_saved(request)
            if response:
                return response
            return redirect("accounts:bank_transaction_list")
        except Exception as e:
            messages.error(request, f"Could not update bank transaction: {e}")

    return render(request, "accounts/bank_transaction_form.html", {
        "title": f"Edit Bank Transaction — {transaction.reference_number or transaction.pk}",
        "action": "edit",
        "branches": Branch.objects.filter(is_active=True).order_by("name"),
        "bank_accounts": BankAccount.objects.filter(is_active=True).order_by("bank_name", "account_name"),
        "transaction_type_choices": BankTransaction.TransactionType.choices,
        "transaction": transaction,
        "now": timezone.localtime(),
    })

# ------------------------------------------------------------------ #
# CEO branch filter (nav switcher)                                     #
# ------------------------------------------------------------------ #

@login_required
def set_branch_filter(request):
    """Set/clear the CEO's nav-switcher branch default for this session.

    Only meaningful for CEOs (branch_scope.effective_branch_id ignores the
    session entirely for everyone else), but any authenticated user posting
    here just gets redirected back — no error, since it's a no-op for them.
    """
    from .branch_scope import SESSION_KEY

    if request.method == "POST":
        branch_id = request.POST.get("branch", "").strip()
        if branch_id and branch_id.isdigit() and Branch.objects.filter(pk=branch_id, is_active=True).exists():
            request.session[SESSION_KEY] = branch_id
        else:
            request.session.pop(SESSION_KEY, None)

    next_url = request.POST.get("next") or request.META.get("HTTP_REFERER") or "/"
    # Avoid redirect loops back to a page carrying a stale ?branch= override
    # from before the switch — safest is to just drop any query string.
    from urllib.parse import urlsplit
    next_url = urlsplit(next_url).path or "/"
    return redirect(next_url)