from django.conf import settings
from django.db import connection
from django.db.models.signals import post_migrate, post_save, pre_save
from django.dispatch import receiver
from django.contrib.auth import get_user_model


@receiver(pre_save, sender=settings.AUTH_USER_MODEL)
def strip_elevated_flags_on_demotion(sender, instance, **kwargs):
    """When someone is moved OUT of the CEO role, drop is_superuser / is_staff.

    CEOs are normally created as superusers, and Django treats a superuser as
    holding EVERY permission (has_perm() always returns True) -- so without
    this, a demoted CEO keeps the admin panel, user management, etc. even
    though their role says Cashier.
    """
    if instance.pk is None or instance.role == "CEO":
        return
    if not (instance.is_superuser or instance.is_staff):
        return
    try:
        old_role = sender.objects.filter(pk=instance.pk).values_list("role", flat=True).first()
    except Exception:
        return
    if old_role == "CEO":
        instance.is_superuser = False
        instance.is_staff = False


@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def sync_role_group(sender, instance, **kwargs):
    """
    Keep group membership in sync with the `role` field whenever a user is
    created or their role changes, so `user.can(...)` reflects the right
    permission set without anyone having to remember to update groups by
    hand. This only touches the built-in Cashier/Manager/CEO groups — any
    extra groups/per-user permissions a CEO has added manually elsewhere
    are left alone.
    """
    from accounts.permissions import ALL_GROUPS
    from django.contrib.auth.models import Group

    role_to_group_name = {"CASHIER": "Cashier", "MANAGER": "Manager", "CEO": "CEO"}
    target_name = role_to_group_name.get(instance.role)
    if not target_name:
        return

    try:
        current = set(instance.groups.filter(name__in=ALL_GROUPS).values_list("name", flat=True))
    except Exception:
        # e.g. mid-migration before the groups/M2M table is ready
        return

    if current == {target_name}:
        return  # already correct, avoid needless queries on every save

    target_group, _created = Group.objects.get_or_create(name=target_name)
    # Remove from any of the other two built-in role groups, add to the right one
    stale = Group.objects.filter(name__in=ALL_GROUPS).exclude(name=target_name)
    instance.groups.remove(*stale)
    instance.groups.add(target_group)


@receiver(post_migrate)
def create_initial_tenant_admin(sender, app_config, **kwargs):
    """Create an initial tenant admin user automatically after tenant migrations.

    This runs on post_migrate for the 'accounts' app inside a tenant schema.
    Behavior:
    - Skip when running in the public schema (schema_name == 'public').
    - Only act when app_config.name == 'accounts' to avoid duplicate runs.
    - If the User table has no users, create a superuser with defaults from settings.

    This provides a safe automatic seeding: the first migration into a brand new
    tenant will create an admin account so operators can sign in immediately.
    """
    try:
        schema = getattr(connection, 'schema_name', None) or getattr(connection, 'settings_dict', {}).get('OPTIONS', {}).get('schema', None)
    except Exception:
        schema = None

    # If we are in the public schema, do nothing
    if schema in (None, 'public'):
        return

    # Only run when the accounts app migrations have completed in this schema
    if getattr(app_config, 'name', '') != 'accounts':
        return

    User = get_user_model()

    try:
        if User.objects.exists():
            # Tenant already has users, nothing to do
            return
    except Exception:
        # If the user table doesn't exist or other DB error, abort silently
        return

    admin_username = getattr(settings, 'TENANT_INITIAL_ADMIN_USERNAME', 'admin')
    admin_password = getattr(settings, 'TENANT_INITIAL_ADMIN_PASSWORD', '@Developer25')
    admin_email = getattr(settings, 'TENANT_INITIAL_ADMIN_EMAIL', 'primefocusug@gmail.com')

    try:
        User.objects.create_superuser(username=admin_username, email=admin_email, password=admin_password)
        # Optionally write to stdout for visibility when running management commands
        try:
            from django.core.management import call_command
            print(f"Created initial tenant admin: {admin_username} ({admin_email}) in schema {schema}")
        except Exception:
            pass
    except Exception as exc:
        # Do not raise during migrations; just log to stderr if possible
        try:
            import sys
            sys.stderr.write(f"Could not create initial tenant admin for schema {schema}: {exc}\n")
        except Exception:
            pass
