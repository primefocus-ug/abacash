"""
Single source of truth for "who can see which branch's data".

Rule (per product decision): anyone with the can_view_all_branches
permission (CEOs by default — see accounts/permissions.py, but it's
grantable to any role/user) sees every branch. Everyone else is
restricted to their own branch. A staff member with no branch assigned
sees nothing branch-scoped until an admin assigns one — we deliberately do
NOT fall back to "show everything" for an unassigned user, since that would
silently leak other branches' data.

Usage:
    from accounts.branch_scope import scope_to_branch
    loans = scope_to_branch(Loan.objects.all(), request.user)                 # field="branch" by default
    payments = scope_to_branch(Payment.objects.all(), request.user, "loan__branch")
"""


def scope_to_branch(queryset, user, field="branch"):
    """Restrict queryset to the user's branch unless they're a CEO.

    - CEO (or Django superuser): queryset returned unchanged.
    - Everyone else with a branch assigned: filtered to that branch.
    - Everyone else with NO branch assigned: filtered to nothing (empty
      queryset) rather than showing all branches by accident.
    """
    if getattr(user, "is_superuser", False) or (hasattr(user, "can") and user.can("can_view_all_branches")):
        return queryset
    branch_id = getattr(user, "branch_id", None)
    if not branch_id:
        return queryset.none()
    return queryset.filter(**{f"{field}_id": branch_id})


def can_access_branch_object(user, obj, field="branch"):
    """True if the user is allowed to view/act on a single object.

    Mirrors scope_to_branch's rule for the single-object case (detail/edit
    views that fetch by pk before deciding whether to show it).
    """
    if getattr(user, "is_superuser", False) or (hasattr(user, "can") and user.can("can_view_all_branches")):
        return True
    branch_id = getattr(user, "branch_id", None)
    if not branch_id:
        return False
    obj_branch_id = obj
    for part in field.split("__"):
        obj_branch_id = getattr(obj_branch_id, part, None)
        if obj_branch_id is None:
            return False
    obj_branch_id = getattr(obj_branch_id, "pk", obj_branch_id)
    return obj_branch_id == branch_id


SESSION_KEY = "ceo_branch_filter"


def get_single_active_branch_id():
    """Return the sole active branch ID, or None when branch selection is ambiguous."""
    from accounts.models import Branch

    branch_ids = list(
        Branch.objects.filter(is_active=True)
        .order_by("pk")
        .values_list("pk", flat=True)[:2]
    )
    return branch_ids[0] if len(branch_ids) == 1 else None


def effective_branch_id(request, param="branch"):
    """Resolve which branch a list/report page should be scoped to.

    - Non-CEO: always their own branch (branch_id, or -1 if unassigned).
      Ignores any ?branch= param and the session switcher entirely — a
      Manager/Cashier can't page-hack or switcher-hack into another branch.
    - CEO: the page's own ?branch= query param wins if present (including
      an explicit empty value, meaning "All branches" was chosen on this
      page). Otherwise falls back to the nav switcher's session default.
      Otherwise None (all branches).

    Returns an int branch id, -1 (deliberately-empty scope), or None (no
    restriction — only ever returned for a CEO).
    """
    user = request.user
    if not (getattr(user, "is_superuser", False) or (hasattr(user, "can") and user.can("can_view_all_branches"))):
        return user.branch_id or -1

    raw = request.GET.get(param, None)
    if raw is not None:
        return int(raw) if raw.isdigit() else None

    session_val = request.session.get(SESSION_KEY)
    if session_val:
        return int(session_val) if str(session_val).isdigit() else None
    return None


def scope_to_branch_request(queryset, request, field="branch", param="branch"):
    """Like scope_to_branch, but CEO-aware of the nav switcher/page filter."""
    branch_id = effective_branch_id(request, param=param)
    if branch_id is None:
        return queryset
    return queryset.filter(**{f"{field}_id": branch_id})


def _is_all_branches(user):
    return getattr(user, "is_superuser", False) or (hasattr(user, "can") and user.can("can_view_all_branches"))


def resolve_branch_for_write(request, posted_branch_id):
    """Return the branch a NEW or EDITED record should be stored against.

    Never trusts the posted form value for non-CEO users: they always write
    to their own branch, so a record cannot land in another branch and cannot
    silently fall into "general" because a dropdown was left blank.

    CEOs (and superusers): an explicit choice in the form wins; otherwise the
    nav switcher's session branch; otherwise the sole active branch is used.
    If multiple active branches exist, no implicit choice is made. The page's
    ?branch= query param is deliberately ignored here, since it belongs to the
    list filter, not to the record being written.

    Raises ValueError if a non-CEO has no branch assigned, so the view can
    show a message instead of saving a general record by accident.
    """
    user = request.user
    if not _is_all_branches(user):
        if not user.branch_id:
            raise ValueError("Your account has no branch assigned. Ask an administrator to assign one.")
        return user.branch_id
    if posted_branch_id and str(posted_branch_id).isdigit():
        return int(posted_branch_id)
    session_val = request.session.get(SESSION_KEY)
    if session_val and str(session_val).isdigit():
        return int(session_val)
    return get_single_active_branch_id()