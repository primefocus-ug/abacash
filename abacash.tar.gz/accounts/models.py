from decimal import Decimal
from common.phone_numbers import PhoneNumberNormalizationMixin, normalize_phone_number
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from accounts.permissions import PERMISSIONS
from decimal import Decimal
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _
from django.utils import timezone



class UserManager(BaseUserManager):
    """Custom user manager for the User model."""

    def _create_user(self, email, password, **extra_fields):
        """Create and save a user with the given email and password."""
        if not email:
            raise ValueError("The Email field must be set")
        email = self.normalize_email(email)

        # Generate username from email if not provided
        username = extra_fields.pop('username', None)
        if not username:
            username = email.split('@')[0]
            # Ensure uniqueness
            base_username = username
            counter = 1
            while self.model.objects.filter(username=username).exists():
                username = f"{base_username}{counter}"
                counter += 1
            extra_fields['username'] = username

        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        extra_fields.setdefault("role", User.Role.CASHIER)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        """Create a superuser with CEO role."""
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("role", User.Role.CEO)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self._create_user(email, password, **extra_fields)

    def create_ceo(self, email, password=None, **extra_fields):
        """Create a CEO user (superuser by default)."""
        return self.create_superuser(email, password, **extra_fields)

    def create_cashier(self, email, password=None, **extra_fields):
        extra_fields.setdefault("role", User.Role.CASHIER)
        return self.create_user(email, password, **extra_fields)

    def create_manager(self, email, password=None, **extra_fields):
        extra_fields.setdefault("role", User.Role.MANAGER)
        extra_fields.setdefault("is_staff", True)
        return self.create_user(email, password, **extra_fields)

    def get_by_natural_key(self, username):
        """Allow login by email or username.

        Case-insensitive matching (email__iexact/username__iexact) means a
        pair of accounts differing only by letter-case can both match the
        same lookup — the DB's unique=True constraint is case-sensitive and
        won't have caught that. Rather than raising MultipleObjectsReturned
        here (which previously crashed login), fall back to the oldest
        matching row, same as EmailOrUsernameModelBackend already does.
        """
        try:
            # Try by email first
            return self.get(email__iexact=username)
        except self.model.MultipleObjectsReturned:
            return self.filter(email__iexact=username).order_by("id").first()
        except self.model.DoesNotExist:
            try:
                # Try by username
                return self.get(username__iexact=username)
            except self.model.MultipleObjectsReturned:
                return self.filter(username__iexact=username).order_by("id").first()
            except self.model.DoesNotExist:
                if "@" not in username and not any(character.isalpha() for character in username):
                    phone = normalize_phone_number(username)
                    if phone:
                        try:
                            return self.get(phone=phone)
                        except self.model.MultipleObjectsReturned:
                            return self.filter(phone=phone).order_by("id").first()
                        except self.model.DoesNotExist:
                            pass
                raise self.model.DoesNotExist(
                    f"No user found with email, username, or phone: {username}"
                )


class User(PhoneNumberNormalizationMixin, AbstractBaseUser, PermissionsMixin):
    """Custom User model using email as the unique identifier."""
    phone_fields = ("phone",)

    class Role(models.TextChoices):
        CASHIER = "CASHIER", _("Cashier")
        MANAGER = "MANAGER", _("Manager")
        CEO = "CEO", _("CEO")

    # Required fields for AbstractBaseUser
    email = models.EmailField(_("email address"), unique=True)
    username = models.CharField(
        _("username"),
        max_length=150,
        unique=True,
        blank=True,
        null=True,
        help_text=_("Optional username for login (can be email, phone, or custom)"),
    )
    # User information fields
    first_name = models.CharField(_("first name"), max_length=150, blank=True)
    last_name = models.CharField(_("last name"), max_length=150, blank=True)

    # Role and permissions
    role = models.CharField(
        max_length=10,
        choices=Role.choices,
        default=Role.CASHIER,
        help_text=_("Controls which parts of the system this user can access."),
    )

    # Required for admin interface
    is_active = models.BooleanField(
        _("active"),
        default=True,
        help_text=_(
            "Designates whether this user should be treated as active. "
            "Unselect this instead of deleting accounts."
        ),
    )
    is_staff = models.BooleanField(
        _("staff status"),
        default=False,
        help_text=_("Designates whether the user can log into this admin site."),
    )

    # Additional fields
    phone = models.CharField(
        max_length=20,
        blank=True,
        help_text=_("Staff contact number, e.g. +256700123456"),
    )
    signature = models.ImageField(
        upload_to="user_signatures/",
        blank=True,
        null=True,
        help_text=_("Signature image used when this staff member is selected on printed documents."),
    )

    branch = models.ForeignKey(
        "accounts.Branch",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="staff_members",
        help_text=_("Branch where this user is stationed."),
    )

    commission_rate = models.DecimalField(
        max_digits=5, decimal_places=2,
        default=Decimal("0.00"),
        validators=[MinValueValidator(Decimal("0.00")), MaxValueValidator(Decimal("100.00"))],
        help_text=_("Commission rate as a percentage (e.g., 2.50 for 2.5%)."),
    )

    date_joined = models.DateTimeField(_("date joined"), default=timezone.now)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    # ------------------------------------------------------------------ #
    # Convenience properties used in templates and views                   #
    # ------------------------------------------------------------------ #

    @property
    def is_cashier(self):
        return self.role == self.Role.CASHIER

    @property
    def is_manager(self):
        return self.role == self.Role.MANAGER

    @property
    def is_ceo(self):
        return self.role == self.Role.CEO

    def can(self, codename):
        """
        Check an app permission by its short codename, e.g. user.can("can_manage_branches").
        Thin wrapper over has_perm() so call sites don't need to spell out
        the "accounts." app-label prefix every time. Respects everything
        has_perm() does: group permissions, per-user overrides, and
        is_superuser (which auto-passes every check).
        """
        return self.has_perm(f"accounts.{codename}")

    @property
    def can_approve_loans(self):
        """Whether this user is allowed to approve/renew loans.

        Backed by the real can_approve_loans permission (granted to the
        Manager/CEO groups by default, see accounts/permissions.py) rather
        than a hardcoded role check, so a CEO can extend or restrict this
        per-user or per-group without a code change.
        """
        return self.can("can_approve_loans")

    @property
    def full_name(self):
        """Return the user's full name or email if not set."""
        if self.first_name or self.last_name:
            return f"{self.first_name} {self.last_name}".strip()
        return self.email

    def get_full_name(self):
        return self.full_name

    def get_short_name(self):
        return self.first_name or self.email

    def __str__(self):
        branch_info = f" - {self.branch.name}" if self.branch else ""
        return f"{self.full_name} ({self.get_role_display()}{branch_info})"

    class Meta:
        verbose_name = _("User")
        verbose_name_plural = _("Users")
        ordering = ["first_name", "last_name"]
        # App-level permissions (not tied to any one model instance) that
        # power the Roles & Permissions system. See accounts/permissions.py
        # for the canonical list + which Group each is granted to by
        # default, and the 0006/0007 migrations for how they're created.
        permissions = [(codename, label) for codename, label, _groups in PERMISSIONS]


class Branch(PhoneNumberNormalizationMixin, models.Model):
    """
    Represents a branch/office location of the microfinance institution.
    Allows for multi-branch operations with branch-specific settings.
    """
    phone_fields = ("phone",)

    name = models.CharField(max_length=200)
    code = models.CharField(max_length=10, unique=True, help_text=_("Short code for this branch, e.g., KLA, MBA"))
    address = models.TextField(blank=True)
    phone = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)
    manager = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="managed_branches",
        help_text=_("Branch manager."),
    )
    is_active = models.BooleanField(default=True)
    opened_date = models.DateField(null=True, blank=True)
    closed_date = models.DateField(null=True, blank=True)

    # Branch-specific settings
    approval_limit = models.DecimalField(
        max_digits=15, decimal_places=2,
        default=Decimal("10_000_000"),
        help_text=_("Maximum loan amount this branch can approve without head office approval (UGX)."),
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.code})"

    class Meta:
        verbose_name = _("Branch")
        verbose_name_plural = _("Branches")
        ordering = ["name"]


class FeeType(models.Model):
    """
    Defines different types of fees that can be charged.
    Examples: Processing fee, Late payment fee, Early repayment penalty, etc.
    """
    class CalculationMethod(models.TextChoices):
        FLAT = "FLAT", _("Flat Amount")
        PERCENTAGE = "PERCENTAGE", _("Percentage of Loan Amount")
        PERCENTAGE_OUTSTANDING = "PERCENTAGE_OUTSTANDING", _("Percentage of Outstanding Balance")

    class AppliedTo(models.TextChoices):
        LOAN_APPLICATION = "LOAN_APP", _("Loan Application")
        LOAN_DISBURSEMENT = "LOAN_DISB", _("Loan Disbursement")
        LATE_PAYMENT = "LATE_PAY", _("Late Payment")
        EARLY_REPAYMENT = "EARLY_PAY", _("Early Repayment")
        LOAN_RESTRUCTURE = "RESTRUCTURE", _("Loan Restructuring")
        CHECKBOOK = "CHECKBOOK", _("Checkbook Issuance")
        STATEMENT = "STATEMENT", _("Account Statement")
        OTHER = "OTHER", _("Other")

    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    applied_to = models.CharField(max_length=20, choices=AppliedTo.choices)
    calculation_method = models.CharField(
        max_length=30,
        choices=CalculationMethod.choices,
        default=CalculationMethod.FLAT,
    )
    amount = models.DecimalField(
        max_digits=15, decimal_places=2,
        default=Decimal("0.00"),
        help_text=_("Flat amount in UGX or percentage value depending on calculation method."),
    )
    is_active = models.BooleanField(default=True)
    is_mandatory = models.BooleanField(
        default=False,
        help_text=_("If True, this fee is automatically applied to all applicable transactions."),
    )

    # For percentage-based fees, set min and max limits
    min_amount = models.DecimalField(
        max_digits=15, decimal_places=2,
        default=Decimal("0.00"),
        help_text=_("Minimum fee amount (0 = no minimum)."),
    )
    max_amount = models.DecimalField(
        max_digits=15, decimal_places=2,
        default=Decimal("0.00"),
        help_text=_("Maximum fee amount (0 = no maximum)."),
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.name} ({self.get_applied_to_display()})"

    class Meta:
        verbose_name = _("Fee Type")
        verbose_name_plural = _("Fee Types")
        ordering = ["name"]


class Holiday(models.Model):
    """
    Holiday calendar for due date adjustments.
    If a due date falls on a holiday, it can be adjusted to the next working day.
    """
    name = models.CharField(max_length=200)
    date = models.DateField()
    is_recurring = models.BooleanField(
        default=False,
        help_text=_("If True, this holiday occurs every year on the same date."),
    )
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)

    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.date})"

    class Meta:
        verbose_name = _("Holiday")
        verbose_name_plural = _("Holidays")
        ordering = ["date"]
        indexes = [
            models.Index(fields=["date"]),
        ]


DEFAULT_PROCESSING_FEE_RANGES = (
    "0-50000:4000\n"
    "100000-200000:8000\n"
    "200001-300001:10000\n"
    "300001-450000:12000\n"
    "450001-600000:15000\n"
    "600001-800000:20000\n"
    "800001-1000000:30000\n"
    "1000001-:40000"
)

DEFAULT_LOAN_TERMS = """1. Loan agreement
The borrower acknowledges receipt of the loan amount stated on this schedule and agrees to repay the principal, interest, approved fees, and any lawful charges shown in the schedule.

2. Repayment obligation
Each instalment is due on its stated due date. The borrower must ensure that payments are made through an approved payment channel and that the loan number is used as the payment reference.

3. Allocation of payments
Unless applicable law requires otherwise, payments are applied to approved charges and penalties, interest, and then principal, according to the lender's documented allocation procedure. A payment is only treated as received when it has been confirmed and allocated by the lender.

4. Late payment and default
An unpaid or partially paid instalment may be treated as overdue after the applicable grace period. Lawful default penalties, collection costs, and other charges disclosed in the loan agreement may apply. Persistent non-payment may result in recovery action, reporting to authorised credit-reference bodies, or enforcement of security.

5. Early repayment
The borrower may request early settlement. The lender will provide a settlement figure showing the amount required to close the loan. Any early-repayment charge must be disclosed, lawful, and included in the applicable loan agreement.

6. Security and guarantees
Where security or a guarantee has been provided, it remains subject to the separate security or guarantee instrument. The lender may enforce those rights only in accordance with the agreement and applicable law.

7. Changes and restructuring
Any variation, extension, waiver, or restructuring must be approved by the lender in writing. An informal promise or verbal discussion does not amend the repayment schedule.

8. Statements and disputes
The borrower should review this schedule and report any error promptly. The lender's records are prima facie evidence of transactions, subject to reconciliation and the borrower's statutory rights to request information or raise a dispute.

9. Notices and contact details
The borrower must keep contact information current and promptly notify the lender of changes affecting repayment. Notices may be sent using the contact details recorded in the lender's records, subject to applicable law.

10. Governing law
This schedule is intended to be read with the signed loan agreement, disclosures, and applicable security documents. Those documents and the laws applicable in the lender's jurisdiction govern the relationship. This summary does not replace independent legal advice."""


class CompanySettings(PhoneNumberNormalizationMixin, models.Model):
    """
    Singleton model for company-wide configuration.
    Only one row should ever exist — use CompanySettings.get() to access it.
    """
    phone_fields = ("company_phone",)

    class PenaltyFrequency(models.TextChoices):
        DAILY = "DAILY", _("Daily")
        MONTHLY = "MONTHLY", _("Monthly")

    # Company Information
    company_name            = models.CharField(max_length=200, default="Abacash")
    currency_symbol         = models.CharField(max_length=10, default="UGX",
                                               help_text=_("Currency symbol displayed with amounts."))
    company_address         = models.TextField(blank=True)
    company_phone           = models.CharField(max_length=50, blank=True)
    company_email           = models.EmailField(blank=True)
    company_logo            = models.ImageField(upload_to="company/", null=True, blank=True)
    company_website         = models.URLField(blank=True)
    company_registration    = models.CharField(max_length=100, blank=True, help_text=_("Registration number"))
    tax_identification      = models.CharField(max_length=100, blank=True, help_text=_("TIN number"))
    loan_terms_and_conditions = models.TextField(
        default=DEFAULT_LOAN_TERMS,
        help_text=_(
            "Terms printed on loan schedules. Review with qualified local counsel "
            "before relying on them as a legal contract."
        ),
    )

    # Loan Business Rules
    manager_approval_limit  = models.DecimalField(
        max_digits=15, decimal_places=2, default=5_000_000,
        help_text=_("Maximum loan amount a Manager can approve without CEO sign-off (UGX).")
    )
    penalties_enabled = models.BooleanField(
        default=True,
        help_text=_("Allow late-payment penalties to accrue for this tenant."),
    )
    penalty_frequency = models.CharField(
        max_length=10,
        choices=PenaltyFrequency.choices,
        default=PenaltyFrequency.MONTHLY,
        help_text=_("Interval used to apply late-payment penalties."),
    )
    default_penalty_rate    = models.DecimalField(
        max_digits=5, decimal_places=2, default=2,
        help_text=_("Default penalty rate on overdue amounts per selected interval (%)."),
    )
    income_multiplier       = models.DecimalField(
        max_digits=4, decimal_places=1, default=3,
        help_text=_("Max loan = monthly income × this multiplier."),
    )
    collateral_haircut      = models.DecimalField(
        max_digits=4, decimal_places=2, default=50,
        help_text=_("Percentage of collateral value used as loan floor (e.g. 50 = 50%)."),
    )

    # Disbursement limits
    class DisbursementLimitScope(models.TextChoices):
        ALL = "ALL", _("All staff")
        CASHIER = "CASHIER", _("Cashiers")
        MANAGER = "MANAGER", _("Managers")
        CEO = "CEO", _("CEOs")

    daily_disbursement_limit = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text=_("Maximum total loan principal disbursed per day. Zero disables the limit."),
    )
    daily_disbursement_limit_scope = models.CharField(
        max_length=10, choices=DisbursementLimitScope.choices, default=DisbursementLimitScope.ALL,
    )
    weekly_disbursement_limit = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text=_("Maximum total loan principal disbursed per week. Zero disables the limit."),
    )
    weekly_disbursement_limit_scope = models.CharField(
        max_length=10, choices=DisbursementLimitScope.choices, default=DisbursementLimitScope.ALL,
    )
    monthly_disbursement_limit = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        validators=[MinValueValidator(Decimal("0.00"))],
        help_text=_("Maximum total loan principal disbursed per month. Zero disables the limit."),
    )
    monthly_disbursement_limit_scope = models.CharField(
        max_length=10, choices=DisbursementLimitScope.choices, default=DisbursementLimitScope.ALL,
    )

    # Fee Settings
    default_processing_fee_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=1,
        help_text=_("Default loan processing fee as a percentage of loan amount."),
    )
    processing_fee_method = models.CharField(
        max_length=20,
        choices=[("PERCENTAGE", "Percentage"), ("RANGE", "Range")],
        default="RANGE",
        help_text=_("Choose whether processing fees are calculated using a percentage or amount ranges."),
    )
    processing_fee_ranges = models.TextField(
        blank=True,
        default=DEFAULT_PROCESSING_FEE_RANGES,
        help_text=_(
            "Processing fee ranges as 'MIN-MAX:AMOUNT' per line. Endpoints are "
            "inclusive; unmatched amounts have no range fee, and the first "
            "matching range wins."
        ),
    )
    early_repayment_penalty_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=0,
        help_text=_("Penalty for early loan repayment as a percentage of outstanding balance (0 = no penalty)."),
    )
    loan_restructure_fee = models.DecimalField(
        max_digits=15, decimal_places=2, default=10000,
        help_text=_("Flat fee for loan restructuring (UGX)."),
    )

    # Maximum loans per client
    max_active_loans_per_client = models.PositiveSmallIntegerField(
        default=3,
        help_text=_("Maximum number of active loans a client can have simultaneously."),
    )

    # SMS & Communication Settings
    sms_reminders_enabled   = models.BooleanField(default=True)
    reminder_days_before    = models.PositiveSmallIntegerField(
        default=3,
        help_text=_("Days before due date to send payment reminder."),
    )
    sms_sender_id = models.CharField(
        max_length=20, blank=True, default="ABA Uganda",
        help_text=_("Sender ID for SMS messages."),
    )

    # Due Date Adjustment Settings
    adjust_due_dates_for_holidays = models.BooleanField(
        default=True,
        help_text=_("If True, move due dates that fall on holidays to next working day."),
    )
    grace_period_days = models.PositiveSmallIntegerField(
        default=3,
        help_text=_("Number of grace days before marking a payment as overdue."),
    )

    # Savings Settings (for future savings module)
    savings_enabled = models.BooleanField(default=False)
    default_savings_interest_rate = models.DecimalField(
        max_digits=5, decimal_places=2, default=3,
        help_text=_("Annual interest rate paid on savings balances (%)."),
    )
    minimum_savings_balance = models.DecimalField(
        max_digits=15, decimal_places=2, default=10000,
        help_text=_("Minimum required savings balance (UGX)."),
    )

    # Share Capital Settings (for future shares module)
    shares_enabled = models.BooleanField(default=False)
    share_price = models.DecimalField(
        max_digits=15, decimal_places=2, default=50000,
        help_text=_("Price per share (UGX)."),
    )
    minimum_shares = models.PositiveSmallIntegerField(
        default=10,
        help_text=_("Minimum number of shares a member must hold."),
    )
    maximum_shares = models.PositiveSmallIntegerField(
        default=1000,
        help_text=_("Maximum number of shares a member can hold."),
    )

    # Dividend Settings
    dividend_frequency = models.CharField(
        max_length=10,
        choices=[
            ("MONTHLY", "Monthly"),
            ("QUARTERLY", "Quarterly"),
            ("ANNUALLY", "Annually"),
        ],
        default="ANNUALLY",
        help_text=_("How often dividends are calculated and distributed."),
    )

    # Risk Management
    max_portfolio_at_risk_percent = models.DecimalField(
        max_digits=5, decimal_places=2, default=5,
        help_text=_("Maximum acceptable Portfolio at Risk (PAR) percentage."),
    )
    auto_write_off_days = models.PositiveSmallIntegerField(
        default=180,
        help_text=_("Number of days overdue before a loan is automatically flagged for write-off."),
    )

    # Audit & Tracking
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(
        "accounts.User", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="+",
    )

    @classmethod
    def get(cls):
        obj, _ = cls.objects.get_or_create(pk=1)
        return obj

    def __str__(self):
        return "Company Settings"

    class Meta:
        verbose_name = _("Company Settings")
        verbose_name_plural = _("Company Settings")



class TransactionCategory(models.Model):
    """User-manageable transaction categories (e.g. Operations, Payroll)."""
    name = models.CharField(max_length=100, unique=True)
    description = models.TextField(blank=True)
    color = models.CharField(
        max_length=20, default="amber",
        help_text=_("Badge colour: teal, amber, red, green, blue, purple"),
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _("Transaction Category")
        verbose_name_plural = _("Transaction Categories")
        ordering = ["name"]


class ExpenseType(models.Model):
    """Specific expense types nested under a TransactionCategory."""
    category = models.ForeignKey(
        TransactionCategory,
        on_delete=models.PROTECT,
        related_name="expense_types",
    )
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.category.name} — {self.name}"

    class Meta:
        verbose_name = _("Expense Type")
        verbose_name_plural = _("Expense Types")
        ordering = ["category__name", "name"]
        unique_together = [("category", "name")]


class Expense(models.Model):

    class Status(models.TextChoices):
        DRAFT    = "DRAFT",    _("Draft")
        PENDING  = "PENDING",  _("Pending Approval")
        APPROVED = "APPROVED", _("Approved")
        REJECTED = "REJECTED", _("Rejected")

    class PaymentMethod(models.TextChoices):
        CASH         = "CASH",         _("Cash")
        BANK         = "BANK",         _("Bank Transfer")
        MOBILE_MONEY = "MOBILE_MONEY", _("Mobile Money")
        CHEQUE       = "CHEQUE",       _("Cheque")

    reference_number = models.CharField(
        max_length=30, unique=True, blank=True,
        help_text=_("Auto-generated on save, e.g. EXP-2025-00042"),
    )
    category = models.ForeignKey(
        TransactionCategory,
        on_delete=models.PROTECT,
        related_name="expenses",
        null=True, blank=True,
    )
    expense_type = models.ForeignKey(
        ExpenseType,
        on_delete=models.SET_NULL,
        related_name="expenses",
        null=True, blank=True,
    )
    branch = models.ForeignKey(
        "accounts.Branch",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="expenses",
    )
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    expense_date = models.DateField(default=timezone.localdate)
    vendor = models.CharField(max_length=200, blank=True, help_text=_("Supplier / payee name"))
    payment_method = models.CharField(
        max_length=20, choices=PaymentMethod.choices, default=PaymentMethod.CASH,
    )
    receipt_number = models.CharField(max_length=100, blank=True, help_text=_("Supplier receipt or cheque number"))
    description = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.APPROVED)
    approved_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="approved_expenses",
    )
    approved_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="created_expenses",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if not self.reference_number:
            year = self.expense_date.year if self.expense_date else timezone.localdate().year
            last = Expense.objects.filter(
                reference_number__startswith=f"EXP-{year}-"
            ).order_by("-reference_number").first()
            seq = 1
            if last and last.reference_number:
                try:
                    seq = int(last.reference_number.split("-")[-1]) + 1
                except ValueError:
                    pass
            self.reference_number = f"EXP-{year}-{seq:05d}"
        super().save(*args, **kwargs)

    def __str__(self):
        cat = self.category.name if self.category else "Uncategorised"
        return f"{self.reference_number} — {cat} UGX {self.amount:,.0f}"

    class Meta:
        verbose_name = _("Expense")
        verbose_name_plural = _("Expenses")
        ordering = ["-expense_date", "-created_at"]
        indexes = [
            models.Index(fields=["expense_date"]),
            models.Index(fields=["category"]),
            models.Index(fields=["status"]),
        ]


class CapitalInjection(models.Model):
    class PaymentMethod(models.TextChoices):
        CASH         = "CASH",         _("Cash")
        BANK         = "BANK",         _("Bank Transfer")
        MOBILE_MONEY = "MOBILE_MONEY", _("Mobile Money")

    source = models.CharField(max_length=200)
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    injected_date = models.DateField(default=timezone.localdate)
    payment_method = models.CharField(
        max_length=20, choices=PaymentMethod.choices, default=PaymentMethod.CASH,
    )
    branch = models.ForeignKey(
        "accounts.Branch", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="capital_injections",
    )
    investor = models.CharField(max_length=200, blank=True)
    investor_record = models.ForeignKey(
        "accounts.Investor",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="capital_injections",
    )
    attracts_interest = models.BooleanField(
        default=False,
        help_text=_("Apply the configured annual savings interest rate to this injection."),
    )
    interest_rate_annual = models.DecimalField(
        max_digits=5, decimal_places=2, default=0,
        help_text=_("Annual interest rate snapshotted when this injection was recorded."),
    )
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="created_injections",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Capital injection UGX {self.amount:,.0f} from {self.source} on {self.injected_date}"

    @property
    def investor_name(self):
        return self.investor_record.name if self.investor_record else self.investor

    class Meta:
        verbose_name = _("Capital Injection")
        verbose_name_plural = _("Capital Injections")
        ordering = ["-injected_date", "-created_at"]
        indexes = [models.Index(fields=["injected_date"])]


class Investor(models.Model):
    class InvestorType(models.TextChoices):
        INDIVIDUAL = "INDIVIDUAL", _("Individual")
        COMPANY = "COMPANY", _("Company")
        PARTNERSHIP = "PARTNERSHIP", _("Partnership")

    class Status(models.TextChoices):
        ACTIVE = "ACTIVE", _("Active")
        INACTIVE = "INACTIVE", _("Inactive")
        PROSPECT = "PROSPECT", _("Prospect")

    name = models.CharField(max_length=200)
    investor_type = models.CharField(
        max_length=20, choices=InvestorType.choices, default=InvestorType.INDIVIDUAL,
    )
    phone = models.CharField(max_length=20, blank=True)
    email = models.EmailField(blank=True)
    national_id = models.CharField(max_length=100, blank=True)
    address = models.CharField(max_length=255, blank=True)
    committed_amount = models.DecimalField(
        max_digits=15, decimal_places=2, default=0,
        validators=[MinValueValidator(Decimal("0.00"))],
    )
    investment_date = models.DateField(null=True, blank=True)
    maturity_date = models.DateField(null=True, blank=True)
    payment_method = models.CharField(
        max_length=20, choices=CapitalInjection.PaymentMethod.choices,
        default=CapitalInjection.PaymentMethod.BANK,
    )
    status = models.CharField(
        max_length=10, choices=Status.choices, default=Status.ACTIVE,
    )
    branch = models.ForeignKey(
        "accounts.Branch", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="investors",
    )
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        "accounts.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_investors",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = _("Investor")
        verbose_name_plural = _("Investors")
        ordering = ["name"]
        indexes = [
            models.Index(fields=["name"]),
            models.Index(fields=["status"]),
            models.Index(fields=["investment_date"]),
        ]


class InvestorDrawing(models.Model):
    """A withdrawal/drawing made against an investor's capital account."""

    investor = models.ForeignKey(
        Investor, on_delete=models.PROTECT, related_name="drawings",
    )
    amount = models.DecimalField(
        max_digits=15, decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    drawing_date = models.DateField(default=timezone.localdate)
    payment_method = models.CharField(
        max_length=20, choices=CapitalInjection.PaymentMethod.choices,
        default=CapitalInjection.PaymentMethod.BANK,
    )
    purpose = models.CharField(max_length=255, blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        "accounts.User", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="created_investor_drawings",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Drawing UGX {self.amount:,.0f} from {self.investor.name}"

    class Meta:
        ordering = ["-drawing_date", "-created_at"]
        indexes = [models.Index(fields=["investor", "drawing_date"])]


class SalesAdjustment(models.Model):
    class Direction(models.TextChoices):
        CASH_IN = "CASH_IN", _("Cash In")
        CASH_OUT = "CASH_OUT", _("Cash Out")

    reference = models.CharField(max_length=100, unique=True)
    direction = models.CharField(max_length=10, choices=Direction.choices)
    amount = models.DecimalField(
        max_digits=15,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
    )
    adjustment_date = models.DateField(default=timezone.localdate)
    branch = models.ForeignKey(
        "accounts.Branch",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="sales_adjustments",
    )
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_sales_adjustments",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.reference} — {self.get_direction_display()} UGX {self.amount:,.0f}"

    class Meta:
        ordering = ["-adjustment_date", "-created_at"]
        indexes = [models.Index(fields=["adjustment_date"])]
        constraints = [
            models.CheckConstraint(
                check=models.Q(amount__gt=0),
                name="sales_adjustment_amount_positive",
            ),
        ]


class BankAccount(models.Model):
    """Institution's own bank accounts for tracking balances and reconciliation."""

    class AccountType(models.TextChoices):
        CURRENT  = "CURRENT",  _("Current Account")
        SAVINGS  = "SAVINGS",  _("Savings Account")
        FIXED    = "FIXED",    _("Fixed Deposit")
        MOBILE   = "MOBILE",   _("Mobile Money")

    account_name   = models.CharField(max_length=200)
    account_number = models.CharField(max_length=50, unique=True)
    bank_name      = models.CharField(max_length=200)
    branch_name    = models.CharField(max_length=200, blank=True)
    account_type   = models.CharField(max_length=10, choices=AccountType.choices, default=AccountType.CURRENT)
    currency       = models.CharField(max_length=10, default="UGX")
    opening_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    current_balance = models.DecimalField(max_digits=15, decimal_places=2, default=0)
    is_active      = models.BooleanField(default=True)
    notes          = models.TextField(blank=True)
    created_at     = models.DateTimeField(auto_now_add=True)
    updated_at     = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.account_name} — {self.bank_name} ({self.account_number})"

    class Meta:
        verbose_name = _("Bank Account")
        verbose_name_plural = _("Bank Accounts")
        ordering = ["bank_name", "account_name"]


class BankTransaction(models.Model):
    class TransactionType(models.TextChoices):
        CREDIT = "CREDIT", _("Credit")
        DEBIT = "DEBIT", _("Debit")

    branch = models.ForeignKey(
        "accounts.Branch",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="bank_transactions",
    )
    bank_account = models.ForeignKey(
        BankAccount,
        on_delete=models.PROTECT,
        related_name="transactions",
    )
    category = models.CharField(max_length=200, blank=True)
    transaction_type = models.CharField(
        max_length=10,
        choices=TransactionType.choices,
        default=TransactionType.CREDIT,
    )
    amount = models.DecimalField(max_digits=15, decimal_places=2)
    transaction_date = models.DateTimeField(default=timezone.now)
    reference_number = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="bank_transactions_created",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.get_transaction_type_display()} UGX {self.amount:,.0f} — {self.bank_account}"

    class Meta:
        verbose_name = _("Bank Transaction")
        verbose_name_plural = _("Bank Transactions")
        ordering = ["-transaction_date", "bank_account"]
        indexes = [
            models.Index(fields=["transaction_date"]),
            models.Index(fields=["branch"]),
            models.Index(fields=["transaction_type"]),
        ]


class AuditLog(models.Model):
    """
    Detailed audit trail for important actions in the system.
    This complements django-auditlog by capturing business-level events.
    """
    class Action(models.TextChoices):
        CREATE = "CREATE", _("Create")
        UPDATE = "UPDATE", _("Update")
        DELETE = "DELETE", _("Delete")
        APPROVE = "APPROVE", _("Approve")
        REJECT = "REJECT", _("Reject")
        DISBURSE = "DISBURSE", _("Disburse")
        PAYMENT = "PAYMENT", _("Payment")
        REVERSE = "REVERSE", _("Reverse")
        WAIVE = "WAIVE", _("Waive")
        RESTRUCTURE = "RESTRUCTURE", _("Restructure")
        WRITE_OFF = "WRITE_OFF", _("Write Off")
        LOGIN = "LOGIN", _("Login")
        LOGOUT = "LOGOUT", _("Logout")
        OTHER = "OTHER", _("Other")

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name="audit_logs",
    )
    action = models.CharField(max_length=20, choices=Action.choices)
    entity_type = models.CharField(max_length=100, help_text=_("Type of entity affected, e.g., Loan, Client"))
    entity_id = models.CharField(max_length=100, help_text=_("ID of the entity affected"))
    entity_repr = models.CharField(max_length=500, help_text=_("String representation of the entity"))
    changes = models.JSONField(
        default=dict, blank=True,
        help_text=_("JSON representation of changes made"),
    )
    ip_address = models.GenericIPAddressField(null=True, blank=True)
    user_agent = models.TextField(blank=True)
    remarks = models.TextField(blank=True, help_text=_("Additional notes about this action"))
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    def __str__(self):
        return f"{self.get_action_display()} - {self.entity_type} #{self.entity_id} by {self.user}"

    class Meta:
        verbose_name = _("Audit Log")
        verbose_name_plural = _("Audit Logs")
        ordering = ["-created_at"]
        indexes = [
            models.Index(fields=["entity_type", "entity_id"]),
            models.Index(fields=["user", "created_at"]),
            models.Index(fields=["action"]),
        ]


class ReceiptSequence(models.Model):
    """Concurrency-safe sequence counter for receipt numbers."""
    name = models.CharField(max_length=32, unique=True)
    last = models.PositiveBigIntegerField(default=0)

    def __str__(self):
        return f"{self.name}:{self.last}"


class SystemParameter(models.Model):
    """
    Key-value store for system-wide parameters that may need to be adjusted
    without code changes. Useful for feature flags and configuration values.
    """
    key = models.CharField(max_length=100, unique=True)
    value = models.TextField(help_text=_("Parameter value (stored as text)"))
    value_type = models.CharField(
        max_length=20,
        choices=[
            ("STRING", "String"),
            ("INTEGER", "Integer"),
            ("DECIMAL", "Decimal"),
            ("BOOLEAN", "Boolean"),
            ("JSON", "JSON"),
        ],
        default="STRING",
    )
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    updated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True, blank=True,
    )

    def __str__(self):
        return f"{self.key} = {self.value}"

    class Meta:
        verbose_name = _("System Parameter")
        verbose_name_plural = _("System Parameters")
        ordering = ["key"]