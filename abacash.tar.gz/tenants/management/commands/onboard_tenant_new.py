"""
python manage.py onboard_tenant \
    --schema=sacco_kampala \
    --name="Sacco Kampala MFI" \
    --domain=sacco-kampala.yourdomain.com \
    --email=admin@sacco.com \
    --password=SecurePassword123 \
    --notify
"""
from django.core.management.base import BaseCommand, CommandError
from django_tenants.utils import schema_context
import logging
import os
from tenants.provisioning import (
    _seed_branch as seed_branch,
    _seed_expense_categories as seed_expense_categories,
    _seed_products as seed_products,
)

logger = logging.getLogger(__name__)

PLANS = {
    "STARTER":      {"manager_limit": 5_000_000,   "max_loans": 2},
    "PROFESSIONAL": {"manager_limit": 20_000_000,  "max_loans": 3},
    "ENTERPRISE":   {"manager_limit": 999_999_999, "max_loans": 5},
}

class Command(BaseCommand):
    help = "Provision a new tenant: schema + migrations + seed data + CEO user."

    def add_arguments(self, parser):
        parser.add_argument("--schema",   required=True)
        parser.add_argument("--name",     required=True)
        parser.add_argument("--domain",   required=True)
        parser.add_argument("--email",    required=True)
        parser.add_argument("--password", default="ChangeMe123!")
        parser.add_argument("--plan",     default="STARTER", choices=PLANS.keys())
        parser.add_argument("--phone",    default="")
        parser.add_argument("--address",  default="")
        parser.add_argument("--company-email", default="", help="Optional contact email for company settings.")
        parser.add_argument("--notify", action="store_true", default=False, help="Send password reset link to the company contact email after provisioning.")

    def handle(self, *args, **options):
        schema   = options["schema"].lower().replace("-", "_")
        name     = options["name"]
        domain   = options["domain"]
        email    = options["email"]
        password = options["password"]
        plan     = options["plan"]
        company_email = options["company_email"] or email

        # Setup logging to capture output to a file
        log_file = self._setup_logging(schema)

        self._header(name, schema, domain, plan)

        # ── 1. Tenant + domain ──────────────────────────────────────────
        self._step("1", "Creating tenant & domain")
        from tenants.models import Company, Domain

        if Company.objects.filter(schema_name=schema).exists():
            raise CommandError(f"Schema '{schema}' already exists.")

        company = Company(schema_name=schema, name=name, is_active=True, plan=plan)
        company.save()
        self.stdout.write(f"    ✔  Schema '{schema}' created")

        Domain.objects.create(domain=domain, tenant=company, is_primary=True)
        self.stdout.write(f"    ✔  Domain '{domain}' mapped")

        # Run tenant migrations for the newly created schema before seeding
        try:
            from django.core import management as django_management
            self._step("1a", "Applying tenant migrations")
            django_management.call_command('migrate_schemas', schema_name=schema, verbosity=1)
            self.stdout.write("    ✔  Tenant migrations applied")
        except Exception as exc:
            error_msg = f"Tenant migrations failed for schema '{schema}': {exc}"
            self.stdout.write(self.style.ERROR(f"    ✖  {error_msg}"))
            logger.error(error_msg, exc_info=True)
            raise CommandError(error_msg)

        # ── 2. Seed inside schema ───────────────────────────────────────
        self._step("2", "Seeding schema data")
        plan_cfg = PLANS[plan]

        created_user = None
        with schema_context(schema):
            self._seed_settings(name, options["phone"], options["address"], plan_cfg, company_email)
            branch = seed_branch(name, options["phone"], options["address"], company_email)
            self._seed_sequence("accounts.models", "ReceiptSequence", "receipt")
            self._seed_sequence("loans.models",    "LoanSequence",    "loans")
            self._seed_products()
            seed_expense_categories()
            created_user = self._create_ceo(name, email)
            if branch is not None:
                from accounts.models import User
                User.objects.filter(branch__isnull=True).update(branch=branch)

        self._summary(name, schema, domain, email, plan)

        # ── 3. Optional notification to company contact (send password-reset link) ─────────────────
        notify = bool(options.get('notify'))
        if notify and company_email:
            try:
                from django.core.mail import send_mail
                from django.conf import settings
                # Build a password reset link for the created admin user
                reset_url = None
                if created_user is not None:
                    try:
                        from django.contrib.auth.tokens import default_token_generator
                        from django.utils.http import urlsafe_base64_encode
                        from django.utils.encoding import force_bytes
                        from django.urls import reverse

                        uid = urlsafe_base64_encode(force_bytes(created_user.pk))
                        token = default_token_generator.make_token(created_user)
                        try:
                            path = reverse('password_reset_confirm', args=[uid, token])
                            reset_url = f"https://{domain}{path}"
                        except Exception:
                            reset_url = f"https://{domain}/accounts/reset/{uid}/{token}/"
                    except Exception as e:
                        self.stdout.write(self.style.WARNING(f"    ⚠  Could not generate reset link: {e}"))
                        reset_url = f"https://{domain}/accounts/login/"

                subject = f"Your Abacash tenant '{name}' is ready"
                if reset_url and 'accounts/reset' in reset_url:
                    body = (
                        f"Hello,\n\n"
                        f"Your Abacash tenant has been provisioned. To complete setup, use the administrator account and set your password by following the secure link below:\n\n"
                        f"Tenant: {name}\n"
                        f"Domain: {domain}\n"
                        f"Administrator email: {email}\n\n"
                        f"Open this link to complete your password creation: {reset_url}\n\n"
                        "The password entry screen will open with your username prefilled. For security, the link can only be used once. If you did not request this, contact support@abacash.loan immediately.\n\n"
                        "Best regards,\nAbacash Onboarding Team"
                    )
                else:
                    body = (
                        f"Hello,\n\n"
                        f"Your Abacash tenant has been provisioned. Sign in at https://{domain}/accounts/login/ and use the password reset flow to set your administrator password.\n\n"
                        "If you did not request this, contact support@abacash.loan immediately.\n\n"
                        "Best regards,\nAbacash Onboarding Team"
                    )

                from_email = getattr(settings, 'DEFAULT_FROM_EMAIL', getattr(settings, 'EMAIL_HOST_USER', 'support@abacash.loan'))
                send_mail(subject, body, from_email, [company_email], fail_silently=False)
                self.stdout.write(self.style.SUCCESS(f"    ✔  Sent password reset instructions to {company_email}"))
                logger.info(f"Sent password reset email for tenant {schema} to {company_email}")
            except Exception as exc:
                warning_msg = f"Failed to send credentials email: {exc}"
                self.stdout.write(self.style.WARNING(f"    ⚠  {warning_msg}"))
                logger.warning(warning_msg, exc_info=True)

        self.stdout.write(self.style.SUCCESS(f"\n✅ Onboarding complete! Logs: {log_file}\n"))

    # ── helpers ─────────────────────────────────────────────────────────

    def _setup_logging(self, schema):
        """Setup file-based logging for this onboarding job."""
        from django.conf import settings
        logs_dir = getattr(settings, 'LOGS_DIR', os.path.join(getattr(settings, 'BASE_DIR', os.getcwd()), 'logs'))
        os.makedirs(logs_dir, exist_ok=True)
        log_file = os.path.join(logs_dir, f"onboard_{schema}.log")
        
        # Add file handler to the logger
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('[%(asctime)s] %(levelname)s: %(message)s')
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
        
        return log_file

    def _seed_settings(self, name, phone, address, plan_cfg, company_email):
        from accounts.models import CompanySettings, DEFAULT_PROCESSING_FEE_RANGES
        _, created = CompanySettings.objects.get_or_create(pk=1, defaults={
            "company_name": name,
            "company_phone": phone,
            "company_address": address,
            "company_email": company_email,
            "manager_approval_limit": plan_cfg["manager_limit"],
            "max_active_loans_per_client": plan_cfg["max_loans"],
            "processing_fee_method": "RANGE",
            "processing_fee_ranges": DEFAULT_PROCESSING_FEE_RANGES,
            "currency_symbol": "UGX",
        })
        self.stdout.write(f"    ✔  CompanySettings {'created' if created else 'exists'}")

    def _seed_sequence(self, module_path, model_name, seq_name):
        import importlib
        mod = importlib.import_module(module_path)
        Model = getattr(mod, model_name)
        _, created = Model.objects.get_or_create(name=seq_name, defaults={"last": 0})
        self.stdout.write(f"    ✔  {model_name}({seq_name}) {'created' if created else 'exists'}")

    def _seed_products(self):
        n = seed_products()
        self.stdout.write(f"    ✔  {n} loan products seeded")

    def _create_ceo(self, company_name, email, password=None):
        """Create CEO user with no usable password; expects password reset via email link."""
        from django.contrib.auth import get_user_model
        User = get_user_model()
        
        try:
            existing = User.objects.filter(email=email).first()
            if existing:
                self.stdout.write(f"    ⚠  CEO '{email}' already exists")
                return existing
        except Exception:
            return None

        username = base = email.split("@")[0]
        i = 1
        while User.objects.filter(username=username).exists():
            username = f"{base}{i}"; i += 1

        try:
            user = User.objects.create_user(username=username, email=email)
        except TypeError:
            user = User(username=username, email=email)
            user.save()

        try:
            user.set_unusable_password()
        except Exception:
            pass
        try:
            user.first_name = company_name.split()[0] if company_name else ''
        except Exception:
            pass
        try:
            if hasattr(user, 'role'):
                user.role = "CEO"
        except Exception:
            pass
        user.is_staff = True
        user.is_superuser = True
        user.save()

        self.stdout.write(f"    ✔  CEO '{email}' created (username: {username})")
        return user

    def _step(self, n, label):
        self.stdout.write("")
        self.stdout.write(self.style.HTTP_INFO(f"  ── Step {n}: {label}"))

    def _header(self, name, schema, domain, plan):
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("╔══════════════════════════════════════════╗"))
        self.stdout.write(self.style.SUCCESS("║   Abacash — Tenant Onboarding            ║"))
        self.stdout.write(self.style.SUCCESS("╚══════════════════════════════════════════╝"))
        self.stdout.write(f"  Company : {name}")
        self.stdout.write(f"  Schema  : {schema}")
        self.stdout.write(f"  Domain  : {domain}")
        self.stdout.write(f"  Plan    : {plan}")

    def _summary(self, name, schema, domain, email, plan):
        self.stdout.write("")
        self.stdout.write(self.style.SUCCESS("╔══════════════════════════════════════════╗"))
        self.stdout.write(self.style.SUCCESS("║  ✅  Onboarding complete!                ║"))
        self.stdout.write(self.style.SUCCESS("╚══════════════════════════════════════════╝"))
        self.stdout.write(f"\n  Login  → https://{domain}/accounts/login/")
        self.stdout.write(f"  Email  → {email}")
        self.stdout.write(f"  Plan   → {plan}\n")
        self.stdout.write("  Next: point DNS, issue SSL cert, configure logo & branches.\n")
