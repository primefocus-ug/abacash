import json
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP
from io import BytesIO
from types import SimpleNamespace

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.files.base import ContentFile
from django.test import RequestFactory, SimpleTestCase, TestCase
from django.urls import reverse
from django.utils import timezone
from PIL import Image
from unittest.mock import Mock, patch

from accounts.models import CompanySettings
from clients.models import Client
from common.pdf_utils import generate_loan_calculator_pdf, generate_loan_schedule_pdf
from loans import views as loan_views
from loans.models import Loan, LoanProduct
from loans.utils import (
    calculate_penalty,
    calculate_processing_fee_amount,
    resolve_processing_fee_rate,
)


class _RelatedList(list):
    def all(self):
        return self

    def exists(self):
        return bool(self)

    def order_by(self, *fields):
        return self

    def select_related(self, *fields):
        return self


class ProcessingFeeResolutionTests(SimpleTestCase):
    def test_new_company_settings_use_default_range_fees(self):
        settings = CompanySettings()
        self.assertEqual(settings.processing_fee_method, "RANGE")
        self.assertEqual(
            settings.penalty_frequency,
            CompanySettings.PenaltyFrequency.MONTHLY,
        )
        self.assertEqual(
            settings.processing_fee_ranges,
            "0-50000:4000\n"
            "100000-200000:8000\n"
            "200001-300001:10000\n"
            "300001-450000:12000\n"
            "450001-600000:15000\n"
            "600001-800000:20000\n"
            "800001-1000000:30000\n"
            "1000001-:40000",
        )

    def test_range_fees_match_configured_inclusive_tiers_and_gaps(self):
        settings = CompanySettings()
        cases = (
            ("50000", "4000"),
            ("50001", "0"),
            ("99999", "0"),
            ("100000", "8000"),
            ("200000", "8000"),
            ("200001", "10000"),
            ("300001", "10000"),
            ("300002", "12000"),
            ("450000", "12000"),
            ("450001", "15000"),
            ("600001", "20000"),
            ("800001", "30000"),
            ("1000000", "30000"),
            ("1000001", "40000"),
        )

        for principal, expected_fee in cases:
            with self.subTest(principal=principal):
                self.assertEqual(
                    calculate_processing_fee_amount(Decimal(principal), company_settings=settings),
                    Decimal(expected_fee),
                )

    def test_uses_product_rate_when_available(self):
        product = SimpleNamespace(processing_fee_percent=Decimal("1.50"))

        self.assertEqual(resolve_processing_fee_rate(product), Decimal("1.50"))

    def test_falls_back_to_company_default_when_product_is_missing(self):
        settings = CompanySettings(
            processing_fee_method="PERCENTAGE",
            default_processing_fee_percent=Decimal("2.25"),
        )

        self.assertEqual(resolve_processing_fee_rate(None, settings), Decimal("2.25"))

    def test_disabled_product_has_no_processing_fee_even_with_company_rate(self):
        settings = CompanySettings(
            processing_fee_method="PERCENTAGE",
            default_processing_fee_percent=Decimal("2.25"),
        )
        product = SimpleNamespace(
            processing_fee_enabled=False,
            processing_fee_percent=Decimal("1.00"),
        )

        self.assertEqual(
            calculate_processing_fee_amount(
                Decimal("1000000"),
                product=product,
                company_settings=settings,
            ),
            Decimal("0"),
        )
        self.assertEqual(resolve_processing_fee_rate(product, settings), Decimal("0"))

    def test_ceo_override_can_calculate_a_disabled_products_processing_fee(self):
        settings = CompanySettings(
            processing_fee_method="PERCENTAGE",
            default_processing_fee_percent=Decimal("2.25"),
        )
        product = SimpleNamespace(
            processing_fee_enabled=False,
            processing_fee_percent=Decimal("1.00"),
        )

        self.assertEqual(
            calculate_processing_fee_amount(
                Decimal("1000000"),
                product=product,
                company_settings=settings,
                allow_disabled_product_fee=True,
            ),
            Decimal("22500.00"),
        )
        self.assertEqual(
            resolve_processing_fee_rate(
                product,
                settings,
                allow_disabled_product_fee=True,
            ),
            Decimal("2.25"),
        )

    def test_waived_loan_processing_fee_stays_zero(self):
        loan = Loan(
            principal_amount=Decimal("1000000"),
            processing_fee_enabled=False,
        )

        self.assertEqual(loan.effective_processing_fee, Decimal("0"))


class PenaltyCalculationTests(SimpleTestCase):
    def test_daily_penalty_applies_rate_for_each_overdue_day(self):
        self.assertEqual(
            calculate_penalty(
                Decimal("1000"),
                Decimal("2"),
                days_overdue=5,
                frequency="DAILY",
            ),
            Decimal("100.00"),
        )

    def test_monthly_penalty_applies_for_each_started_thirty_day_period(self):
        self.assertEqual(
            calculate_penalty(
                Decimal("1000"),
                Decimal("2"),
                days_overdue=31,
                frequency="MONTHLY",
            ),
            Decimal("40.00"),
        )

    def test_no_penalty_is_applied_before_overdue_period_starts(self):
        self.assertEqual(
            calculate_penalty(
                Decimal("1000"),
                Decimal("2"),
                days_overdue=0,
                frequency="DAILY",
            ),
            Decimal("0.00"),
        )

    def test_rejects_unknown_penalty_frequency(self):
        with self.assertRaises(ValueError):
            calculate_penalty(
                Decimal("1000"),
                Decimal("2"),
                days_overdue=5,
                frequency="WEEKLY",
            )


class CEOOnlyLoanActionTests(SimpleTestCase):
    def setUp(self):
        self.factory = RequestFactory()

    def _request(self, method, role):
        request = getattr(self.factory, method)("/")
        request.user = SimpleNamespace(role=role, is_authenticated=True)
        return request

    @patch("loans.views.messages.error")
    def test_non_ceo_cannot_regenerate_or_undo_schedule(self, show_error):
        actions = (
            (loan_views.loan_regenerate_schedule, "get"),
            (loan_views.loan_undo_regenerate_schedule, "post"),
        )
        for action, method in actions:
            with self.subTest(action=action.__name__):
                response = action(self._request(method, "MANAGER"), pk="loan-id")
                self.assertEqual(response.status_code, 302)
                self.assertEqual(response.url, reverse("accounts:dashboard"))
        self.assertEqual(show_error.call_count, 2)

    @patch("loans.views.messages.error")
    @patch("loans.views.get_object_or_404")
    def test_non_ceo_cannot_recall_an_application(self, get_object, show_error):
        response = loan_views.loan_recall(
            self._request("post", "MANAGER"),
            loan_id="loan-id",
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("accounts:dashboard"))
        get_object.assert_not_called()
        show_error.assert_called_once()

    @patch("loans.views.messages.success")
    @patch("loans.views.get_object_or_404")
    def test_ceo_can_delete_a_draft_loan(self, get_object, show_success):
        loan = SimpleNamespace(loan_number="LN-100", delete=Mock())
        get_object.return_value = loan

        response = loan_views.loan_draft_delete(
            self._request("post", "CEO"),
            pk="loan-id",
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("loans:list"))
        loan.delete.assert_called_once_with()
        show_success.assert_called_once()

    @patch("loans.views.messages.error")
    @patch("loans.views.get_object_or_404")
    def test_non_ceo_cannot_delete_a_draft_loan(self, get_object, show_error):
        response = loan_views.loan_draft_delete(
            self._request("post", "MANAGER"),
            pk="loan-id",
        )

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, reverse("accounts:dashboard"))
        get_object.assert_not_called()
        show_error.assert_called_once()


class LoanFeeSwitchTests(SimpleTestCase):
    def setUp(self):
        settings_patcher = patch(
            "loans.views.CompanySettings.get",
            return_value=SimpleNamespace(penalties_enabled=True),
        )
        settings_patcher.start()
        self.addCleanup(settings_patcher.stop)
        self.product = SimpleNamespace(
            pk=1,
            interest_method=LoanProduct.InterestMethod.FLAT_RATE,
            processing_fee_enabled=True,
            penalty_enabled=True,
        )

    def test_application_method_defaults_to_product_but_can_be_changed(self):
        self.assertEqual(
            loan_views._resolve_loan_interest_method(self.product, {}),
            LoanProduct.InterestMethod.FLAT_RATE,
        )
        self.assertEqual(
            loan_views._resolve_loan_interest_method(
                self.product,
                {"interest_method": LoanProduct.InterestMethod.INTEREST_ONLY},
            ),
            LoanProduct.InterestMethod.INTEREST_ONLY,
        )

    def test_application_keeps_existing_method_when_product_is_unchanged(self):
        existing_loan = SimpleNamespace(
            product_id=self.product.pk,
            interest_method=LoanProduct.InterestMethod.COMPOUND,
        )

        self.assertEqual(
            loan_views._resolve_loan_interest_method(self.product, {}, existing_loan),
            LoanProduct.InterestMethod.COMPOUND,
        )

    def test_application_user_without_permission_keeps_existing_method(self):
        existing_loan = SimpleNamespace(
            product_id=self.product.pk,
            interest_method=LoanProduct.InterestMethod.COMPOUND,
        )

        self.assertEqual(
            loan_views._resolve_loan_interest_method(
                self.product,
                {"interest_method": LoanProduct.InterestMethod.FLAT_RATE},
                existing_loan,
                can_change=False,
            ),
            LoanProduct.InterestMethod.COMPOUND,
        )

    def test_application_user_without_permission_uses_product_method_for_new_product(self):
        posted_method = LoanProduct.InterestMethod.COMPOUND

        self.assertEqual(
            loan_views._resolve_loan_interest_method(
                self.product,
                {"interest_method": posted_method},
                can_change=False,
            ),
            self.product.interest_method,
        )

    def test_invalid_application_method_is_rejected(self):
        with self.assertRaises(ValueError):
            loan_views._resolve_loan_interest_method(
                self.product,
                {"interest_method": "UNKNOWN"},
            )

    def test_ceo_can_waive_either_fee_for_an_application(self):
        processing_enabled, penalty_enabled = loan_views._resolve_loan_fee_switches(
            self.product,
            {"penalty_enabled": "on"},
            can_override=True,
        )

        self.assertFalse(processing_enabled)
        self.assertTrue(penalty_enabled)

    def test_ceo_can_override_product_fee_defaults(self):
        self.product.processing_fee_enabled = False
        self.product.penalty_enabled = False

        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {"processing_fee_enabled": "on", "penalty_enabled": "on"},
                can_override=True,
            ),
            (True, True),
        )

    @patch(
        "loans.views.CompanySettings.get",
        return_value=SimpleNamespace(penalties_enabled=False),
    )
    def test_tenant_can_disable_penalties_even_for_ceo_overrides(self, _get_settings):
        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {"processing_fee_enabled": "on", "penalty_enabled": "on"},
                can_override=True,
            ),
            (True, False),
        )

    @patch(
        "loans.views.CompanySettings.get",
        return_value=SimpleNamespace(penalties_enabled=False),
    )
    def test_tenant_can_disable_penalties_for_new_loans(self, _get_settings):
        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {},
                can_override=False,
            ),
            (True, False),
        )

    def test_non_ceo_cannot_enable_product_disabled_fees(self):
        self.product.processing_fee_enabled = False
        self.product.penalty_enabled = False

        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {"processing_fee_enabled": "on", "penalty_enabled": "on"},
                can_override=False,
            ),
            (False, False),
        )

    def test_non_ceo_reuses_existing_draft_fee_choices(self):
        existing_loan = SimpleNamespace(
            product_id=self.product.pk,
            processing_fee_enabled=False,
            penalty_enabled=False,
        )

        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {},
                can_override=False,
                existing_loan=existing_loan,
            ),
            (False, False),
        )

    def test_non_ceo_preserves_existing_ceo_fee_overrides(self):
        self.product.processing_fee_enabled = False
        self.product.penalty_enabled = False
        existing_loan = SimpleNamespace(
            product_id=self.product.pk,
            processing_fee_enabled=True,
            penalty_enabled=True,
        )

        self.assertEqual(
            loan_views._resolve_loan_fee_switches(
                self.product,
                {},
                can_override=False,
                existing_loan=existing_loan,
            ),
            (True, True),
        )


class LoanReviewDecisionTests(SimpleTestCase):
    def setUp(self):
        self.request_factory = RequestFactory()
        self.user = SimpleNamespace(
            is_authenticated=True,
            can=lambda codename: codename == "can_approve_loans",
        )
        self.loan = SimpleNamespace(
            pk="00000000-0000-0000-0000-000000000001",
            loan_number="LN-TEST-1",
            status=Loan.Status.PENDING,
            reviewed_by=None,
            query_reason="",
            rejection_reason="",
            save=Mock(),
        )

    def review_request(self, reason):
        request = self.request_factory.post(
            f"/loans/{self.loan.pk}/query/",
            {"review_reason": reason},
        )
        request.user = self.user
        return request

    def test_query_saves_reason_and_returns_loan_to_draft(self):
        reason = "Please provide the client's recent payslip."
        request = self.review_request(reason)

        with (
            patch("loans.views.get_object_or_404", return_value=self.loan),
            patch("loans.views.messages.success"),
        ):
            response = loan_views.loan_query(request, pk=self.loan.pk)

        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.loan.status, Loan.Status.DRAFT)
        self.assertEqual(self.loan.query_reason, reason)
        self.assertIs(self.loan.reviewed_by, self.user)
        self.loan.save.assert_called_once_with(
            update_fields=["status", "reviewed_by", "query_reason"]
        )

    def test_query_requires_a_reason(self):
        request = self.review_request("")

        with (
            patch("loans.views.get_object_or_404", return_value=self.loan),
            patch("loans.views.messages.error") as message_error,
        ):
            response = loan_views.loan_query(request, pk=self.loan.pk)

        self.assertEqual(response.status_code, 302)
        self.loan.save.assert_not_called()
        message_error.assert_called_once()

    def test_rejection_uses_shared_review_reason_field(self):
        reason = "Income is not sufficient for the requested amount."
        self.loan.query_reason = "Please provide income proof."
        request = self.review_request(reason)

        with (
            patch("loans.views.get_object_or_404", return_value=self.loan),
            patch("loans.views.messages.success"),
        ):
            response = loan_views.loan_reject(request, pk=self.loan.pk)

        self.assertEqual(response.status_code, 302)
        self.assertEqual(self.loan.status, Loan.Status.REJECTED)
        self.assertEqual(self.loan.rejection_reason, reason)
        self.assertEqual(self.loan.query_reason, "")
        self.assertIs(self.loan.reviewed_by, self.user)


class LoanCalculatorPreviewTests(SimpleTestCase):
    def setUp(self):
        self.request_factory = RequestFactory()

    def calculator_request(self, params):
        request = self.request_factory.get("/loans/calculator/preview/", params)
        request.user = SimpleNamespace(is_authenticated=True)
        return request

    def test_returns_schedule_estimates_for_selected_method_and_frequency(self):
        schedule = [
            {"total_payment": Decimal("100.00")},
            {"total_payment": Decimal("110.00")},
        ]
        totals = {
            "total_interest": Decimal("10.00"),
            "total_repayable": Decimal("210.00"),
        }
        request = self.calculator_request({
            "principal": "1000",
            "monthly_rate": "5",
            "term_months": "1",
            "frequency": "BIWEEKLY",
            "method": "INTEREST_ONLY",
        })

        with patch("loans.views.generate_schedule", return_value=(schedule, totals)) as generate:
            response = loan_views.loan_calculator_preview(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(json.loads(response.content), {
            "period_count": 2,
            "total_interest": "10.0000",
            "total_repayable": "210.0000",
            "average_payment": "105.0000",
            "first_payment": "100.0000",
            "final_payment": "110.0000",
        })
        self.assertEqual(generate.call_args.kwargs["annual_rate"], Decimal("60"))
        self.assertEqual(generate.call_args.kwargs["method"], "INTEREST_ONLY")
        self.assertEqual(generate.call_args.kwargs["frequency"], "BIWEEKLY")
        self.assertEqual(generate.call_args.kwargs["decimal_places"], 4)

    def test_returns_estimates_rounded_to_four_decimal_places(self):
        response = loan_views.loan_calculator_preview(self.calculator_request({
            "principal": "1234.5678",
            "monthly_rate": "1.2345",
            "term_months": "1",
            "frequency": "MONTHLY",
            "method": "FLAT",
        }))

        payload = json.loads(response.content)
        expected_interest = (
            Decimal("1234.5678") * Decimal("1.2345") / Decimal("100")
        ).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(payload["total_interest"], f"{expected_interest:.4f}")
        self.assertEqual(
            payload["total_repayable"],
            f"{Decimal('1234.5678') + expected_interest:.4f}",
        )
        self.assertEqual(payload["average_payment"], payload["total_repayable"])
        self.assertEqual(payload["first_payment"], payload["total_repayable"])
        self.assertEqual(payload["final_payment"], payload["total_repayable"])

    def test_weekly_flat_rate_example_reports_expected_figures(self):
        response = loan_views.loan_calculator_preview(self.calculator_request({
            "principal": "300000",
            "monthly_rate": "5",
            "term_months": "12",
            "frequency": "WEEKLY",
            "method": "FLAT",
        }))

        self.assertEqual(json.loads(response.content), {
            "period_count": 48,
            "total_interest": "180000.0000",
            "total_repayable": "480000.0000",
            "average_payment": "10000.0000",
            "first_payment": "10000.0000",
            "final_payment": "10000.0000",
        })

    def test_rejects_invalid_calculator_input(self):
        response = loan_views.loan_calculator_preview(self.calculator_request({
            "principal": "0",
            "monthly_rate": "5",
            "term_months": "12",
            "frequency": "MONTHLY",
            "method": "FLAT",
        }))

        self.assertEqual(response.status_code, 400)
        self.assertIn("error", json.loads(response.content))

    def test_pdf_endpoint_returns_a_tenant_branded_attachment(self):
        request = self.calculator_request({
            "principal": "1000",
            "monthly_rate": "5",
            "term_months": "1",
            "frequency": "MONTHLY",
            "method": "FLAT",
        })
        request.path = "/loans/calculator/pdf/"
        settings = SimpleNamespace(company_name="North Star Finance")
        schedule = [{
            "period_number": 1,
            "due_date": date(2026, 12, 14),
            "principal_due": Decimal("1000"),
            "interest_due": Decimal("50"),
            "total_payment": Decimal("1050"),
            "closing_balance": Decimal("0"),
        }]
        totals = {
            "total_interest": Decimal("50"),
            "total_repayable": Decimal("1050"),
        }

        with (
            patch("loans.views.generate_schedule", return_value=(schedule, totals)),
            patch("loans.views.CompanySettings.get", return_value=settings),
            patch("loans.views.generate_loan_calculator_pdf", return_value=b"%PDF-test") as make_pdf,
        ):
            response = loan_views.loan_calculator_pdf(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "application/pdf")
        self.assertIn("attachment", response["Content-Disposition"])
        self.assertEqual(response.content, b"%PDF-test")
        self.assertIs(make_pdf.call_args.kwargs["company_settings"], settings)

    def test_branded_pdf_generator_returns_a_pdf_document(self):
        settings = SimpleNamespace(
            company_name="North Star Finance",
            company_address="Kampala",
            company_phone="+256700000000",
            company_email="hello@example.test",
            company_website="",
            company_registration="",
            tax_identification="",
            currency_symbol="UGX",
            company_logo=None,
        )
        schedule = [{
            "period_number": 1,
            "due_date": date(2026, 12, 14),
            "principal_due": Decimal("1000"),
            "interest_due": Decimal("50"),
            "total_payment": Decimal("1050"),
            "closing_balance": Decimal("0"),
        }]
        pdf = generate_loan_calculator_pdf(
            company_settings=settings,
            schedule=schedule,
            totals={
                "total_interest": Decimal("50"),
                "total_repayable": Decimal("1050"),
            },
            principal=Decimal("1000"),
            monthly_rate=Decimal("5"),
            term_months=1,
            frequency_label="Monthly",
            method_label="Flat Rate",
        )

        self.assertTrue(pdf.startswith(b"%PDF-"))


class LoanApplicationSchedulePreviewTests(SimpleTestCase):
    def setUp(self):
        self.request_factory = RequestFactory()

    def test_incomplete_stage_two_terms_show_an_actionable_preview_message(self):
        request = self.request_factory.get("/loans/schedule-preview/", {
            "product": "",
            "principal": "",
            "term_months": "1",
            "frequency": "MONTHLY",
        })
        request.user = SimpleNamespace(is_authenticated=True)

        response = loan_views.schedule_preview(request)

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Select a product and enter a positive loan amount")

    def test_valid_stage_two_terms_build_a_schedule_for_the_live_preview(self):
        product = SimpleNamespace(
            name="Short Term",
            interest_rate_monthly=Decimal("2"),
        )
        request = self.request_factory.get(
            "/loans/schedule-preview/",
            {
                "product": "7",
                "principal": "500",
                "term_months": "3",
                "frequency": "WEEKLY",
            },
        )
        request.user = SimpleNamespace(is_authenticated=True, can=lambda _permission: False)
        schedule_rows = [SimpleNamespace(period=1)]
        totals = {
            "total_interest": Decimal("12"),
            "total_repayable": Decimal("512"),
        }

        with (
            patch("loans.views.LoanProduct.objects.filter") as filter_products,
            patch("loans.views._get_schedule_preview_draft", return_value=None),
            patch("loans.views._resolve_loan_interest_method", return_value="FLAT"),
            patch("loans.views._resolve_loan_fee_switches", return_value=(False, False)),
            patch("loans.views.generate_schedule", return_value=(schedule_rows, totals)) as generate,
            patch("loans.views.render", return_value=SimpleNamespace(status_code=200)) as render,
        ):
            filter_products.return_value.first.return_value = product
            response = loan_views.schedule_preview(request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(generate.call_args.kwargs["frequency"], "WEEKLY")
        self.assertEqual(render.call_args.args[2]["schedule_rows"], schedule_rows)
        self.assertEqual(render.call_args.args[2]["totals"], totals)

    def test_print_preview_uses_saved_draft_terms_on_later_stages(self):
        client = SimpleNamespace(pk="client-id", client_number="C-1")
        product = SimpleNamespace(pk=7)
        draft = SimpleNamespace(
            pk="draft-id",
            product_id=7,
            product=product,
            principal_amount=Decimal("125000"),
            term_months=6,
            repayment_frequency="WEEKLY",
        )
        request = self.request_factory.get(
            "/loans/apply/client-id/schedule-pdf/",
            {"draft_id": draft.pk},
        )
        request.user = SimpleNamespace(is_authenticated=True, can=lambda _permission: False)

        with (
            patch("loans.views.get_object_or_404", side_effect=[client, product]),
            patch("loans.views._get_schedule_preview_draft", return_value=draft),
            patch("loans.views._resolve_loan_interest_method", return_value="FLAT"),
            patch("loans.views._resolve_loan_fee_switches", return_value=(False, False)),
            patch(
                "loans.views.build_loan_schedule_context",
                return_value=([], {}, Decimal("0"), Decimal("0"), ""),
            ) as build_schedule,
            patch("loans.utils.generate_schedule_preview_pdf", return_value=b"%PDF-preview"),
        ):
            response = loan_views.schedule_preview_pdf(request, client_id=client.pk)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response["Content-Type"], "application/pdf")
        self.assertEqual(build_schedule.call_args.kwargs["principal"], Decimal("125000"))
        self.assertEqual(build_schedule.call_args.kwargs["term_months"], 6)
        self.assertEqual(build_schedule.call_args.kwargs["frequency"], "WEEKLY")


class LoanProductCreateDefaultsTests(SimpleTestCase):
    def test_new_product_form_defaults_to_active(self):
        request = RequestFactory().get("/loans/products/new/")
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)

        with patch("loans.views.render") as render:
            loan_views.loan_product_create(request)

        context = render.call_args.args[2]
        self.assertTrue(context["product_form_defaults"]["is_active"])
        self.assertFalse(context["product_form_defaults"]["requires_collateral"])
        self.assertTrue(context["product_form_defaults"]["penalty_enabled"])
        self.assertTrue(context["product_form_defaults"]["processing_fee_enabled"])
        self.assertEqual(
            context["product_form_defaults"]["interest_method"],
            LoanProduct.InterestMethod.FLAT_RATE,
        )
        self.assertIn(
            (LoanProduct.InterestMethod.COMPOUND, "Compound Interest"),
            context["interest_method_choices"],
        )
        self.assertIn(
            (LoanProduct.InterestMethod.INTEREST_ONLY, "Interest Only"),
            context["interest_method_choices"],
        )

    def test_htmx_request_renders_product_creation_popover(self):
        request = RequestFactory().get(
            "/loans/products/new/",
            HTTP_HX_REQUEST="true",
        )
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)

        with patch("loans.views.render") as render:
            loan_views.loan_product_create(request)

        self.assertEqual(render.call_args.args[1], "loans/product_form_modal.html")

    def test_htmx_product_create_redirects_to_product_list(self):
        request = RequestFactory().post(
            "/loans/products/new/",
            {
                "name": "Short Term",
                "interest_rate_monthly": "2",
                "interest_method": "FLAT",
                "default_repayment_frequency": "MONTHLY",
                "min_amount": "100000",
                "max_amount": "500000",
                "min_term_months": "1",
                "max_term_months": "6",
                "penalty_rate_monthly": "1",
                "penalty_enabled": "on",
                "processing_fee_enabled": "on",
            },
            HTTP_HX_REQUEST="true",
        )
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)
        product = SimpleNamespace(name="Short Term", full_clean=lambda: None, save=lambda: None)

        with (
            patch("loans.views.LoanProduct", return_value=product),
            patch("loans.views.messages.success"),
        ):
            response = loan_views.loan_product_create(request)

        self.assertEqual(response.status_code, 204)
        self.assertEqual(response["HX-Redirect"], reverse("loans:products"))


class LoanProductEditPopoverTests(SimpleTestCase):
    def setUp(self):
        self.product = SimpleNamespace(
            pk=1,
            name="Short Term",
            description="",
            interest_rate_monthly=Decimal("2"),
            interest_method="FLAT",
            default_repayment_frequency="MONTHLY",
            min_amount=Decimal("100000"),
            max_amount=Decimal("500000"),
            min_term_months=1,
            max_term_months=6,
            penalty_rate_monthly=Decimal("1"),
            penalty_enabled=True,
            processing_fee_percent=Decimal("0"),
            processing_fee_enabled=True,
            requires_guarantor=False,
            requires_collateral=False,
            is_active=True,
            full_clean=lambda: None,
            save=lambda: None,
        )

    def test_htmx_get_renders_product_edit_popover(self):
        request = RequestFactory().get(
            "/loans/products/1/edit/",
            HTTP_HX_REQUEST="true",
        )
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)

        with (
            patch("loans.views.get_object_or_404", return_value=self.product),
            patch("loans.views.render") as render,
        ):
            loan_views.loan_product_edit(request, pk=1)

        self.assertEqual(render.call_args.args[1], "loans/product_form_modal.html")
        self.assertEqual(render.call_args.args[2]["action"], "edit")
        self.assertEqual(render.call_args.args[2]["product_form_defaults"]["name"], "Short Term")

    def test_htmx_edit_saves_and_redirects_to_product_list(self):
        request = RequestFactory().post(
            "/loans/products/1/edit/",
            {
                "name": "Updated Term",
                "interest_rate_monthly": "2",
                "interest_method": "FLAT",
                "default_repayment_frequency": "MONTHLY",
                "min_amount": "100000",
                "max_amount": "500000",
                "min_term_months": "1",
                "max_term_months": "6",
                "penalty_rate_monthly": "1",
                "penalty_enabled": "on",
                "processing_fee_enabled": "on",
            },
            HTTP_HX_REQUEST="true",
        )
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)

        with (
            patch("loans.views.get_object_or_404", return_value=self.product),
            patch("loans.views.messages.success"),
        ):
            response = loan_views.loan_product_edit(request, pk=1)

        self.assertEqual(response.status_code, 204)
        self.assertEqual(response["HX-Redirect"], reverse("loans:products"))
        self.assertEqual(self.product.name, "Updated Term")
        self.assertTrue(self.product.penalty_enabled)
        self.assertTrue(self.product.processing_fee_enabled)

    def test_invalid_htmx_edit_renders_errors_inside_the_popover(self):
        request = RequestFactory().post(
            "/loans/products/1/edit/",
            {
                "name": "Updated Term",
                "interest_rate_monthly": "2",
                "interest_method": "FLAT",
                "default_repayment_frequency": "MONTHLY",
                "min_amount": "100000",
                "max_amount": "500000",
                "min_term_months": "1",
                "max_term_months": "6",
                "penalty_rate_monthly": "1",
            },
            HTTP_HX_REQUEST="true",
        )
        request.user = SimpleNamespace(role="CEO", is_authenticated=True)

        with (
            patch("loans.views.get_object_or_404", return_value=self.product),
            patch.object(self.product, "full_clean", side_effect=ValueError("Invalid product terms.")),
            patch.object(self.product, "save") as save,
            patch("loans.views.render") as render,
        ):
            loan_views.loan_product_edit(request, pk=1)

        self.assertEqual(render.call_args.args[1], "loans/product_form_modal.html")
        self.assertIn("Invalid product terms.", render.call_args.args[2]["form_error"])
        save.assert_not_called()


class LoanProductRangeValidationTests(SimpleTestCase):
    def test_rejects_maximum_amount_below_minimum(self):
        product = LoanProduct(min_amount=Decimal("100000"), max_amount=Decimal("1"))

        with self.assertRaises(ValidationError) as error:
            product.clean()

        self.assertIn("max_amount", error.exception.message_dict)

    def test_rejects_maximum_term_below_minimum(self):
        product = LoanProduct(min_term_months=6, max_term_months=1)

        with self.assertRaises(ValidationError) as error:
            product.clean()

        self.assertIn("max_term_months", error.exception.message_dict)


class SchedulePdfGenerationTests(SimpleTestCase):
    def test_generates_pdf_with_payment_reconciliation_fields(self):
        payment = SimpleNamespace(reference_number="MOMO-12345")
        schedule_row = SimpleNamespace(
            due_date=date(2026, 11, 1),
            paid_date=date(2026, 11, 1),
            paid_by_payment=payment,
            opening_balance=Decimal("110000"),
            principal_due=Decimal("100000"),
            interest_due=Decimal("10000"),
            penalty_due=Decimal("0"),
            total_payment=Decimal("110000"),
            amount_paid=Decimal("110000"),
            closing_balance=Decimal("0"),
            get_status_display=lambda: "Paid",
        )
        collateral = SimpleNamespace(
            description="Motorcycle",
            estimated_value=Decimal("5000000"),
            document_number="LOG-123",
            storage_location="Kampala branch",
            notes="",
            release_date=None,
            released_to="",
        )
        loan = SimpleNamespace(
            loan_number="LN-00001",
            client=SimpleNamespace(full_name="Test Client"),
            principal_amount=Decimal("100000"),
            product=SimpleNamespace(name="Salary Loan"),
            get_status_display=lambda: "Active",
            disbursement_date=date(2026, 10, 1),
            maturity_date=date(2026, 11, 1),
            get_interest_method_display=lambda: "Flat Rate",
            interest_rate_monthly=Decimal("5.00"),
            total_interest=Decimal("10000"),
            processing_fee=Decimal("4000"),
            total_repayable=Decimal("110000"),
            total_paid=Decimal("110000"),
            collateral_items=_RelatedList([collateral]),
            schedule=_RelatedList([schedule_row]),
        )
        signature_buffer = BytesIO()
        Image.new("RGB", (1, 1), color="black").save(signature_buffer, format="PNG")
        signatory = SimpleNamespace(
            full_name="Test Signatory",
            signature=ContentFile(signature_buffer.getvalue(), name="signature.png"),
        )

        with patch("accounts.models.BankAccount.objects.filter", return_value=_RelatedList()):
            pdf = generate_loan_schedule_pdf(loan, signatory=signatory)

        self.assertTrue(pdf.startswith(b"%PDF"))


class OptionalGuarantorAmountTests(SimpleTestCase):
    def test_blank_guaranteed_amount_is_allowed(self):
        self.assertEqual(loan_views._parse_optional_guarantor_amount(""), Decimal("0"))

    def test_supplied_guaranteed_amount_must_be_positive(self):
        self.assertEqual(
            loan_views._parse_optional_guarantor_amount("25000"),
            Decimal("25000"),
        )
        with self.assertRaisesMessage(ValueError, "positive number"):
            loan_views._parse_optional_guarantor_amount("0")
        with self.assertRaisesMessage(ValueError, "positive number"):
            loan_views._parse_optional_guarantor_amount("not-a-number")


class LoanBranchResolutionTests(SimpleTestCase):
    @patch("loans.views.resolve_branch_for_write", return_value=None)
    @patch("loans.views.Branch.objects.filter")
    def test_privileged_user_defaults_to_clients_active_branch(self, branch_filter, _resolver):
        client_branch = SimpleNamespace(pk=12)
        branch_filter.return_value.first.return_value = client_branch
        client = SimpleNamespace(branch_id=12)
        request = SimpleNamespace(
            user=SimpleNamespace(is_superuser=True),
            session={},
        )

        self.assertEqual(loan_views._resolve_loan_branch(request, client, ""), 12)
        branch_filter.assert_called_once_with(pk=12, is_active=True)

    @patch("loans.views.Branch.objects.filter")
    def test_privileged_user_can_select_an_active_branch(self, branch_filter):
        branch_filter.return_value.first.return_value = SimpleNamespace(pk=15)
        request = SimpleNamespace(
            user=SimpleNamespace(
                is_superuser=False,
                can=lambda permission: permission == "can_view_all_branches",
            ),
            session={},
        )

        self.assertEqual(loan_views._resolve_loan_branch(request, SimpleNamespace(branch_id=12), "15"), 15)
        branch_filter.assert_called_once_with(pk="15", is_active=True)

    def test_staff_remain_restricted_to_their_assigned_branch(self):
        request = SimpleNamespace(
            user=SimpleNamespace(is_superuser=False, can=lambda _permission: False, branch_id=21),
            session={},
        )
        with (
            patch("loans.views.resolve_branch_for_write", return_value=21) as resolver,
            patch("loans.views.Branch.objects.filter") as branch_filter,
        ):
            branch_filter.return_value.first.return_value = SimpleNamespace(pk=21)
            self.assertEqual(loan_views._resolve_loan_branch(request, SimpleNamespace(branch_id=12), ""), 21)
        resolver.assert_called_once_with(request, "")


class LoanListStaffFilterTests(TestCase):
    def test_list_filters_loans_by_applied_staff(self):
        User = get_user_model()
        staff_a = User.objects.create_user(username="staff_a", email="staffa@example.com", password="secret123", role=User.Role.CASHIER)
        staff_b = User.objects.create_user(username="staff_b", email="staffb@example.com", password="secret123", role=User.Role.CASHIER)

        product = LoanProduct.objects.create(
            name="Test Product",
            interest_rate_monthly=Decimal("2.00"),
            processing_fee_percent=Decimal("1.00"),
        )

        client = Client.objects.create(
            first_name="Jane",
            last_name="Doe",
            gender=Client.Gender.FEMALE,
            date_of_birth="1990-01-01",
            marital_status=Client.MaritalStatus.SINGLE,
            nin="NIN1234567890",
            phone_primary="+256700000001",
            physical_address="Kampala",
            district="Kampala",
            employment_status=Client.EmploymentStatus.EMPLOYED,
        )

        Loan.objects.create(
            client=client,
            product=product,
            applied_by=staff_a,
            principal_amount=Decimal("1000000"),
            interest_rate_monthly=Decimal("2.00"),
            interest_method=LoanProduct.InterestMethod.FLAT_RATE,
            penalty_rate_monthly=Decimal("2.00"),
            term_months=3,
            repayment_frequency=Loan.RepaymentFrequency.MONTHLY,
            total_repayable=Decimal("1000000"),
            outstanding_balance=Decimal("1000000"),
            status=Loan.Status.PENDING,
            loan_number="LN-2024-00001",
            core_id="LN00000001",
        )

        Loan.objects.create(
            client=client,
            product=product,
            applied_by=staff_b,
            principal_amount=Decimal("2000000"),
            interest_rate_monthly=Decimal("2.00"),
            interest_method=LoanProduct.InterestMethod.FLAT_RATE,
            penalty_rate_monthly=Decimal("2.00"),
            term_months=6,
            repayment_frequency=Loan.RepaymentFrequency.MONTHLY,
            total_repayable=Decimal("2000000"),
            outstanding_balance=Decimal("2000000"),
            status=Loan.Status.PENDING,
            loan_number="LN-2024-00002",
            core_id="LN00000002",
        )

        self.client.force_login(staff_a)
        response = self.client.get(reverse("loans:list"), {"staff": str(staff_b.pk)})

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "LN-2024-00002")
        self.assertNotContains(response, "LN-2024-00001")


class LoanApplicationClientSearchTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.user = User.objects.create_user(
            username="loan_search_cashier",
            email="loan-search@example.com",
            password="test-password",
            role=User.Role.CASHIER,
        )
        self.client.force_login(self.user)

    def create_client(self, first_name, last_name, **overrides):
        details = {
            "first_name": first_name,
            "last_name": last_name,
            "gender": Client.Gender.FEMALE,
            "date_of_birth": "1990-01-01",
            "marital_status": Client.MaritalStatus.SINGLE,
            "nin": overrides.pop("nin", f"NIN-{first_name}-{last_name}"),
            "phone_primary": "+256700000001",
            "physical_address": "Kampala",
            "district": "Kampala",
            "employment_status": Client.EmploymentStatus.EMPLOYED,
            **overrides,
        }
        return Client.objects.create(**details)

    def test_apply_page_shows_the_three_most_recent_clients_immediately(self):
        created_clients = [
            self.create_client(f"Recent{index}", "Client", nin=f"NIN-RECENT-{index}")
            for index in range(4)
        ]
        created_at = timezone.now()
        for index, client in enumerate(created_clients):
            Client.objects.filter(pk=client.pk).update(
                created_at=created_at + timedelta(seconds=index),
            )

        with patch("loans.views.scope_to_branch", side_effect=lambda queryset, _user: queryset):
            response = self.client.get(reverse("loans:apply"))

        self.assertEqual(response.status_code, 200)
        content = response.content.decode()
        visible_numbers = [
            content.index(client.client_number)
            for client in created_clients[1:]
        ]
        self.assertEqual(visible_numbers, sorted(visible_numbers, reverse=True))
        self.assertNotContains(response, created_clients[0].client_number)

    def test_search_matches_a_full_client_name(self):
        client = self.create_client("Jane", "Doe", other_names="Ann", nin="NIN-JANE-DOE")

        with patch("loans.views.scope_to_branch", side_effect=lambda queryset, _user: queryset):
            response = self.client.get(
                reverse("loans:client_search"),
                {"q": "Jane Ann Doe"},
                HTTP_HX_REQUEST="true",
            )

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, client.client_number)
        self.assertContains(response, "Jane Ann Doe")

class LoanScheduleCalculationTests(SimpleTestCase):
    def test_schedule_methods_support_four_decimal_calculator_precision(self):
        from datetime import date
        from loans.utils import generate_schedule

        for method in ("FLAT", "REDUCING", "COMPOUND", "INTEREST_ONLY"):
            with self.subTest(method=method):
                schedule, totals = generate_schedule(
                    principal=Decimal("1234.5678"),
                    annual_rate=Decimal("14.814"),
                    term_months=2,
                    start_date=date(2026, 1, 1),
                    method=method,
                    frequency="WEEKLY",
                    company_settings=CompanySettings(adjust_due_dates_for_holidays=False),
                    decimal_places=4,
                )

                self.assertEqual(totals["total_interest"].as_tuple().exponent, -4)
                self.assertEqual(totals["total_repayable"].as_tuple().exponent, -4)
                self.assertEqual(schedule[0]["total_payment"].as_tuple().exponent, -4)

    def test_weekly_reducing_balance_uses_a_weekly_rate(self):
        from datetime import date
        from loans.utils import generate_schedule

        schedule, totals = generate_schedule(
            principal=Decimal("100000"),
            annual_rate=Decimal("60"),
            term_months=1,
            start_date=date(2026, 1, 1),
            method="REDUCING",
            frequency="WEEKLY",
            company_settings=CompanySettings(adjust_due_dates_for_holidays=False),
        )

        self.assertEqual(schedule[0]["interest_due"], Decimal("1250.00"))
        self.assertEqual(len(schedule), 4)
        self.assertEqual(
            totals["total_repayable"],
            sum(row["total_payment"] for row in schedule),
        )

    def test_reducing_balance_total_repayable_matches_schedule_sum(self):
        from datetime import date
        from loans.utils import generate_schedule
        from decimal import Decimal

        principal = Decimal("1000000")
        schedule, totals = generate_schedule(
            principal=principal,
            annual_rate=Decimal("60"),
            term_months=12,
            start_date=date.today(),
            method="REDUCING",
            frequency="MONTHLY",
        )

        total_payment_sum = sum(row["total_payment"] for row in schedule)
        total_interest_sum = sum(row["interest_due"] for row in schedule)

        self.assertEqual(totals["total_repayable"], total_payment_sum)
        self.assertEqual(totals["total_interest"], total_interest_sum)

    def test_interest_only_collects_interest_until_final_principal_payment(self):
        from datetime import date
        from loans.utils import generate_schedule

        principal = Decimal("100000")
        schedule, totals = generate_schedule(
            principal=principal,
            annual_rate=Decimal("24"),
            term_months=3,
            start_date=date(2026, 1, 1),
            method=LoanProduct.InterestMethod.INTEREST_ONLY,
            frequency="MONTHLY",
            company_settings=CompanySettings(adjust_due_dates_for_holidays=False),
        )

        self.assertEqual([row["principal_due"] for row in schedule], [
            Decimal("0.00"),
            Decimal("0.00"),
            principal,
        ])
        self.assertEqual([row["interest_due"] for row in schedule], [
            Decimal("2000.00"),
            Decimal("2000.00"),
            Decimal("2000.00"),
        ])
        self.assertEqual(totals["total_interest"], Decimal("6000.00"))
        self.assertEqual(totals["total_repayable"], Decimal("106000.00"))

    def test_compound_method_amortizes_with_effective_repayment_period_rate(self):
        from datetime import date
        from loans.utils import generate_schedule

        principal = Decimal("100000")
        schedule, totals = generate_schedule(
            principal=principal,
            annual_rate=Decimal("12"),
            term_months=1,
            start_date=date(2026, 1, 1),
            method=LoanProduct.InterestMethod.COMPOUND,
            frequency="WEEKLY",
            company_settings=CompanySettings(adjust_due_dates_for_holidays=False),
        )
        expected_first_period_interest = (
            principal * ((Decimal("1.01") ** (Decimal("1") / Decimal("4"))) - Decimal("1"))
        ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

        self.assertEqual(len(schedule), 4)
        self.assertEqual(schedule[0]["interest_due"], expected_first_period_interest)
        self.assertEqual(schedule[-1]["closing_balance"], Decimal("0.00"))
        self.assertEqual(
            totals["total_repayable"],
            sum(row["total_payment"] for row in schedule),
        )


class LoanOutstandingBalanceTests(TestCase):
    def test_loan_review_submission_stores_principal_plus_interest_only(self):
        User = get_user_model()
        cashier = User.objects.create_user(
            username="cashier",
            email="cashier@example.com",
            password="pass",
            role=User.Role.CASHIER,
        )

        product = LoanProduct.objects.create(
            name="Test Product",
            interest_rate_monthly=Decimal("2.00"),
            processing_fee_percent=Decimal("1.00"),
            requires_guarantor=False,
        )

        client = Client.objects.create(
            first_name="Jane",
            last_name="Doe",
            gender=Client.Gender.FEMALE,
            date_of_birth="1990-01-01",
            marital_status=Client.MaritalStatus.SINGLE,
            nin="NIN1234567890",
            phone_primary="+256700000001",
            physical_address="Kampala",
            district="Kampala",
            employment_status=Client.EmploymentStatus.EMPLOYED,
        )

        loan = Loan.objects.create(
            client=client,
            product=product,
            applied_by=cashier,
            principal_amount=Decimal("1000000"),
            interest_rate_monthly=Decimal("2.00"),
            interest_method=LoanProduct.InterestMethod.FLAT_RATE,
            penalty_rate_monthly=Decimal("2.00"),
            term_months=6,
            repayment_frequency=Loan.RepaymentFrequency.MONTHLY,
            total_repayable=Decimal("0"),
            outstanding_balance=Decimal("0"),
            status=Loan.Status.DRAFT,
            loan_number="LN-2024-00001",
            core_id="LN00000001",
        )

        self.client.force_login(cashier)
        response = self.client.post(
            reverse("loans:apply_review", kwargs={"client_id": client.pk}),
            {"draft_id": str(loan.pk), "action": "submit"},
        )

        loan.refresh_from_db()
        expected_total_interest = Decimal("1000000") * Decimal("0.02") * Decimal("6")
        expected_total_repayable = Decimal("1000000") + expected_total_interest

        self.assertEqual(response.status_code, 302)
        self.assertEqual(loan.total_repayable, expected_total_repayable)
        self.assertEqual(loan.outstanding_balance, expected_total_repayable)


class LoanRescheduleTests(SimpleTestCase):
    def test_reschedule_sets_outstanding_balance_from_first_schedule_row(self):
        class DummyUser:
            role = "MANAGER"
            is_authenticated = True
            username = "manager"
            first_name = "Manager"
            last_name = "Test"

            @property
            def is_ceo(self):
                return False

        class DummyLoan:
            pk = "12345678-1234-1234-1234-123456789abc"
            loan_number = "LN-001"
            term_months = 6
            repayment_frequency = Loan.RepaymentFrequency.MONTHLY
            outstanding_balance = Decimal("1000000")
            disbursement_date = date(2024, 1, 1)
            product = SimpleNamespace(min_term_months=1, max_term_months=12)
            interest_rate_monthly = Decimal("2.00")
            interest_method = LoanProduct.InterestMethod.FLAT_RATE
            status = Loan.Status.ACTIVE

            def __init__(self):
                self.saved = False
                self.schedule_rows = []

            def save(self):
                self.saved = True

        class DummyScheduleManager:
            def __init__(self):
                self.deleted = False
                self.created_rows = []

            def filter(self, **kwargs):
                return self

            def delete(self):
                self.deleted = True

            def bulk_create(self, rows):
                self.created_rows = rows

        loan = DummyLoan()
        request = RequestFactory().post(
            reverse("loans:reschedule", kwargs={"pk": loan.pk}),
            {
                "principal_amount": "750000",
                "term_months": "4",
                "frequency": Loan.RepaymentFrequency.MONTHLY,
                "reason": "Need a shorter schedule",
            },
        )
        request.user = DummyUser()
        schedule_manager = DummyScheduleManager()
        schedule_rows = [
            {"period_number": 1, "due_date": date(2024, 2, 1), "opening_balance": Decimal("500000"), "principal_due": Decimal("400000"), "interest_due": Decimal("100000"), "total_payment": Decimal("500000"), "closing_balance": Decimal("0")},
        ]
        totals = {"total_repayable_exclusive": Decimal("500000"), "total_interest": Decimal("100000")}

        with patch("loans.views.get_object_or_404", return_value=loan), \
             patch("loans.views.build_loan_schedule_context", return_value=(schedule_rows, totals, None, None, None)), \
             patch("loans.views.messages.success"), \
             patch("loans.views.messages.error"), \
             patch("loans.views.LoanSchedule.objects", new=schedule_manager), \
             patch("loans.views.LoanDisbursementAudit.objects.create", return_value=None):
            response = loan_views.loan_reschedule(request, "loan-1")

        self.assertIn(response.status_code, (200, 302))
        self.assertTrue(loan.saved)
        self.assertEqual(loan.principal_amount, Decimal("750000"))
        self.assertEqual(loan.outstanding_balance, Decimal("750000"))

    def test_reschedule_keeps_existing_schedule_when_no_settings_change(self):
        class DummyUser:
            role = "MANAGER"
            is_authenticated = True
            username = "manager"
            first_name = "Manager"
            last_name = "Test"

            @property
            def is_ceo(self):
                return False

        class DummyLoan:
            pk = "12345678-1234-1234-1234-123456789abc"
            loan_number = "LN-001"
            term_months = 6
            repayment_frequency = Loan.RepaymentFrequency.MONTHLY
            outstanding_balance = Decimal("1000000")
            disbursement_date = date(2024, 1, 1)
            product = SimpleNamespace(min_term_months=1, max_term_months=12)
            status = Loan.Status.ACTIVE
            total_repayable = Decimal("1200000")
            total_interest = Decimal("200000")
            maturity_date = date(2024, 7, 1)

            def __init__(self):
                self.saved = False

            def save(self):
                self.saved = True

        class DummyScheduleManager:
            def __init__(self):
                self.deleted = False
                self.created_rows = []

            def filter(self, **kwargs):
                return self

            def delete(self):
                self.deleted = True

            def bulk_create(self, rows):
                self.created_rows = rows

        loan = DummyLoan()
        request = RequestFactory().post(
            reverse("loans:reschedule", kwargs={"pk": loan.pk}),
            {
                "term_months": "6",
                "frequency": Loan.RepaymentFrequency.MONTHLY,
                "reason": "No change needed",
                "disbursement_date": "2024-01-01",
            },
        )
        request.user = DummyUser()
        schedule_manager = DummyScheduleManager()

        with patch("loans.views.get_object_or_404", return_value=loan), \
             patch("loans.views.build_loan_schedule_context", side_effect=AssertionError("build_loan_schedule_context should not run when settings are unchanged")), \
             patch("loans.views.messages.success"), \
             patch("loans.views.messages.error"), \
             patch("loans.views.LoanSchedule.objects", new=schedule_manager), \
             patch("loans.views.LoanDisbursementAudit.objects.create", return_value=None):
            response = loan_views.loan_reschedule(request, "loan-1")

        self.assertIn(response.status_code, (200, 302))
        self.assertFalse(loan.saved)
        self.assertFalse(schedule_manager.deleted)
        self.assertEqual(schedule_manager.created_rows, [])


class LoanScheduleContextTests(SimpleTestCase):
    def test_selected_method_overrides_the_product_default_for_schedule(self):
        from datetime import date
        from loans.utils import build_loan_schedule_context

        product = SimpleNamespace(
            interest_rate_monthly=Decimal("2.00"),
            interest_method=LoanProduct.InterestMethod.FLAT_RATE,
            processing_fee_percent=Decimal("0"),
        )
        schedule_rows, totals, _, _, _ = build_loan_schedule_context(
            principal=Decimal("100000"),
            product=product,
            term_months=3,
            frequency="MONTHLY",
            start_date=date.today(),
            include_processing_fee=False,
            interest_method=LoanProduct.InterestMethod.INTEREST_ONLY,
            company_settings=CompanySettings(adjust_due_dates_for_holidays=False),
        )

        self.assertEqual(schedule_rows[0]["principal_due"], Decimal("0.00"))
        self.assertEqual(schedule_rows[-1]["principal_due"], Decimal("100000"))
        self.assertEqual(totals["total_interest"], Decimal("6000.00"))

    def test_schedule_context_total_repayable_inclusive_excludes_processing_fee(self):
        from datetime import date
        from loans.utils import build_loan_schedule_context

        product = SimpleNamespace(
            interest_rate_monthly=Decimal("2.00"),
            interest_method="FLAT",
            processing_fee_percent=Decimal("1.00"),
        )

        principal = Decimal("1000000")
        schedule_rows, totals, processing_fee, fee_percent, fee_source = build_loan_schedule_context(
            principal=principal,
            product=product,
            term_months=6,
            frequency="MONTHLY",
            start_date=date.today(),
            include_processing_fee=True,
            company_settings=CompanySettings(
                processing_fee_method="PERCENTAGE",
                default_processing_fee_percent=Decimal("0"),
                adjust_due_dates_for_holidays=False,
            ),
        )

        expected_total_interest = principal * Decimal("0.02") * Decimal("6")
        expected_total_repayable = principal + expected_total_interest

        self.assertEqual(totals["total_repayable_exclusive"], expected_total_repayable)
        self.assertEqual(totals["total_repayable_inclusive"], expected_total_repayable)
        self.assertEqual(totals["grand_total"], expected_total_repayable)
        self.assertEqual(totals["total_repayable"], expected_total_repayable)
        self.assertEqual(processing_fee, principal * Decimal("0.01"))
