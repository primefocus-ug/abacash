"""
loans/views.py
==============
Loan application, approval workflow, and detail views for ABA Uganda.
"""

from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from datetime import date, datetime, timedelta

from django.contrib import messages
from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from django.core.exceptions import ValidationError
from django.db import transaction
from django.db.models import Q, Sum
from django.http import HttpResponse, HttpResponseBadRequest, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils import timezone
from django.views.decorators.http import require_GET, require_POST

from accounts.models import BankAccount, Branch, CompanySettings
from accounts.terms import sanitize_loan_terms
from accounts.branch_scope import (
    SESSION_KEY,
    scope_to_branch,
    can_access_branch_object,
    scope_to_branch_request,
    resolve_branch_for_write,
)
from clients.models import Client
from .models import (
    Loan,
    LoanProduct,
    LoanSchedule,
    LoanRenewal,
    CollateralItem,
    Guarantor,
    LoanGuarantee,
    LoanDisbursementAudit,
    LoanScheduleSnapshot,
    LoanRestructure,
    cash_disbursed_amount_expression,
)
from .utils import (
    build_loan_schedule_context,
    calculate_eligibility,
    calculate_processing_fee_amount,
    collateral_minimum,
    generate_schedule,
    resolve_processing_fee_rate,
    serialize_schedule_row,
    deserialize_schedule_row,
    serialize_loan_snapshot_fields,
    restore_loan_snapshot_fields,
)
from common.pdf_utils import generate_loan_calculator_pdf
from payments.models import Payment


def _require_role(*roles):
    """Decorator factory: restrict view to given roles."""
    from functools import wraps
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def wrapper(request, *args, **kwargs):
            if request.user.role not in roles:
                messages.error(request, "You do not have permission to access that page.")
                return redirect("accounts:dashboard")
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


def _permission_required(codename):
    """Restrict a view to users holding the given app permission.

    Uses user.can() so access follows the Roles & Permissions page (group
    grants and per-user overrides) instead of the user's role field.
    """
    from functools import wraps
    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def wrapper(request, *args, **kwargs):
            if not _user_has_permission(request.user, codename):
                messages.error(request, "You do not have permission to access that page.")
                return redirect("accounts:dashboard")
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


def _user_has_permission(user, codename):
    """Return True when the user object exposes the required permission check."""
    can = getattr(user, "can", None)
    return bool(can is not None and callable(can) and can(codename))


def _loan_calculator_inputs(query_params):
    try:
        principal = Decimal(query_params.get("principal", ""))
        monthly_rate = Decimal(query_params.get("monthly_rate", ""))
        term_months = int(query_params.get("term_months", ""))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("Enter a valid amount, rate, and term.") from None

    if not principal.is_finite() or principal <= 0:
        raise ValueError("Amount must be greater than zero.")
    if principal > Decimal("9999999999999.99"):
        raise ValueError("Amount exceeds the supported maximum.")
    if not monthly_rate.is_finite() or monthly_rate < 0 or monthly_rate > Decimal("99.99"):
        raise ValueError("Monthly rate must be between 0 and 99.99%.")
    if term_months < 1 or term_months > 60:
        raise ValueError("Term must be between 1 and 60 months.")

    method = query_params.get("method", "")
    if method not in dict(LoanProduct.InterestMethod.choices):
        raise ValueError("Select a valid interest method.")

    frequency = query_params.get("frequency", "")
    if frequency not in dict(Loan.RepaymentFrequency.choices):
        raise ValueError("Select a valid repayment frequency.")

    return {
        "principal": principal,
        "monthly_rate": monthly_rate,
        "term_months": term_months,
        "method": method,
        "frequency": frequency,
    }


def _loan_calculator_schedule(inputs):
    schedule, totals = generate_schedule(
        principal=inputs["principal"],
        annual_rate=inputs["monthly_rate"] * Decimal("12"),
        term_months=inputs["term_months"],
        start_date=date.today(),
        method=inputs["method"],
        frequency=inputs["frequency"],
        decimal_places=4,
    )
    return schedule, totals


@login_required
@require_GET
def loan_calculator_preview(request):
    """Return a server-calculated estimate for the floating loan calculator."""
    try:
        inputs = _loan_calculator_inputs(request.GET)
    except ValueError as error:
        return JsonResponse({"error": str(error)}, status=400)

    schedule, totals = _loan_calculator_schedule(inputs)
    period_count = len(schedule)
    average_payment = (
        totals["total_repayable"] / Decimal(period_count)
    ).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP)

    return JsonResponse({
        "period_count": period_count,
        "total_interest": f'{totals["total_interest"]:.4f}',
        "total_repayable": f'{totals["total_repayable"]:.4f}',
        "average_payment": f"{average_payment:.4f}",
        "first_payment": f'{schedule[0]["total_payment"]:.4f}',
        "final_payment": f'{schedule[-1]["total_payment"]:.4f}',
    })


@login_required
@require_GET
def loan_calculator_pdf(request):
    """Export the calculator estimate as a tenant-branded repayment schedule."""
    try:
        inputs = _loan_calculator_inputs(request.GET)
    except ValueError as error:
        return JsonResponse({"error": str(error)}, status=400)

    schedule, totals = _loan_calculator_schedule(inputs)
    company_settings = CompanySettings.get()
    pdf_bytes = generate_loan_calculator_pdf(
        company_settings=company_settings,
        schedule=schedule,
        totals=totals,
        principal=inputs["principal"],
        monthly_rate=inputs["monthly_rate"],
        term_months=inputs["term_months"],
        frequency_label=dict(Loan.RepaymentFrequency.choices)[inputs["frequency"]],
        method_label=dict(LoanProduct.InterestMethod.choices)[inputs["method"]],
    )
    response = HttpResponse(pdf_bytes, content_type="application/pdf")
    response["Content-Disposition"] = 'attachment; filename="loan-schedule-estimate.pdf"'
    return response


def _disbursement_limit_error(user, amount, disbursement_date):
    """Return a user-facing error when a staff member would exceed a limit."""
    settings_obj = CompanySettings.get()
    periods = (
        ("daily", "Daily", disbursement_date, disbursement_date + timedelta(days=1)),
        (
            "weekly",
            "Weekly",
            disbursement_date - timedelta(days=disbursement_date.weekday()),
            disbursement_date - timedelta(days=disbursement_date.weekday()) + timedelta(days=7),
        ),
        (
            "monthly",
            "Monthly",
            disbursement_date.replace(day=1),
            (
                disbursement_date.replace(day=28) + timedelta(days=4)
            ).replace(day=1),
        ),
    )
    disbursed_statuses = (
        Loan.Status.ACTIVE,
        Loan.Status.RESTRUCTURED,
        Loan.Status.COMPLETED,
        Loan.Status.DEFAULTED,
        Loan.Status.WRITTEN_OFF,
    )

    for period, label, start, end in periods:
        limit = getattr(settings_obj, f"{period}_disbursement_limit")
        if limit <= 0:
            continue
        scope = getattr(settings_obj, f"{period}_disbursement_limit_scope")
        if scope != CompanySettings.DisbursementLimitScope.ALL and user.role != scope:
            continue
        query = Loan.objects.filter(
            disbursement_date__gte=start,
            disbursement_date__lt=end,
            status__in=disbursed_statuses,
        )
        if scope != CompanySettings.DisbursementLimitScope.ALL:
            query = query.filter(disbursed_by__role=scope)
        query = query.annotate(
            cash_disbursed_amount=cash_disbursed_amount_expression()
        )
        used = query.aggregate(total=Sum("cash_disbursed_amount"))["total"] or Decimal("0")
        if used + amount > limit:
            remaining = max(limit - used, Decimal("0"))
            scope_label = dict(CompanySettings.DisbursementLimitScope.choices).get(scope, "selected staff")
            return (
                f"{label} disbursement limit for {scope_label} would be exceeded. "
                f"Limit: {limit:,.2f}; remaining: {remaining:,.2f}."
            )
    return None


def _get_client_loan_draft(client):
    return Loan.objects.filter(client=client, status=Loan.Status.DRAFT).order_by("-application_date").first()


def _build_loan_basic_data(loan=None):
    if not loan:
        return {}
    return {
        "product": loan.product,
        "principal": loan.principal_amount,
        "term_months": loan.term_months,
        "frequency": loan.repayment_frequency,
        "interest_method": loan.interest_method,
        "purpose": loan.purpose,
        "processing_fee_enabled": loan.processing_fee_enabled,
        "penalty_enabled": loan.penalty_enabled,
    }


def _resolve_loan_interest_method(
    product,
    data,
    existing_loan=None,
    can_change=True,
):
    same_product_draft = (
        existing_loan is not None and existing_loan.product_id == product.pk
    )
    if can_change:
        method = data.get("interest_method")
        if not method and same_product_draft:
            method = existing_loan.interest_method
    else:
        method = existing_loan.interest_method if same_product_draft else None
    method = method or product.interest_method
    if method not in dict(LoanProduct.InterestMethod.choices):
        raise ValueError("Select a valid interest method.")
    return method


def _resolve_loan_fee_switches(product, data, can_override, existing_loan=None):
    same_product_draft = (
        existing_loan is not None and existing_loan.product_id == product.pk
    )
    if can_override:
        processing_fee_requested = data.get("processing_fee_enabled") == "on"
        penalty_requested = data.get("penalty_enabled") == "on"
    elif same_product_draft:
        processing_fee_requested = existing_loan.processing_fee_enabled
        penalty_requested = existing_loan.penalty_enabled
    else:
        processing_fee_requested = True
        penalty_requested = True

    penalty_requested = penalty_requested and CompanySettings.get().penalties_enabled

    if can_override or same_product_draft:
        return processing_fee_requested, penalty_requested

    processing_fee_enabled = product.processing_fee_enabled and processing_fee_requested
    penalty_enabled = product.penalty_enabled and penalty_requested
    return processing_fee_enabled, penalty_enabled


def _get_schedule_preview_draft(data, client_id=None):
    draft_id = data.get("draft_id")
    client_id = client_id or data.get("client_id")
    if not draft_id or not client_id:
        return None
    try:
        return Loan.objects.filter(
            pk=draft_id,
            client_id=client_id,
            status__in=(Loan.Status.DRAFT, Loan.Status.PENDING),
        ).first()
    except ValidationError:
        return None


def _build_security_data(loan=None):
    if not loan:
        return {
            "collateral_items": [],
            "guarantor_rows": [],
        }
    collateral_items = list(loan.collateral_items.values("description", "estimated_value"))
    guarantor_rows = [
        {
            "guarantor_id": str(g.guarantor_id),
            "amount": str(g.guaranteed_amount) if g.guaranteed_amount else "",
        }
        for g in loan.guarantees.filter(is_active=False)
    ]
    return {
        "collateral_items": collateral_items,
        "guarantor_rows": guarantor_rows,
    }


def _resolve_loan_branch(request, client, posted_branch_id):
    """Resolve an active loan branch, defaulting privileged users to the client's branch."""
    can_choose_branch = bool(getattr(request.user, "is_superuser", False)) or _user_has_permission(request.user, "can_view_all_branches")

    if can_choose_branch and posted_branch_id:
        branch = Branch.objects.filter(pk=posted_branch_id, is_active=True).first()
        if branch is None:
            raise ValueError("Select an active branch for this loan.")
        return branch.pk

    branch_id = resolve_branch_for_write(request, None if can_choose_branch else posted_branch_id)
    if branch_id:
        branch = Branch.objects.filter(pk=branch_id, is_active=True).first()
        if branch is not None:
            return branch.pk

    if can_choose_branch and client.branch_id:
        branch = Branch.objects.filter(pk=client.branch_id, is_active=True).first()
        if branch is not None:
            return branch.pk

    raise ValueError("Select an active branch for this loan.")


def _parse_optional_guarantor_amount(amount):
    """Return zero when omitted; validate a supplied guarantee amount."""
    if not amount:
        return Decimal("0")
    try:
        parsed_amount = Decimal(amount)
    except (ValueError, ArithmeticError) as exc:
        raise ValueError("the amount must be a positive number.") from exc
    if parsed_amount <= 0:
        raise ValueError("the amount must be a positive number.")
    return parsed_amount


# ------------------------------------------------------------------ #
# Loan list                                                            #
# ------------------------------------------------------------------ #

@login_required
def loan_list(request):
    qs = Loan.objects.select_related(
        "client", "product", "applied_by", "reviewed_by"
    ).order_by("-application_date")
    qs = scope_to_branch_request(qs, request)

    status_filter = request.GET.get("status", "")
    if status_filter:
        qs = qs.filter(status=status_filter)

    staff_filter = request.GET.get("staff", "").strip()
    if staff_filter:
        qs = qs.filter(applied_by_id=staff_filter)

    search = request.GET.get("q", "").strip()
    if search:
        qs = qs.filter(
            loan_number__icontains=search
        ) | qs.filter(
            client__first_name__icontains=search
        ) | qs.filter(
            client__last_name__icontains=search
        )

    portfolio_qs = qs.exclude(status=Loan.Status.DRAFT)
    total_principal = portfolio_qs.aggregate(total=Sum("principal_amount"))["total"] or Decimal("0")
    total_outstanding = portfolio_qs.aggregate(total=Sum("outstanding_balance"))["total"] or Decimal("0")
    draft_total_principal = qs.filter(status=Loan.Status.DRAFT).aggregate(total=Sum("principal_amount"))["total"] or Decimal("0")

    User = get_user_model()
    staff_choices = User.objects.filter(is_active=True).order_by("first_name", "last_name", "username")

    context = {
        "loans":          qs[:100],
        "total_principal": total_principal,
        "total_outstanding": total_outstanding,
        "draft_total_principal": draft_total_principal,
        "status_choices": Loan.Status.choices,
        "status_filter":  status_filter,
        "staff_choices":  staff_choices,
        "staff_filter":   staff_filter,
        "search":         search,
    }
    return render(request, "loans/loan_list.html", context)


@login_required
def loan_search(request):
    """AJAX endpoint for Select2 loan search. Returns JSON in Select2 format."""
    q = request.GET.get('q', '').strip()
    qs = Loan.objects.select_related('client').order_by('-application_date')
    qs = scope_to_branch(qs, request.user)
    if q:
        qs = qs.filter(loan_number__icontains=q) | qs.filter(client__first_name__icontains=q) | qs.filter(client__last_name__icontains=q)

    results = []
    for l in qs[:50]:
        text = f"{l.loan_number} — {l.client.full_name} (UGX {int(l.outstanding_balance):,})"
        results.append({"id": str(l.pk), "text": text})

    return JsonResponse({"results": results})


# ------------------------------------------------------------------ #
# Apply for a loan (multi-step)                                        #
# ------------------------------------------------------------------ #

@_require_role("CASHIER", "MANAGER", "CEO")
def loan_apply_step1(request):
    """Step 1: Select or search for the client."""
    clients = _loan_application_client_queryset(request.user)[:3]
    return render(request, "loans/apply_step1.html", {"recent_clients": clients})


def _loan_application_client_queryset(user, search=""):
    clients = scope_to_branch(
        Client.objects.filter(is_active=True, is_blacklisted=False),
        user,
    )
    if not search:
        return clients.order_by("-created_at", "-pk")

    name_query = Q()
    for term in search.split():
        name_query &= (
            Q(first_name__icontains=term)
            | Q(other_names__icontains=term)
            | Q(last_name__icontains=term)
        )
    return clients.filter(
        name_query
        | Q(client_number__icontains=search)
        | Q(nin__icontains=search)
        | Q(phone_primary__icontains=search)
    ).distinct().order_by("-created_at", "-pk")


@_require_role("CASHIER", "MANAGER", "CEO")
def client_search_htmx(request):
    """Return the client search results table partial."""
    q = request.GET.get("q", "").strip()
    clients = _loan_application_client_queryset(request.user, q)[:30 if q else 3]
    return render(request, "partials/client_search_results.html", {"clients": clients, "q": q})


@_require_role("CASHIER", "MANAGER", "CEO")
def loan_apply_step2(request, client_id):
    """Step 2: Enter loan terms and preview amortization schedule."""
    client = get_object_or_404(Client, pk=client_id, is_active=True, is_blacklisted=False)
    active_loan = None
    can_renew = False
    if client.active_loan_count > 0:
        # show existing active loan and allow rollover option when product and user permit
        active_loan = client.loans.filter(status=Loan.Status.ACTIVE).order_by("-disbursement_date").first()
        can_renew = bool(active_loan and active_loan.product and active_loan.product.allows_renewal and _user_has_permission(request.user, "can_approve_loans"))

    products = LoanProduct.objects.filter(is_active=True)
    can_override_loan_fees = request.user.can("can_override_loan_fees")
    can_change_loan_interest_method = request.user.can("can_change_loan_interest_method")
    active_branches = Branch.objects.filter(is_active=True).order_by("name")
    can_choose_branch = bool(getattr(request.user, "is_superuser", False)) or _user_has_permission(request.user, "can_view_all_branches")
    company_settings = CompanySettings.get()
    company_default_fee = company_settings.default_processing_fee_percent

    loan = _get_client_loan_draft(client)
    form_data = _build_loan_basic_data(loan)
    schedule_rows = []
    totals = {}
    processing_fee = None
    processing_fee_percent = None
    fee_source = None
    nominal_apr = Decimal("0")
    total_cost_of_credit = Decimal("0")

    if request.method == "POST":
        data = request.POST
        try:
            product_id = int(data.get("product", 0))
            principal = Decimal(str(data.get("principal", "0") or "0"))
            term_months = int(data.get("term_months", 1) or 1)
            frequency = data.get("frequency", Loan.RepaymentFrequency.MONTHLY)
            purpose = data.get("purpose", "").strip()

            product = get_object_or_404(LoanProduct, pk=product_id, is_active=True)
            interest_method = _resolve_loan_interest_method(
                product,
                data,
                loan,
                can_change=can_change_loan_interest_method,
            )
            processing_fee_enabled, penalty_enabled = _resolve_loan_fee_switches(
                product, data, can_override_loan_fees, loan
            )
            penalty_frequency = CompanySettings.get().penalty_frequency

            if principal < product.min_amount or principal > product.max_amount:
                raise ValueError(
                    f"Loan amount must be between UGX {product.min_amount:,.0f} and {product.max_amount:,.0f}."
                )
            if term_months < product.min_term_months or term_months > product.max_term_months:
                raise ValueError(
                    f"Loan term must be between {product.min_term_months} and {product.max_term_months} months for this product."
                )

            if not loan:
                loan = Loan(
                    client=client,
                    applied_by=request.user,
                    status=Loan.Status.DRAFT,
                    application_date=date.today(),
                )

            loan.product = product
            loan.principal_amount = principal
            loan.interest_rate_monthly = product.interest_rate_monthly
            loan.interest_method = interest_method
            loan.penalty_rate_monthly = product.penalty_rate_monthly
            loan.penalty_frequency = penalty_frequency
            loan.penalty_enabled = penalty_enabled
            if not penalty_enabled:
                loan.penalty_rate_monthly = Decimal("0")
            loan.processing_fee_enabled = processing_fee_enabled
            loan.processing_fee_manually_set = not processing_fee_enabled
            loan.term_months = term_months
            loan.repayment_frequency = frequency
            loan.purpose = purpose

            # Set on every save, including reused drafts that were saved with no branch.
            loan.branch_id = _resolve_loan_branch(request, client, data.get("branch"))

            schedule_rows, totals, processing_fee, fee_percent, fee_source = build_loan_schedule_context(
                principal=principal,
                product=product,
                term_months=term_months,
                frequency=frequency,
                start_date=date.today(),
                include_processing_fee=processing_fee_enabled,
                interest_method=interest_method,
                allow_disabled_product_fee=processing_fee_enabled,
            )
            processing_fee_percent = fee_percent
            nominal_apr = product.interest_rate_monthly * Decimal("12")
            total_cost_of_credit = totals["total_interest"] + processing_fee

            loan.processing_fee = processing_fee
            loan.processing_fee_percent = fee_percent if fee_percent else None
            loan.total_fees = processing_fee
            loan.total_interest = totals["total_interest"]
            loan.total_repayable = totals["total_repayable_exclusive"]
            loan.outstanding_balance = loan.total_repayable
            loan.save()

            form_data = {
                "product": product,
                "principal": principal,
                "term_months": term_months,
                "frequency": frequency,
                "interest_method": interest_method,
                "purpose": purpose,
                "processing_fee_enabled": processing_fee_enabled,
                "penalty_enabled": penalty_enabled,
            }

            if data.get("action") == "continue":
                return redirect(reverse("loans:apply_step3", kwargs={"client_id": client.pk}))

            messages.success(request, "Loan draft saved. Continue to security details when ready.")

        except (ValueError, TypeError) as e:
            messages.error(request, f"Invalid input: {e}")

    elif loan and loan.product and loan.principal_amount and loan.term_months:
        try:
            schedule_rows, totals, processing_fee, fee_percent, fee_source = build_loan_schedule_context(
                principal=loan.principal_amount,
                product=loan.product,
                term_months=loan.term_months,
                frequency=loan.repayment_frequency,
                start_date=date.today(),
                include_processing_fee=loan.processing_fee_enabled,
                interest_method=loan.interest_method,
                allow_disabled_product_fee=loan.processing_fee_enabled,
            )
            processing_fee_percent = fee_percent
            nominal_apr = loan.interest_rate_monthly * Decimal("12")
            total_cost_of_credit = totals["total_interest"] + processing_fee
            form_data = _build_loan_basic_data(loan)
        except Exception as e:
            import logging
            logging.error(f"Error generating schedule for loan {loan.id}: {e}")

    selected_branch_id = ""
    if can_choose_branch:
        requested_branch_id = request.POST.get("branch", "").strip() if request.method == "POST" else ""
        if requested_branch_id:
            selected_branch_id = requested_branch_id
        elif loan and loan.branch_id:
            selected_branch_id = str(loan.branch_id)
        elif request.session.get(SESSION_KEY):
            selected_branch_id = str(request.session[SESSION_KEY])
        elif client.branch_id:
            selected_branch_id = str(client.branch_id)
        else:
            from accounts.branch_scope import get_single_active_branch_id
            selected_branch_id = str(get_single_active_branch_id() or "")

    return render(request, "loans/apply_step2.html", {
        "client": client,
        "products": products,
        "branches": active_branches if can_choose_branch else (),
        "can_choose_branch": can_choose_branch,
        "selected_branch_id": selected_branch_id,
        "schedule_rows": schedule_rows,
        "totals": totals,
        "form_data": form_data,
        "loan": loan,
        "active_loan": active_loan,
        "can_renew": can_renew,
        "can_override_loan_fees": can_override_loan_fees,
        "can_change_loan_interest_method": can_change_loan_interest_method,
        "processing_fee": processing_fee,
        "processing_fee_percent": processing_fee_percent,
        "fee_source": fee_source,
        "processing_fee_method": company_settings.processing_fee_method,
        "processing_fee_ranges": company_settings.processing_fee_ranges,
        "company_default_processing_fee_percent": company_default_fee,
        "nominal_apr": nominal_apr,
        "total_cost_of_credit": total_cost_of_credit,
        "interest_method_choices": LoanProduct.InterestMethod.choices,
    })


def _calculate_loan_fees(principal, product):
    fee_amount = calculate_processing_fee_amount(principal, product=product)
    fee_percent = resolve_processing_fee_rate(product)
    source = "Company settings (range)" if (fee_amount and not fee_percent) else (product.name if fee_percent else "Company settings")
    return fee_amount, fee_percent, source


def _generate_schedule_correct(principal, monthly_rate, term_months, start_date, method, frequency):
    """
    Generate amortization schedule with CORRECT interest calculation.
    """
    from decimal import Decimal, ROUND_HALF_UP
    from dateutil.relativedelta import relativedelta

    # Convert monthly rate to periodic rate based on frequency
    if frequency == Loan.RepaymentFrequency.MONTHLY:
        total_periods = term_months
        period_rate = monthly_rate
    elif frequency == Loan.RepaymentFrequency.WEEKLY:
        total_periods = term_months * 4  # 4 weeks per month
        # Use compound equivalent: (1 + monthly_rate)^(1/4) - 1
        # Or simple: monthly_rate / 4
        period_rate = monthly_rate / Decimal('4')  # Simple division
    elif frequency == Loan.RepaymentFrequency.BIWEEKLY:
        total_periods = term_months * 2
        period_rate = monthly_rate / Decimal('2')
    elif frequency == Loan.RepaymentFrequency.DAILY:
        total_periods = term_months * 30
        period_rate = monthly_rate / Decimal('30')
    else:
        total_periods = term_months
        period_rate = monthly_rate

    schedule_rows = []
    remaining_balance = principal
    total_interest = Decimal('0')

    if method == LoanProduct.InterestMethod.FLAT_RATE:
        # Flat Rate: Simple interest
        total_interest_flat = principal * monthly_rate * term_months
        total_payment_flat = principal + total_interest_flat
        payment_per_period = (total_payment_flat / total_periods).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        interest_per_period = (total_interest_flat / total_periods).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        principal_per_period = (principal / total_periods).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

        for period in range(1, total_periods + 1):
            due_date = start_date + relativedelta(days=period * (30 // (total_periods // term_months if term_months > 0 else 1)))

            if period == total_periods:
                # Last period - adjust for rounding
                principal_due = remaining_balance
                interest_due = total_interest_flat - (interest_per_period * (total_periods - 1))
                total_payment = principal_due + interest_due
            else:
                principal_due = principal_per_period
                interest_due = interest_per_period
                total_payment = payment_per_period

            opening_balance = remaining_balance
            remaining_balance -= principal_due
            closing_balance = max(remaining_balance, Decimal('0'))

            schedule_rows.append({
                'period_number': period,
                'due_date': due_date,
                'opening_balance': opening_balance,
                'principal_due': principal_due,
                'interest_due': interest_due,
                'total_payment': total_payment,
                'closing_balance': closing_balance,
            })

            total_interest += interest_due

    elif method == LoanProduct.InterestMethod.REDUCING_BALANCE:
        # Reducing Balance: Calculate payment using PMT formula
        if period_rate > 0:
            # PMT = P * r * (1+r)^n / ((1+r)^n - 1)
            r = period_rate
            n = total_periods
            # Use Decimal for precision
            one_plus_r = Decimal('1') + r
            payment_per_period = principal * r * (one_plus_r ** n) / ((one_plus_r ** n) - Decimal('1'))
            payment_per_period = payment_per_period.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
        else:
            payment_per_period = (principal / total_periods).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

        for period in range(1, total_periods + 1):
            due_date = start_date + relativedelta(days=period * (30 // (total_periods // term_months if term_months > 0 else 1)))

            opening_balance = remaining_balance
            # Calculate interest on current balance
            interest_due = (remaining_balance * period_rate).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

            if period == total_periods:
                # Last payment - pay off remaining balance
                principal_due = remaining_balance
                total_payment = principal_due + interest_due
            else:
                principal_due = payment_per_period - interest_due
                # Ensure principal doesn't exceed remaining balance
                if principal_due > remaining_balance:
                    principal_due = remaining_balance
                    total_payment = principal_due + interest_due
                else:
                    total_payment = payment_per_period

            remaining_balance -= principal_due
            closing_balance = max(remaining_balance, Decimal('0'))

            schedule_rows.append({
                'period_number': period,
                'due_date': due_date,
                'opening_balance': opening_balance,
                'principal_due': principal_due,
                'interest_due': interest_due,
                'total_payment': total_payment,
                'closing_balance': closing_balance,
            })

            total_interest += interest_due

    # Calculate processing fee using company default
    fee_amount = _get_processing_fee_amount(principal)

    # Total interest should be principal × monthly_rate × term_months
    total_interest = (principal * monthly_rate * term_months).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    total_repayable = (principal + total_interest).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)

    totals = {
        'total_repayable': total_repayable,
        'total_interest': total_interest,
        'total_principal': principal,
        'number_of_periods': total_periods,
        'processing_fee': fee_amount,
    }

    return schedule_rows, totals


def _get_processing_fee_amount(principal):
    return calculate_processing_fee_amount(principal)

@_require_role("CASHIER", "MANAGER", "CEO")
def loan_apply_step3(request, client_id):
    """Step 3: Attach collateral and guarantors for the loan draft."""
    client = get_object_or_404(Client, pk=client_id, is_active=True, is_blacklisted=False)
    loan = None
    draft_id = request.POST.get("draft_id") or request.GET.get("draft_id")
    if draft_id:
        loan = get_object_or_404(Loan, pk=draft_id, client=client, status=Loan.Status.DRAFT)
    else:
        loan = _get_client_loan_draft(client)

    if not loan:
        messages.error(request, "No loan draft found for this client. Please complete loan details first.")
        return redirect("loans:apply_step2", client_id=client.pk)

    products = LoanProduct.objects.filter(is_active=True)
    available_guarantors = Guarantor.objects.filter(is_active=True)
    security_data = _build_security_data(loan)
    schedule_rows = []
    totals = {}
    processing_fee = Decimal("0")
    fee_percent = Decimal("0")
    fee_source = "Company settings"

    if loan.product and loan.principal_amount and loan.term_months:
        try:
            schedule_rows, totals, processing_fee, fee_percent, fee_source = build_loan_schedule_context(
                principal=loan.principal_amount,
                product=loan.product,
                term_months=loan.term_months,
                frequency=loan.repayment_frequency,
                start_date=date.today(),
                include_processing_fee=loan.processing_fee_enabled,
                interest_method=loan.interest_method,
                allow_disabled_product_fee=loan.processing_fee_enabled,
            )
        except Exception:
            pass

    # Preliminary eligibility check (income + active debt). Will be refreshed after collateral input.
    eligibility = None
    effective_min = None
    if loan and loan.product:
        eligibility = calculate_eligibility(client, loan.product)
        coll_items = list(loan.collateral_items.values("description", "estimated_value"))
        coll_floor = collateral_minimum(coll_items)
        effective_min = max(loan.product.min_amount, coll_floor)

    if request.method == "POST":
        data = request.POST
        collateral_descs = data.getlist("collateral_desc")
        collateral_values = data.getlist("collateral_value")
        collateral_items = [
            {"description": d.strip(), "estimated_value": v}
            for d, v in zip(collateral_descs, collateral_values)
            if d.strip() and v
        ]
        include_collateral = loan.product.requires_collateral or data.get("include_collateral") == "on"
        include_guarantors = loan.product.requires_guarantor or data.get("include_guarantors") == "on"
        if not include_collateral:
            collateral_items = []
            security_data["collateral_items"] = []
        if not include_guarantors:
            security_data["guarantor_rows"] = []

        try:
            # Validate guarantor rows BEFORE touching any data, so a bad row
            # shows an error instead of being silently dropped.
            guarantor_ids = data.getlist("guarantor_id") if include_guarantors else []
            guarantor_amounts = data.getlist("guarantor_amount") if include_guarantors else []
            guarantor_rows = []
            guarantor_errors = []
            for index, (gid, amt) in enumerate(zip(guarantor_ids, guarantor_amounts), start=1):
                gid = (gid or "").strip()
                amt = (amt or "").strip()
                if not gid and not amt:
                    continue  # empty row in the picker
                if not gid:
                    guarantor_errors.append(f"Guarantor row {index}: choose a guarantor.")
                    continue
                try:
                    parsed_amount = _parse_optional_guarantor_amount(amt)
                except ValueError as exc:
                    guarantor_errors.append(f"Guarantor row {index}: {exc}")
                    continue
                if not Guarantor.objects.filter(pk=gid, is_active=True).exists():
                    guarantor_errors.append(f"Guarantor row {index}: that guarantor is not active or does not exist.")
                    continue
                guarantor_rows.append({"guarantor_id": gid, "amount": str(parsed_amount)})
            if guarantor_errors:
                raise ValueError(" ".join(guarantor_errors))
            if loan.product.requires_collateral and not collateral_items:
                raise ValueError("This product requires at least one complete collateral item.")

            CollateralItem.objects.filter(loan=loan).delete()
            CollateralItem.objects.bulk_create([
                CollateralItem(
                    loan=loan,
                    description=item["description"],
                    estimated_value=Decimal(str(item["estimated_value"])),
                )
                for item in collateral_items
            ])

            LoanGuarantee.objects.filter(loan=loan).delete()
            draft_guarantees = []
            for row in guarantor_rows:
                try:
                    g = Guarantor.objects.get(pk=row["guarantor_id"], is_active=True)
                except Guarantor.DoesNotExist:
                    continue
                ga = Decimal(str(row["amount"]))
                draft_guarantees.append(LoanGuarantee(
                    guarantor=g,
                    loan=loan,
                    guaranteed_amount=ga,
                    is_active=False,
                ))
            if draft_guarantees:
                LoanGuarantee.objects.bulk_create(draft_guarantees)

            security_data = {
                "collateral_items": collateral_items,
                "guarantor_rows": guarantor_rows,
            }

            # Re-evaluate eligibility taking new collateral into account
            try:
                eligibility = calculate_eligibility(client, loan.product) if loan and loan.product else None
                coll_floor = collateral_minimum(collateral_items)
                effective_min = max(loan.product.min_amount, coll_floor) if loan and loan.product else None

                principal = loan.principal_amount or Decimal("0")
                if eligibility and principal > eligibility.get("net_eligible_max", Decimal("0")):
                    messages.warning(request, f"Principal UGX {principal:,.0f} exceeds recommended limit UGX {eligibility.get('net_eligible_max'):,.0f} based on income and active debt.")
                if effective_min and principal < effective_min:
                    messages.warning(request, f"Principal UGX {principal:,.0f} is below effective minimum UGX {effective_min:,.0f} after collateral floor.")
            except Exception:
                pass

            if data.get("action") == "continue":
                messages.success(request, "Security details saved. Review loan application next.")
                return redirect(reverse("loans:apply_review", kwargs={"client_id": client.pk}) + f"?draft_id={loan.pk}")

            messages.success(request, "Draft security details saved.")
        except (ValueError, TypeError) as e:
            messages.error(request, f"Invalid input: {e}")

    include_collateral = loan.product.requires_collateral or (
        request.POST.get("include_collateral") == "on"
        if request.method == "POST"
        else bool(security_data["collateral_items"])
    )
    include_guarantors = loan.product.requires_guarantor or (
        request.POST.get("include_guarantors") == "on"
        if request.method == "POST"
        else bool(security_data["guarantor_rows"])
    )

    return render(request, "loans/apply_step3.html", {
        "client": client,
        "loan": loan,
        "available_guarantors": available_guarantors,
        "security_data": security_data,
        "include_collateral": include_collateral,
        "include_guarantors": include_guarantors,
        "schedule_rows": schedule_rows,
        "totals": totals,
        "processing_fee": processing_fee,
        "processing_fee_percent": fee_percent,
        "processing_fee_rate_text": f"{fee_percent}%" if fee_percent else ("Fixed range" if processing_fee else ""),
        "fee_source": "Company settings (range)" if (processing_fee and not fee_percent) else (loan.product.name if fee_percent else "Company settings"),
        "nominal_apr": loan.interest_rate_monthly * Decimal("12"),
        "total_cost_of_credit": totals.get("total_interest", Decimal("0")) + processing_fee,
        "eligibility": eligibility,
        "effective_min": effective_min,
    })


@_require_role("CASHIER", "MANAGER", "CEO")
def loan_apply_review(request, client_id):
    """Step 4: Review loan application draft and submit for approval."""
    client = get_object_or_404(Client, pk=client_id, is_active=True, is_blacklisted=False)
    draft_id = request.POST.get("draft_id") or request.GET.get("draft_id")
    loan = None
    if draft_id:
        loan = get_object_or_404(Loan, pk=draft_id, client=client, status=Loan.Status.DRAFT)
    else:
        loan = _get_client_loan_draft(client)

    if not loan:
        messages.error(request, "No loan draft found to review. Please complete the application details first.")
        return redirect("loans:apply_step2", client_id=client.pk)

    schedule_rows = []
    totals = {}
    processing_fee = Decimal("0")
    fee_percent = Decimal("0")
    fee_source = "Company settings"
    if loan.product and loan.principal_amount and loan.term_months:
        try:
            schedule_rows, totals, processing_fee, fee_percent, fee_source = build_loan_schedule_context(
                principal=loan.principal_amount,
                product=loan.product,
                term_months=loan.term_months,
                frequency=loan.repayment_frequency,
                start_date=date.today(),
                include_processing_fee=loan.processing_fee_enabled,
                interest_method=loan.interest_method,
                allow_disabled_product_fee=loan.processing_fee_enabled,
            )
        except Exception:
            pass

    collateral_items = list(loan.collateral_items.values("description", "estimated_value"))
    guarantor_rows = [
        {
            "guarantor": g.guarantor,
            "amount": g.guaranteed_amount if g.guaranteed_amount else None,
        }
        for g in loan.guarantees.filter(is_active=False)
    ]

    if request.method == "POST":
        action = request.POST.get("action")
        if action == "save_draft":
            messages.success(request, "Loan draft saved. You can continue later.")
        elif action == "submit":
            try:
                if not loan.product:
                    raise ValueError("Loan product is required.")
                if loan.product.requires_collateral and not loan.collateral_items.exists():
                    raise ValueError("This product requires at least one collateral item.")
                if loan.product.requires_guarantor and not guarantor_rows:
                    raise ValueError("This product requires at least one guarantor.")
                company_settings = CompanySettings.get()
                active_count = Client.objects.get(pk=client.pk).loans.filter(
                    status__in=[Loan.Status.ACTIVE, Loan.Status.RESTRUCTURED,
                                Loan.Status.PENDING, Loan.Status.APPROVED]
                ).exclude(pk=loan.pk).count()
                if active_count >= company_settings.max_active_loans_per_client:
                    raise ValueError(
                        f"{client.full_name} already has {active_count} active/pending loan(s), "
                        f"the maximum allowed is {company_settings.max_active_loans_per_client}."
                    )
                if loan.product and (loan.principal_amount < loan.product.min_amount or loan.principal_amount > loan.product.max_amount):
                    raise ValueError(
                        f"Loan amount must be between UGX {loan.product.min_amount:,.0f} and {loan.product.max_amount:,.0f}."
                    )
                schedule_rows, totals, processing_fee, fee_percent, _ = build_loan_schedule_context(
                    principal=loan.principal_amount,
                    product=loan.product,
                    term_months=loan.term_months,
                    frequency=loan.repayment_frequency,
                    start_date=date.today(),
                    include_processing_fee=loan.processing_fee_enabled,
                    interest_method=loan.interest_method,
                    allow_disabled_product_fee=loan.processing_fee_enabled,
                )

                loan.processing_fee = processing_fee
                loan.processing_fee_manually_set = not loan.processing_fee_enabled
                loan.processing_fee_percent = fee_percent if fee_percent else None
                loan.total_fees = processing_fee
                loan.total_repayable = totals["total_repayable_exclusive"]
                loan.total_interest = totals["total_interest"]
                loan.outstanding_balance = totals["total_repayable_exclusive"]
                loan.status = Loan.Status.PENDING
                loan.query_reason = ""
                loan.save()

                LoanSchedule.objects.filter(loan=loan).delete()
                LoanSchedule.objects.bulk_create([
                    LoanSchedule(
                        loan=loan,
                        period_number=row["period_number"],
                        due_date=row["due_date"],
                        opening_balance=row["opening_balance"],
                        principal_due=row["principal_due"],
                        interest_due=row["interest_due"],
                        total_payment=row["total_payment"],
                        closing_balance=row["closing_balance"],
                    )
                    for row in schedule_rows
                ])

                for guarantee in loan.guarantees.filter(is_active=False):
                    g = guarantee.guarantor
                    if g.available_capacity < guarantee.guaranteed_amount and g.max_liability != 0:
                        raise ValueError(f"Guarantor {g} does not have enough available capacity for UGX {guarantee.guaranteed_amount}")
                    guarantee.is_active = True
                    guarantee.save()
                    g.current_liability = g.current_liability + guarantee.guaranteed_amount
                    g.save()

                messages.success(request, f"Loan {loan.loan_number} submitted for approval.")
                return redirect("loans:detail", pk=loan.pk)
            except (ValueError, TypeError) as e:
                messages.error(request, f"Could not submit loan: {e}")

    return render(request, "loans/apply_review.html", {
        "client": client,
        "loan": loan,
        "schedule_rows": schedule_rows,
        "totals": totals,
        "processing_fee": processing_fee,
        "processing_fee_percent": fee_percent,
        "processing_fee_rate_text": f"{fee_percent}%" if fee_percent else ("Fixed range" if processing_fee else ""),
        "fee_source": "Company settings (range)" if (processing_fee and not fee_percent) else (loan.product.name if fee_percent else "Company settings"),
        "nominal_apr": loan.interest_rate_monthly * Decimal("12"),
        "total_cost_of_credit": totals.get("total_interest", Decimal("0")) + processing_fee,
        "collateral_items": collateral_items,
        "guarantor_rows": guarantor_rows,
        "can_override_loan_fees": request.user.can("can_override_loan_fees"),
        "eligibility": calculate_eligibility(client, loan.product) if loan and loan.product else None,
        "effective_min": max(loan.product.min_amount, collateral_minimum(collateral_items)) if loan and loan.product else None,
    })


@_require_role("CASHIER", "MANAGER", "CEO")
def loan_edit(request, pk):
    """Edit an existing loan application while it is DRAFT or PENDING.

    Deleting and recreating collateral, schedule and guarantees on update.
    """
    loan = get_object_or_404(Loan.objects.select_related("client", "product"), pk=pk)

    if loan.status == Loan.Status.REJECTED:
        messages.error(request, "Rejected loans cannot be edited.")
        return redirect("loans:detail", pk=loan.pk)

    # Only allow edits for DRAFT or PENDING applications
    if loan.status not in (Loan.Status.DRAFT, Loan.Status.PENDING):
        messages.error(request, "Only draft or pending applications can be edited.")
        return redirect("loans:detail", pk=loan.pk)

    client = loan.client
    products = LoanProduct.objects.filter(is_active=True)
    can_override_loan_fees = request.user.can("can_override_loan_fees")
    can_change_loan_interest_method = request.user.can("can_change_loan_interest_method")
    available_guarantors = Guarantor.objects.filter(is_active=True)

    schedule_rows = []
    totals = {}
    form_data = {
        "product": loan.product,
        "principal": loan.principal_amount,
        "term_months": loan.term_months,
        "frequency": loan.repayment_frequency,
        "interest_method": loan.interest_method,
        "purpose": loan.purpose,
        "processing_fee_enabled": loan.processing_fee_enabled,
        "penalty_enabled": loan.penalty_enabled,
        "collateral_items": list(loan.collateral_items.values("description", "estimated_value")) if hasattr(loan, 'collateral_items') else [],
        "guarantor_rows": [
            {
                "guarantor_id": str(g.guarantor_id),
                "amount": str(g.guaranteed_amount) if g.guaranteed_amount else "",
            }
            for g in loan.guarantees.all()
        ],
    }

    if request.method == "POST" or request.GET.get("preview"):
        data = request.POST or request.GET
        try:
            product_id = int(data.get("product", loan.product_id or 0))
            principal = Decimal(str(data.get("principal", loan.principal_amount)))
            term_months = int(data.get("term_months", loan.term_months) or loan.term_months)
            frequency = data.get("frequency", loan.repayment_frequency)
            purpose = data.get("purpose", loan.purpose or "")

            product = get_object_or_404(LoanProduct, pk=product_id, is_active=True)
            interest_method = _resolve_loan_interest_method(
                product,
                data,
                loan,
                can_change=can_change_loan_interest_method,
            )
            processing_fee_enabled, penalty_enabled = _resolve_loan_fee_switches(
                product, data, can_override_loan_fees, loan
            )
            penalty_frequency = CompanySettings.get().penalty_frequency

            # Parse collateral
            collateral_descs = data.getlist("collateral_desc")
            collateral_values = data.getlist("collateral_value")
            collateral_items = [
                {"description": d.strip(), "estimated_value": v}
                for d, v in zip(collateral_descs, collateral_values)
                if d.strip() and v
            ]

            # Validate limits
            if principal < product.min_amount or principal > product.max_amount:
                raise ValueError(
                    f"Loan amount must be between UGX {product.min_amount:,.0f} and {product.max_amount:,.0f}."
                )
            if term_months < product.min_term_months or term_months > product.max_term_months:
                raise ValueError(
                    f"Loan term must be between {product.min_term_months} and {product.max_term_months} months for this product."
                )

            schedule_rows, totals, processing_fee, _, _ = build_loan_schedule_context(
                principal=principal,
                product=product,
                term_months=term_months,
                frequency=frequency,
                start_date=date.today(),
                include_processing_fee=processing_fee_enabled,
                interest_method=interest_method,
                allow_disabled_product_fee=processing_fee_enabled,
            )

            guarantor_ids = data.getlist("guarantor_id")
            guarantor_amounts = data.getlist("guarantor_amount")

            # Handle full POST submit
            if request.method == "POST" and data.get("action") == "submit":
                # Update loan fields
                loan.product = product
                loan.principal_amount = principal
                loan.interest_rate_monthly = product.interest_rate_monthly
                loan.interest_method = interest_method
                loan.penalty_enabled = penalty_enabled
                loan.penalty_frequency = penalty_frequency
                loan.penalty_rate_monthly = (
                    product.penalty_rate_monthly if penalty_enabled else Decimal("0")
                )
                loan.processing_fee_enabled = processing_fee_enabled
                loan.processing_fee_manually_set = not processing_fee_enabled
                loan.term_months = term_months
                loan.repayment_frequency = frequency
                fee_percent = resolve_processing_fee_rate(
                    product,
                    allow_disabled_product_fee=processing_fee_enabled,
                )
                loan.processing_fee_percent = fee_percent if fee_percent else None
                loan.processing_fee = processing_fee
                loan.total_fees = processing_fee
                loan.total_repayable = totals["total_repayable_exclusive"]
                loan.total_interest = totals["total_interest"]
                loan.outstanding_balance = loan.total_repayable
                loan.total_fees = processing_fee
                loan.purpose = purpose
                loan.applied_by = request.user if not loan.applied_by else loan.applied_by
                loan.query_reason = ""
                loan.save()

                # Replace collateral items: delete existing and recreate
                CollateralItem.objects.filter(loan=loan).delete()
                CollateralItem.objects.bulk_create([
                    CollateralItem(
                        loan=loan,
                        description=item["description"],
                        estimated_value=Decimal(str(item["estimated_value"])),
                    )
                    for item in collateral_items
                ])

                # Replace schedule rows
                LoanSchedule.objects.filter(loan=loan).delete()
                LoanSchedule.objects.bulk_create([
                    LoanSchedule(
                        loan=loan,
                        period_number=row["period_number"],
                        due_date=row["due_date"],
                        opening_balance=row["opening_balance"],
                        principal_due=row["principal_due"],
                        interest_due=row["interest_due"],
                        total_payment=row["total_payment"],
                        closing_balance=row["closing_balance"],
                    )
                    for row in schedule_rows
                ])

                # Replace guarantees: adjust guarantor liabilities safely
                # Subtract old guarantees from guarantors
                for lg in LoanGuarantee.objects.filter(loan=loan):
                    g = lg.guarantor
                    g.current_liability = max(Decimal("0"), g.current_liability - lg.guaranteed_amount)
                    g.save()
                LoanGuarantee.objects.filter(loan=loan).delete()

                # Create new guarantees
                new_guarantees = []
                for gid, amt in zip(guarantor_ids, guarantor_amounts):
                    if not gid:
                        continue
                    try:
                        g = Guarantor.objects.get(pk=gid, is_active=True)
                    except Guarantor.DoesNotExist:
                        continue
                    ga = _parse_optional_guarantor_amount(amt)
                    if g.available_capacity < ga and g.max_liability != 0:
                        raise ValueError(f"Guarantor {g} does not have enough available capacity for UGX {ga}")
                    new_guarantees.append(LoanGuarantee(guarantor=g, loan=loan, guaranteed_amount=ga))

                if new_guarantees:
                    LoanGuarantee.objects.bulk_create(new_guarantees)
                    for lg in LoanGuarantee.objects.filter(loan=loan):
                        g = lg.guarantor
                        g.current_liability = g.current_liability + lg.guaranteed_amount
                        g.save()

                messages.success(request, f"Loan {loan.loan_number} updated.")
                return redirect("loans:detail", pk=loan.pk)

        except (ValueError, TypeError) as e:
            messages.error(request, f"Invalid input: {e}")

    return render(request, "loans/apply_step2.html", {
        "client": client,
        "products": products,
        "available_guarantors": available_guarantors,
        "schedule_rows": schedule_rows,
        "totals": totals,
        "form_data": form_data,
        "eligibility": None,
        "editing": True,
        "loan": loan,
        "can_override_loan_fees": can_override_loan_fees,
        "can_change_loan_interest_method": can_change_loan_interest_method,
        "interest_method_choices": LoanProduct.InterestMethod.choices,
        "processing_fee_method": CompanySettings.get().processing_fee_method,
        "processing_fee_ranges": CompanySettings.get().processing_fee_ranges,
        "company_default_processing_fee_percent": CompanySettings.get().default_processing_fee_percent,
    })


# ------------------------------------------------------------------ #
# Loan detail                                                          #
# ------------------------------------------------------------------ #

def _can_undo_regenerate(loan):
    """
    Whether there's a not-yet-undone schedule regeneration on this loan
    that's still safe to undo (i.e. nothing's been paid against the rows
    it created since). Drives whether the "Undo Last Regeneration" button
    shows up at all.
    """
    snapshot = loan.schedule_snapshots.filter(is_undone=False).order_by("-created_at").first()
    if not snapshot:
        return False
    new_rows = list(LoanSchedule.objects.filter(pk__in=snapshot.new_row_ids))
    return not any(
        r.amount_paid > 0 or r.status not in (LoanSchedule.Status.PENDING, LoanSchedule.Status.OVERDUE)
        for r in new_rows
    )


@login_required
def loan_detail(request, pk):
    loan = get_object_or_404(Loan.objects.select_related("client", "product", "applied_by", "reviewed_by"), pk=pk)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("loans:list")
    schedule  = loan.schedule.order_by("period_number")
    payments  = loan.payments.order_by("-payment_date")
    renewals  = loan.renewal_records.select_related("new_loan").order_by("-renewal_date")

    # Attempt to fetch recent disbursement audits; tolerate missing table (migrations not yet applied)
    recent_audits = []
    audits_total = 0
    try:
        from django.db import ProgrammingError, OperationalError
        recent_qs = LoanDisbursementAudit.objects.filter(loan=loan).order_by('-created_at')
        recent_audits = list(recent_qs[:20])
        audits_total = recent_qs.count()
    except (Exception,) as e:
        # Catch broad exceptions to avoid breaking the loan detail view before migrations.
        # Specifically ProgrammingError/OperationalError may occur when table doesn't exist.
        import logging
        logging.debug('Could not fetch disbursement audit entries: %s', e)
        recent_audits = []
        audits_total = 0

    def date_at_noon(value):
        if not value:
            return timezone.now()
        if isinstance(value, datetime):
            if timezone.is_naive(value):
                return timezone.make_aware(value)
            return value
        return timezone.make_aware(datetime.combine(value, datetime.min.time()))

    action_history = []

    if loan.application_date:
        action_history.append({
            "type": "application",
            "label": "Loan application submitted",
            "detail": f"Principal: {loan.principal_amount:,.0f}",
            "actor": loan.applied_by.full_name if loan.applied_by else "System",
            "timestamp": date_at_noon(loan.application_date),
        })

    if loan.approval_date:
        action_history.append({
            "type": "approval",
            "label": "Loan approved and activated",
            "detail": f"Disbursement date: {loan.disbursement_date or 'Not set'}",
            "actor": loan.reviewed_by.full_name if loan.reviewed_by else "Approver",
            "timestamp": date_at_noon(loan.approval_date),
        })

    for audit in recent_qs if 'recent_qs' in locals() else []:
        action_history.append({
            "type": audit.action,
            "label": audit.get_action_display(),
            "detail": (
                f"{audit.old_disbursement_date or '—'} → {audit.new_disbursement_date or '—'}"
                if audit.old_disbursement_date or audit.new_disbursement_date
                else audit.reason
            ),
            "reason": audit.reason,
            "actor": audit.changed_by.full_name if audit.changed_by else "System",
            "timestamp": audit.created_at,
        })

    for payment in payments:
        action_history.append({
            "type": "payment",
            "label": "Payment recorded",
            "detail": f"{payment.amount_received:,.0f} via {payment.get_payment_method_display()}",
            "reason": payment.notes,
            "actor": payment.recorded_by.full_name if payment.recorded_by else "System",
            "timestamp": payment.created_at,
        })

    for renewal in renewals:
        action_history.append({
            "type": "renewal",
            "label": "Loan renewed",
            "detail": f"Renewal loan: {renewal.new_loan.loan_number}",
            "reason": renewal.reason,
            "actor": renewal.approved_by.full_name if renewal.approved_by else "System",
            "timestamp": renewal.created_at,
        })

    for restructure in LoanRestructure.objects.filter(loan=loan).select_related("approved_by").order_by("-created_at"):
        action_history.append({
            "type": "reschedule",
            "label": "Loan rescheduled",
            "detail": f"{restructure.old_maturity_date or '—'} → {restructure.new_maturity_date}",
            "reason": restructure.reason,
            "actor": restructure.approved_by.full_name if restructure.approved_by else "System",
            "timestamp": restructure.created_at,
        })

    if loan.write_off_reason:
        action_history.append({
            "type": "write_off",
            "label": "Loan written off",
            "detail": "Outstanding balance moved to written-off status",
            "reason": loan.write_off_reason,
            "actor": loan.write_off_approved_by.full_name if loan.write_off_approved_by else "System",
            "timestamp": date_at_noon(loan.updated_at),
        })

    if loan.reinstated_at:
        action_history.append({
            "type": "reinstate",
            "label": "Loan reinstated",
            "detail": "Loan returned to active status",
            "reason": loan.reinstatement_reason,
            "actor": loan.reinstated_by.full_name if loan.reinstated_by else "System",
            "timestamp": loan.reinstated_at,
        })

    action_history.sort(key=lambda item: item["timestamp"], reverse=True)

    # A loan is eligible for a manual write-off once it's been overdue longer
    # than the company's configured auto-write-off threshold (see
    # CompanySettings.auto_write_off_days) — i.e. the system's automatic
    # write-off point has passed but the loan hasn't been written off yet.
    # Loans not yet past that point don't show the write-off action at all;
    # it's meant to catch loans automation hasn't (or can't) clean up, not to
    # be a general-purpose write-off button.
    from accounts.models import CompanySettings
    company_settings = CompanySettings.get()
    write_off_threshold_days = getattr(company_settings, "auto_write_off_days", 180)
    can_write_off = (
        request.user.role == "CEO"
        and loan.status in (Loan.Status.ACTIVE, Loan.Status.RESTRUCTURED, Loan.Status.DEFAULTED)
        and loan.days_overdue >= write_off_threshold_days
    )

    return render(request, "loans/loan_detail.html", {
        "loan":     loan,
        "schedule": schedule,
        "payments": payments,
        "renewals": renewals,
        "today":    date.today(),
        "recent_disbursement_audits": recent_audits,
        "disbursement_audits_total": audits_total,
        "loan_action_history": action_history,
        "can_write_off": can_write_off,
        "write_off_threshold_days": write_off_threshold_days,
        "can_undo_regenerate": _can_undo_regenerate(loan),
        "company_settings": company_settings,
    })

@_require_role("MANAGER", "CEO")
def loan_reschedule(request, pk):
    """Handle payment rescheduling separately from renewals.

    This view accepts both regular and HTMX requests. When requested
    via HTMX it returns the small form fragment (renew_loan_fragment.html)
    suitable for modal display. On POST it validates input, optionally
    accepts a disbursement_date (CEOs may back-date), regenerates the
    repayment schedule for the outstanding balance and replaces the
    loan's schedule rows.
    """
    loan = get_object_or_404(
        Loan.objects.select_related("client", "product"),
        pk=pk,
        status=Loan.Status.ACTIVE,
    )
    products = LoanProduct.objects.filter(is_active=True).order_by("name")
    loan_product_id = getattr(loan, "product_id", getattr(loan.product, "pk", None))
    if getattr(loan.product, "pk", None):
        if loan_product_id and not products.filter(pk=loan_product_id).exists():
            products = products | LoanProduct.objects.filter(pk=loan_product_id)
    else:
        products = [loan.product]
    selected_product = loan.product

    # If a POST request, handle the reschedule submission
    if request.method == "POST":
        try:
            product_id = request.POST.get("product")
            if product_id:
                selected_product = get_object_or_404(products, pk=int(product_id))
            term_months = int(request.POST.get("term_months", loan.term_months) or loan.term_months)
            frequency = request.POST.get("frequency", loan.repayment_frequency)
            reason = request.POST.get("reason", "").strip()
            try:
                reschedule_principal = Decimal(
                    request.POST.get("principal_amount", str(loan.outstanding_balance))
                    or str(loan.outstanding_balance)
                )
            except (InvalidOperation, TypeError, ValueError):
                raise ValueError("Principal amount must be a valid number.")

            if not reason:
                raise ValueError("Rescheduling reason is required.")
            if reschedule_principal <= Decimal("0"):
                raise ValueError("Principal amount must be greater than zero.")

            if term_months < selected_product.min_term_months or term_months > selected_product.max_term_months:
                raise ValueError(
                    f"Term must be between {selected_product.min_term_months} and {selected_product.max_term_months} months."
                )

            product_min_amount = getattr(selected_product, "min_amount", None)
            product_max_amount = getattr(selected_product, "max_amount", None)
            if product_min_amount is not None and product_max_amount is not None and (
                reschedule_principal < product_min_amount
                or reschedule_principal > product_max_amount
            ):
                raise ValueError(
                    f"Principal must be between UGX {selected_product.min_amount:,.0f} "
                    f"and UGX {selected_product.max_amount:,.0f} for {selected_product.name}."
                )

            if frequency not in dict(Loan.RepaymentFrequency.choices):
                raise ValueError("Invalid repayment frequency selected.")

            outstanding_amount = loan.outstanding_balance
            if outstanding_amount <= Decimal("0"):
                raise ValueError("Loan has no outstanding balance to reschedule.")

            # Allow optional disbursement_date from the form (CEOs may back-date)
            provided_disb = request.POST.get('disbursement_date', '').strip()
            if provided_disb:
                try:
                    chosen_disbursement = date.fromisoformat(provided_disb)
                except Exception:
                    raise ValueError("Invalid disbursement date format. Use YYYY-MM-DD.")
            else:
                chosen_disbursement = date.today()

            if (
                term_months == loan.term_months
                and frequency == loan.repayment_frequency
                and reschedule_principal == loan.outstanding_balance
                and chosen_disbursement == loan.disbursement_date
                and getattr(selected_product, "pk", loan_product_id) == loan_product_id
            ):
                messages.success(request, f"Loan {loan.loan_number} already matches the selected schedule settings.")
                if request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true':
                    from django.urls import reverse
                    return render(request, 'loans/htmx_success.html', {
                        'message': f'Loan {loan.loan_number} already matches the selected schedule settings.',
                        'redirect': '"' + reverse('loans:detail', kwargs={'pk': loan.pk}) + '"',
                    })
                return redirect("loans:detail", pk=loan.pk)

            if (
                chosen_disbursement < date.today()
                and not _user_has_permission(request.user, "can_backdate_transactions")
            ):
                raise ValueError("Only users with back-dating permission may set a past disbursement date.")

            schedule_rows, totals, _, _, _ = build_loan_schedule_context(
                principal=reschedule_principal,
                product=selected_product,
                term_months=term_months,
                frequency=frequency,
                start_date=chosen_disbursement,
                include_processing_fee=False,
                interest_rate_monthly=getattr(
                    selected_product,
                    "interest_rate_monthly",
                    loan.interest_rate_monthly,
                ),
                interest_method=getattr(
                    selected_product,
                    "interest_method",
                    loan.interest_method,
                ),
            )

            # Update the loan's schedule instead of creating a new loan
            old_date = loan.disbursement_date
            loan.term_months = term_months
            loan.repayment_frequency = frequency
            loan.product = selected_product
            loan.interest_rate_monthly = getattr(
                selected_product,
                "interest_rate_monthly",
                loan.interest_rate_monthly,
            )
            loan.interest_method = getattr(
                selected_product,
                "interest_method",
                loan.interest_method,
            )
            company_settings = CompanySettings.get()
            selected_penalty_enabled = (
                getattr(selected_product, "penalty_enabled", False)
                and company_settings.penalties_enabled
            )
            loan.penalty_enabled = selected_penalty_enabled
            loan.penalty_frequency = company_settings.penalty_frequency
            loan.penalty_rate_monthly = (
                getattr(selected_product, "penalty_rate_monthly", Decimal("0"))
                if selected_penalty_enabled
                else Decimal("0")
            )
            loan.principal_amount = reschedule_principal
            loan.disbursement_date = chosen_disbursement
            loan.maturity_date = schedule_rows[-1]["due_date"]
            loan.total_repayable = totals["total_repayable_exclusive"]
            loan.total_interest = totals["total_interest"]
            loan.outstanding_balance = reschedule_principal
            loan.save()

            # Create an audit record of this reschedule action
            try:
                LoanDisbursementAudit.objects.create(
                    loan=loan,
                    changed_by=request.user,
                    old_disbursement_date=old_date,
                    new_disbursement_date=loan.disbursement_date,
                    action='reschedule',
                    reason=reason[:2000],
                )
            except Exception:
                import logging
                logging.exception('Failed to create disbursement audit for loan %s', loan.pk)

            # Delete old schedule and create new one
            LoanSchedule.objects.filter(loan=loan).delete()
            LoanSchedule.objects.bulk_create([
                LoanSchedule(
                    loan=loan,
                    period_number=row["period_number"],
                    due_date=row["due_date"],
                    opening_balance=row["opening_balance"],
                    principal_due=row["principal_due"],
                    interest_due=row["interest_due"],
                    total_payment=row["total_payment"],
                    closing_balance=row["closing_balance"],
                )
                for row in schedule_rows
            ])

            messages.success(request, f"Loan {loan.loan_number} has been rescheduled.")
            # HTMX: return small fragment to close modal and refresh
            if request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true':
                from django.urls import reverse
                return render(request, 'loans/htmx_success.html', {
                    'message': f'Loan {loan.loan_number} has been rescheduled.',
                    'redirect': '"' + reverse('loans:detail', kwargs={'pk': loan.pk}) + '"',
                })
            return redirect("loans:detail", pk=loan.pk)

        except Exception as e:
            import logging
            logging.getLogger(__name__).exception("Failed to reschedule loan %s", loan.pk)
            messages.error(request, f"Rescheduling Error: {e}")

    # For GET (or after errors), render the form (fragment for HTMX)
    frequency_choices = Loan.RepaymentFrequency.choices
    context = {
        "loan": loan,
        "products": products,
        "selected_product": selected_product,
        "frequency_choices": frequency_choices,
        "default_term": request.POST.get("term_months", loan.term_months),
        "default_frequency": request.POST.get("frequency", loan.repayment_frequency),
        "default_principal": request.POST.get("principal_amount", loan.outstanding_balance),
        "default_disbursement_date": (
            request.POST.get("disbursement_date")
            or (loan.disbursement_date or date.today()).isoformat()
        ),
        "min_term": selected_product.min_term_months,
        "max_term": selected_product.max_term_months,
        "is_reschedule": True,
        "action_title": "Reschedule Loan",
        "submit_label": "Reschedule Loan",
        "helper_text": "This creates a new repayment schedule for the existing loan.",
        "today": date.today(),
    }
    if request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true':
        return render(request, 'loans/renew_loan_fragment.html', context)
    return render(request, "loans/renew_loan.html", context)


@_require_role("CEO")
def loan_regenerate_schedule(request, pk):
    """HTMX endpoint to GET a small form and POST to regenerate the repayment schedule.

    GET: returns a small fragment with a date input (modal body)
    POST: regenerates schedule using the provided disbursement_date and returns the updated
          schedule card fragment so the page can update via HTMX.

    Only ever touches *unsettled* schedule rows (no payment applied yet —
    status PENDING/OVERDUE with amount_paid == 0). Any row a payment has
    been recorded against (PAID, PARTIAL, WAIVED, or amount_paid > 0) is
    left completely untouched, so payment history can never be lost here.
    The remaining principal is re-amortized only over however many
    unsettled periods remain — not the loan's original full term — so
    regenerating mid-loan doesn't silently restart the amortization clock.

    A full backup is taken first (LoanScheduleSnapshot) so this can be
    undone via loan_undo_regenerate_schedule.
    """
    loan = get_object_or_404(Loan.objects.select_related("product", "client"), pk=pk)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("loans:detail", pk=loan.pk)

    # GET -> return the small form fragment
    if request.method == "GET":
        return render(request, "loans/htmx_regenerate_schedule_form.html", {
            "loan": loan,
            "today": date.today(),
        })

    # POST -> perform regeneration
    if request.method == "POST":
        if loan.status not in (Loan.Status.ACTIVE, Loan.Status.RESTRUCTURED):
            messages.error(
                request,
                f"Cannot regenerate the schedule for a {loan.get_status_display()} loan.",
            )
            return redirect("loans:detail", pk=loan.pk)

        provided = request.POST.get("disbursement_date", "").strip()
        if not provided:
            messages.error(request, "Please provide a disbursement date.")
            return redirect("loans:detail", pk=loan.pk)

        try:
            parsed = date.fromisoformat(provided)
        except Exception:
            messages.error(request, "Invalid disbursement date format. Use YYYY-MM-DD.")
            return redirect("loans:detail", pk=loan.pk)

        # Non-privileged users may not set a start date in the past
        if not request.user.can("can_backdate_transactions") and parsed < date.today():
            messages.error(request, "You do not have permission to set a past date.")
            return redirect("loans:detail", pk=loan.pk)

        reason = request.POST.get("reason", "").strip()[:2000]

        all_rows = list(loan.schedule.order_by("period_number"))
        settled_rows = [
            r for r in all_rows
            if r.status in (LoanSchedule.Status.PAID, LoanSchedule.Status.WAIVED) or r.amount_paid > 0
        ]
        unsettled_rows = [r for r in all_rows if r not in settled_rows]

        if not unsettled_rows:
            messages.info(request, "Every period on this loan is already settled — nothing to regenerate.")
            return redirect("loans:detail", pk=loan.pk)

        remaining_principal = sum((r.principal_due for r in unsettled_rows), Decimal("0"))
        remaining_periods = len(unsettled_rows)

        # build_loan_schedule_context's `term_months` genuinely means
        # months — it internally multiplies by 4/2/30 for WEEKLY/BIWEEKLY/
        # DAILY to get the period count. remaining_periods above is a count
        # of remaining installment ROWS, not months, so for anything other
        # than MONTHLY frequency those are different numbers. Convert back
        # to the equivalent month count so the periods (and interest, which
        # is calculated off term_months) come out right either way.
        periods_per_month = {"DAILY": 30, "WEEKLY": 4, "BIWEEKLY": 2}.get(loan.repayment_frequency, 1)
        remaining_term_months = Decimal(remaining_periods) / Decimal(periods_per_month)

        try:
            with transaction.atomic():
                # 1. Snapshot the full current state before touching anything.
                snapshot = LoanScheduleSnapshot.objects.create(
                    loan=loan,
                    created_by=request.user,
                    reason=reason,
                    old_schedule_rows=[serialize_schedule_row(r) for r in all_rows],
                    old_loan_fields=serialize_loan_snapshot_fields(loan),
                )

                # 2. Build the replacement schedule for ONLY the unsettled
                #    remainder — remaining principal, remaining period count.
                schedule_rows, totals, _, _, _ = build_loan_schedule_context(
                    principal=remaining_principal,
                    product=loan.product,
                    term_months=remaining_term_months,
                    frequency=loan.repayment_frequency,
                    start_date=parsed,
                    include_processing_fee=False,
                    interest_rate_monthly=loan.interest_rate_monthly,
                    interest_method=loan.interest_method,
                )

                # 3. Delete only the unsettled rows; settled rows are untouched.
                unsettled_ids = [r.pk for r in unsettled_rows]
                LoanSchedule.objects.filter(pk__in=unsettled_ids).delete()

                next_period = (max((r.period_number for r in settled_rows), default=0)) + 1
                new_rows = LoanSchedule.objects.bulk_create([
                    LoanSchedule(
                        loan=loan,
                        period_number=next_period + i,
                        due_date=row["due_date"],
                        opening_balance=row["opening_balance"],
                        principal_due=row["principal_due"],
                        interest_due=row["interest_due"],
                        total_payment=row["total_payment"],
                        closing_balance=row["closing_balance"],
                    )
                    for i, row in enumerate(schedule_rows)
                ])
                snapshot.new_row_ids = [r.pk for r in new_rows]
                snapshot.save(update_fields=["new_row_ids"])

                # 4. Recompute loan totals from the FULL current row set
                #    (preserved settled rows + freshly regenerated ones) —
                #    never from outstanding_balance, which already includes
                #    interest and would compound it further.
                final_rows = settled_rows + list(new_rows)
                loan.total_repayable = sum((r.total_payment for r in final_rows), Decimal("0"))
                loan.total_interest = sum((r.interest_due for r in final_rows), Decimal("0"))
                loan.outstanding_balance = sum(
                    (max(r.total_payment - r.amount_paid, Decimal("0")) for r in final_rows),
                    Decimal("0"),
                )
                loan.first_repayment_date = min(r.due_date for r in final_rows)
                loan.maturity_date = max(r.due_date for r in final_rows)

                # Only rewrite disbursement_date if nothing has been paid
                # yet — once real payments exist against the original
                # date, that date is a historical fact and shouldn't move;
                # `parsed` in that case just becomes the resume date for
                # the newly-regenerated remaining periods.
                old_disbursement_date = loan.disbursement_date
                if not settled_rows:
                    loan.disbursement_date = parsed
                loan.save()

                if old_disbursement_date != loan.disbursement_date or reason:
                    LoanDisbursementAudit.objects.create(
                        loan=loan,
                        changed_by=request.user,
                        old_disbursement_date=old_disbursement_date,
                        new_disbursement_date=loan.disbursement_date,
                        action="regenerate",
                        reason=reason,
                    )

            messages.success(request, "Schedule regenerated. You can undo this from the schedule card if needed.")

        except Exception:
            import logging
            logging.exception("Failed to regenerate schedule for loan %s", loan.pk)
            messages.error(request, "Failed to regenerate schedule. See logs.")
            return redirect("loans:detail", pk=loan.pk)

        schedule = loan.schedule.order_by("period_number")
        return render(request, "loans/loan_detail_schedule_fragment.html", {
            "loan": loan,
            "schedule": schedule,
            "user": request.user,
            "can_undo_regenerate": _can_undo_regenerate(loan),
        })


@_require_role("CEO")
@require_POST
def loan_undo_regenerate_schedule(request, pk):
    """
    Reverts the most recent Regenerate Schedule action on this loan, using
    the LoanScheduleSnapshot it created. Refuses if a payment has since
    been recorded against any of the rows the regeneration created, since
    undoing would silently lose that payment's schedule linkage — the user
    is told exactly why and nothing is changed in that case.
    """
    loan = get_object_or_404(Loan, pk=pk)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("loans:list")

    snapshot = loan.schedule_snapshots.filter(is_undone=False).order_by("-created_at").first()
    if not snapshot:
        messages.info(request, "There's no schedule regeneration to undo for this loan.")
        return redirect("loans:detail", pk=loan.pk)

    new_rows = list(LoanSchedule.objects.filter(pk__in=snapshot.new_row_ids))
    if any(r.amount_paid > 0 or r.status not in (LoanSchedule.Status.PENDING, LoanSchedule.Status.OVERDUE) for r in new_rows):
        messages.error(
            request,
            "A payment has already been recorded against the regenerated schedule, "
            "so this can no longer be undone safely.",
        )
        return redirect("loans:detail", pk=loan.pk)

    try:
        with transaction.atomic():
            LoanSchedule.objects.filter(pk__in=snapshot.new_row_ids).delete()
            LoanSchedule.objects.bulk_create([
                deserialize_schedule_row(loan, row) for row in snapshot.old_schedule_rows
            ])
            restore_loan_snapshot_fields(loan, snapshot.old_loan_fields)
            loan.save()

            snapshot.is_undone = True
            snapshot.undone_by = request.user
            snapshot.undone_at = timezone.now()
            snapshot.save(update_fields=["is_undone", "undone_by", "undone_at"])

            LoanDisbursementAudit.objects.create(
                loan=loan,
                changed_by=request.user,
                old_disbursement_date=loan.disbursement_date,
                new_disbursement_date=loan.disbursement_date,
                action="regenerate",
                reason=f"Undo of regeneration from {snapshot.created_at:%Y-%m-%d %H:%M}",
            )

        messages.success(request, "Schedule regeneration undone — restored to how it was before.")
    except Exception:
        import logging
        logging.exception("Failed to undo schedule regeneration for loan %s", loan.pk)
        messages.error(request, "Failed to undo. See logs.")
        return redirect("loans:detail", pk=loan.pk)

    schedule = loan.schedule.order_by("period_number")
    return render(request, "loans/loan_detail_schedule_fragment.html", {
        "loan": loan,
        "schedule": schedule,
        "user": request.user,
        "can_undo_regenerate": _can_undo_regenerate(loan),
    })

# ------------------------------------------------------------------ #
# Loan renewal / roll-over                                              #
# ------------------------------------------------------------------ #

@_permission_required("can_approve_loans")
def loan_renew(request, pk):
    loan = get_object_or_404(
        Loan.objects.select_related("client", "product"),
        pk=pk,
        status=Loan.Status.ACTIVE,
    )

    if not loan.product.allows_renewal:
        messages.error(request, "This loan product does not allow renewal.")
        return redirect("loans:detail", pk=loan.pk)

    if loan.outstanding_balance <= Decimal("0"):
        messages.error(request, "This loan has no outstanding balance to renew.")
        return redirect("loans:detail", pk=loan.pk)

    products = LoanProduct.objects.filter(is_active=True).order_by("name")
    can_override_loan_fees = request.user.can("can_override_loan_fees")
    selected_product = loan.product
    processing_fee_enabled = loan.processing_fee_enabled

    if request.method == "POST":
        try:
            product_id = int(request.POST.get("product", loan.product_id) or loan.product_id)
            product = get_object_or_404(products, pk=product_id)
            selected_product = product
            term_months = int(request.POST.get("term_months", loan.term_months) or loan.term_months)
            frequency = request.POST.get("frequency", loan.repayment_frequency)
            additional_amount = Decimal(request.POST.get("additional_amount", "0") or "0")
            reason = request.POST.get("reason", "").strip()
            existing_loan = loan if product.pk == loan.product_id else None
            interest_method = _resolve_loan_interest_method(
                product,
                request.POST,
                existing_loan,
                can_change=request.user.can("can_change_loan_interest_method"),
            )
            processing_fee_enabled, penalty_enabled = _resolve_loan_fee_switches(
                product,
                request.POST,
                can_override_loan_fees,
                existing_loan,
            )
            penalty_frequency = CompanySettings.get().penalty_frequency

            if not reason:
                raise ValueError("Renewal reason is required.")

            if additional_amount < Decimal("0"):
                raise ValueError("Additional amount cannot be negative.")

            if term_months < product.min_term_months or term_months > product.max_term_months:
                raise ValueError(
                    f"Term must be between {product.min_term_months} and {product.max_term_months} months."
                )

            if frequency not in dict(Loan.RepaymentFrequency.choices):
                raise ValueError("Invalid repayment frequency selected.")

            outstanding_amount = loan.outstanding_balance
            if outstanding_amount <= Decimal("0"):
                raise ValueError("Loan has no outstanding balance to renew.")

            total_new_principal = outstanding_amount + additional_amount
            if total_new_principal <= Decimal("0"):
                raise ValueError("Total new principal must be greater than zero.")
            if total_new_principal < product.min_amount or total_new_principal > product.max_amount:
                raise ValueError(
                    f"New principal must be between UGX {product.min_amount:,.0f} "
                    f"and UGX {product.max_amount:,.0f} for {product.name}."
                )

            # Allow optional disbursement_date from the form (CEOs may back-date)
            provided_disb = request.POST.get('disbursement_date', '').strip()
            if provided_disb:
                try:
                    chosen_disbursement = date.fromisoformat(provided_disb)
                except Exception:
                    raise ValueError("Invalid disbursement date format. Use YYYY-MM-DD.")
                if chosen_disbursement < date.today() and not request.user.can("can_backdate_transactions"):
                    raise ValueError("Only users with back-dating permission may set a past disbursement date.")
            else:
                chosen_disbursement = date.today()

            limit_error = _disbursement_limit_error(request.user, additional_amount, chosen_disbursement)
            if limit_error:
                raise ValueError(limit_error)

            schedule_rows, totals, processing_fee, _, _ = build_loan_schedule_context(
                principal=total_new_principal,
                product=product,
                term_months=term_months,
                frequency=frequency,
                start_date=chosen_disbursement,
                include_processing_fee=processing_fee_enabled,
                interest_method=interest_method,
            )
            fee_percent = resolve_processing_fee_rate(
                product,
                allow_disabled_product_fee=processing_fee_enabled,
            )

            with transaction.atomic():
                new_loan = Loan.objects.create(
                    client=loan.client,
                    product=product,
                    branch=loan.branch,
                    applied_by=request.user,
                    reviewed_by=request.user,
                    disbursed_by=request.user if additional_amount > 0 else None,
                    application_date=date.today(),
                    approval_date=date.today(),
                    disbursement_date=chosen_disbursement,
                    first_repayment_date=schedule_rows[0]["due_date"],
                    maturity_date=schedule_rows[-1]["due_date"],
                    principal_amount=total_new_principal,
                    interest_rate_monthly=product.interest_rate_monthly,
                    interest_method=interest_method,
                    penalty_enabled=penalty_enabled,
                    penalty_frequency=penalty_frequency,
                    penalty_rate_monthly=(
                        product.penalty_rate_monthly if penalty_enabled else Decimal("0")
                    ),
                    processing_fee_enabled=processing_fee_enabled,
                    processing_fee_manually_set=not processing_fee_enabled,
                    processing_fee_percent=fee_percent if fee_percent else None,
                    term_months=term_months,
                    repayment_frequency=frequency,
                    total_repayable=totals["total_repayable_exclusive"],
                    total_interest=totals["total_interest"],
                    outstanding_balance=totals["total_repayable_exclusive"],
                    total_fees=processing_fee,
                    processing_fee=processing_fee,
                    purpose=f"Renewal of {loan.loan_number}. {reason}",
                    status=Loan.Status.ACTIVE,
                    is_renewal=True,
                    renewal_count=loan.renewal_count + 1,
                    renewed_from=loan,
                )

                LoanSchedule.objects.bulk_create([
                    LoanSchedule(
                        loan=new_loan,
                        period_number=row["period_number"],
                        due_date=row["due_date"],
                        opening_balance=row["opening_balance"],
                        principal_due=row["principal_due"],
                        interest_due=row["interest_due"],
                        total_payment=row["total_payment"],
                        closing_balance=row["closing_balance"],
                    )
                    for row in schedule_rows
                ])

                try:
                    with transaction.atomic():
                        LoanDisbursementAudit.objects.create(
                            loan=new_loan,
                            changed_by=request.user,
                            old_disbursement_date=None,
                            new_disbursement_date=new_loan.disbursement_date,
                            action="renew",
                            reason=reason[:2000],
                        )
                except Exception:
                    import logging
                    logging.exception(
                        "Failed to create disbursement audit for new renewed loan %s",
                        new_loan.pk,
                    )

                LoanRenewal.objects.create(
                    original_loan=loan,
                    new_loan=new_loan,
                    outstanding_amount=outstanding_amount,
                    additional_amount=additional_amount,
                    total_new_principal=total_new_principal,
                    reason=reason,
                    approved_by=request.user,
                )

                loan.renewal_count += 1
                loan.status = Loan.Status.COMPLETED
                loan.completion_date = date.today()
                loan.save(update_fields=["renewal_count", "status", "completion_date"])

            messages.success(request, f"Loan renewed into new loan {new_loan.loan_number}.")
            # HTMX: return fragment instructing client to redirect/refresh
            if request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true':
                from django.urls import reverse
                return render(request, 'loans/htmx_success.html', {
                    'message': f'Loan renewed into new loan {new_loan.loan_number}.',
                    'redirect': '"' + reverse('loans:detail', kwargs={'pk': new_loan.pk}) + '"',
                })
            return redirect("loans:detail", pk=new_loan.pk)

        except Exception as e:
            messages.error(request, f"Renewal Error: {e}")

    action_mode = request.GET.get("action", "renew").lower()
    is_reschedule = action_mode == "reschedule"

    frequency_choices = Loan.RepaymentFrequency.choices
    context = {
        "loan": loan,
        "products": products,
        "selected_product": selected_product,
        "can_override_loan_fees": can_override_loan_fees,
        "processing_fee_enabled": processing_fee_enabled,
        "frequency_choices": frequency_choices,
        "default_term": request.POST.get("term_months", loan.term_months),
        "default_frequency": request.POST.get("frequency", loan.repayment_frequency),
        "default_additional_amount": request.POST.get("additional_amount", "0"),
        "default_reason": request.POST.get("reason", ""),
        "default_disbursement_date": request.POST.get(
            "disbursement_date",
            (loan.disbursement_date or date.today()).isoformat(),
        ),
        "min_term": selected_product.min_term_months,
        "max_term": selected_product.max_term_months,
        "is_reschedule": is_reschedule,
        "action_title": "Reschedule Loan" if is_reschedule else "Renew Loan",
        "submit_label": "Create Rescheduled Loan" if is_reschedule else "Create Renewal Loan",
        "helper_text": (
            "This creates a new loan using the full outstanding balance as the new principal."
            if is_reschedule
            else "The current outstanding balance rolls into the new loan. Only the additional amount is disbursed as cash."
        ),
        "today": date.today(),
    }

    # If requested via HTMX, return only the form fragment suitable for modal
    if request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true':
        return render(request, 'loans/renew_loan_fragment.html', context)

    return render(request, "loans/renew_loan.html", context)


# ------------------------------------------------------------------ #
# Approve / Reject                                                     #
# ------------------------------------------------------------------ #

@_permission_required("can_approve_loans")
@require_POST
def loan_approve(request, pk):
    loan = get_object_or_404(Loan, pk=pk, status=Loan.Status.PENDING)
    user = request.user

    # Limit check: managers can only approve up to UGX 5,000,000
    from django.conf import settings as django_settings
    limit = Decimal(str(getattr(django_settings, "MANAGER_APPROVAL_LIMIT", 5_000_000)))
    if not user.can("can_approve_unlimited_loans") and loan.principal_amount > limit:
        messages.error(request, f"Loans above UGX {limit:,.0f} require CEO approval.")
        return redirect("loans:detail", pk=pk)

    # Default to today; allow CEOs to override via POST disbursement_date field.
    disbursement_date = date.today()
    loan.reviewed_by = user
    loan.approval_date = date.today()

    # If a disbursement_date was provided and user is CEO, validate and apply it
    provided = request.POST.get("disbursement_date", "").strip() if request.POST else ""
    if provided:
        if not user.can("can_backdate_transactions"):
            messages.error(request, "You do not have permission to set a custom disbursement date.")
            return redirect("loans:detail", pk=pk)
        try:
            parsed = date.fromisoformat(provided)
        except Exception:
            messages.error(request, "Invalid disbursement date format. Use YYYY-MM-DD.")
            return redirect("loans:detail", pk=pk)
        # CEOs are allowed to back-date disbursement; accept the provided date as-is
        disbursement_date = parsed

    limit_error = _disbursement_limit_error(user, loan.principal_amount, disbursement_date)
    if limit_error:
        messages.error(request, limit_error)
        return redirect("loans:detail", pk=pk)

    # Capture old disbursement date for auditing
    old_disb_date = loan.disbursement_date
    loan.disbursement_date = disbursement_date

    # Product business rule: some products require at least one guarantor.
    if loan.product.requires_guarantor and not loan.guarantees.filter(is_active=True).exists():
        messages.error(request, "This loan needs at least one active guarantor before this product can be approved.")
        return redirect("loans:detail", pk=pk)
    if loan.product.requires_collateral and not loan.collateral_items.exists():
        messages.error(request, "This loan needs at least one collateral item before this product can be approved.")
        return redirect("loans:detail", pk=pk)

    # Ensure a schedule exists (we can regenerate below when CEO changes disbursement date)
    if not loan.schedule.exists():
        messages.error(request, "Schedule not generated yet. Re-open the loan application to generate a schedule.")
        return redirect("loans:detail", pk=pk)

    # If the disbursement date is different from the schedule's start, regenerate schedule rows so due dates align
    try:
        from .utils import build_loan_schedule_context
        # Build schedule using outstanding principal snapshot (full principal at approval time)
        schedule_rows, totals, _, _, _ = build_loan_schedule_context(
            principal=loan.principal_amount,
            product=loan.product,
            term_months=loan.term_months,
            frequency=loan.repayment_frequency,
            start_date=disbursement_date,
            include_processing_fee=False,
            interest_rate_monthly=loan.interest_rate_monthly,
            interest_method=loan.interest_method,
        )

        # Replace existing schedule with new dates/payments
        LoanSchedule.objects.filter(loan=loan).delete()
        LoanSchedule.objects.bulk_create([
            LoanSchedule(
                loan=loan,
                period_number=row["period_number"],
                due_date=row["due_date"],
                opening_balance=row["opening_balance"],
                principal_due=row["principal_due"],
                interest_due=row["interest_due"],
                total_payment=row["total_payment"],
                closing_balance=row["closing_balance"],
            )
            for row in schedule_rows
        ])

        # Update loan totals/dates from regenerated schedule
        loan.first_repayment_date = schedule_rows[0]["due_date"]
        loan.maturity_date = schedule_rows[-1]["due_date"]
        loan.total_repayable = totals.get("total_repayable", loan.total_repayable)
        loan.total_interest = totals.get("total_interest", loan.total_interest)
        loan.outstanding_balance = loan.total_repayable

    except Exception as e:
        # If regeneration fails, fall back to using existing schedule dates
        import logging
        logging.exception("Failed to regenerate schedule on approval for loan %s: %s", loan.pk, e)
        loan.first_repayment_date = loan.schedule.order_by("period_number").first().due_date
        loan.maturity_date = loan.schedule.order_by("-period_number").first().due_date
        loan.outstanding_balance = loan.total_repayable

    # Immediately activate
    loan.status = Loan.Status.ACTIVE
    loan.disbursed_by = user
    loan.query_reason = ""
    loan.save()

    # Audit approval (including the disbursement date decision).
    try:
        LoanDisbursementAudit.objects.create(
            loan=loan,
            changed_by=request.user,
            old_disbursement_date=old_disb_date,
            new_disbursement_date=loan.disbursement_date,
            action='approve',
            reason='Approved and disbursed via approval form',
        )
    except Exception:
        import logging
        logging.exception('Failed to create disbursement audit for loan %s on approval', loan.pk)

    messages.success(request, f"Loan {loan.loan_number} approved and activated.")
    return redirect("loans:detail", pk=pk)


@_require_role("CEO")
def loan_write_off(request, pk):
    """Write off a loan that's uncollectable (e.g. long-defaulted, client untraceable).

    The model already had write_off_reason / write_off_approved_by fields
    and a WRITTEN_OFF status, but nothing ever set them — this is that
    missing action.

    Like loan_reschedule/loan_renew, this is a GET/POST hybrid: GET (or an
    HTMX GET) renders the confirmation form for the Loan Actions modal, POST
    performs the write-off. Only reachable once the loan is past the
    company's auto_write_off_days threshold (see loans.views.loan_detail's
    can_write_off) — enforced again here since this is also a directly
    postable URL.
    """
    loan = get_object_or_404(Loan.objects.select_related("client", "product"), pk=pk)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("loans:list")
    if loan.status not in (Loan.Status.ACTIVE, Loan.Status.RESTRUCTURED, Loan.Status.DEFAULTED):
        messages.error(request, "Only active, restructured, or defaulted loans can be written off.")
        return redirect("loans:detail", pk=pk)

    from accounts.models import CompanySettings
    write_off_threshold_days = getattr(CompanySettings.get(), "auto_write_off_days", 180)
    if loan.days_overdue < write_off_threshold_days:
        messages.error(
            request,
            f"This loan is only {loan.days_overdue} days overdue — it can't be written off until it passes "
            f"the {write_off_threshold_days}-day threshold configured in Company Settings.",
        )
        return redirect("loans:detail", pk=pk)

    is_htmx = request.headers.get('HX-Request') == 'true' or request.META.get('HTTP_HX_REQUEST') == 'true'

    if request.method == "POST":
        reason = request.POST.get("write_off_reason", "").strip()
        if not reason:
            messages.error(request, "A write-off reason is required.")
            return redirect("loans:detail", pk=pk)

        with transaction.atomic():
            loan.status = Loan.Status.WRITTEN_OFF
            loan.write_off_reason = reason
            loan.write_off_approved_by = request.user
            loan.outstanding_balance = Decimal("0")
            loan.save()

            # Remaining schedule entries are marked WAIVED so they stop showing
            # as due/overdue and stop generating collection reminders. Marked
            # waived_by_writeoff=True so a later reinstate() only reverts entries
            # this action touched — not any independent fee waiver.
            LoanSchedule.objects.filter(
                loan=loan,
                status__in=[LoanSchedule.Status.PENDING, LoanSchedule.Status.OVERDUE, LoanSchedule.Status.PARTIAL],
            ).update(status=LoanSchedule.Status.WAIVED, waived_by_writeoff=True)

        try:
            LoanDisbursementAudit.objects.create(
                loan=loan,
                changed_by=request.user,
                old_disbursement_date=loan.disbursement_date,
                new_disbursement_date=loan.disbursement_date,
                action="write_off",
                reason=reason,
            )
        except Exception:
            import logging
            logging.exception("Failed to create write-off audit for loan %s", loan.pk)

        messages.success(request, f"Loan {loan.loan_number} has been written off.")
        if is_htmx:
            from django.urls import reverse
            return render(request, 'loans/htmx_success.html', {
                'message': f'Loan {loan.loan_number} has been written off.',
                'redirect': '"' + reverse('loans:detail', kwargs={'pk': loan.pk}) + '"',
            })
        return redirect("loans:detail", pk=pk)

    # GET (or after a validation error above): render the confirmation form.
    context = {
        "loan": loan,
        "write_off_threshold_days": write_off_threshold_days,
    }
    return render(request, 'loans/write_off_fragment.html', context)


@_require_role("CEO")
@require_POST
def loan_reinstate(request, pk):
    """Reverse a write-off after a settlement/agreement with the client.

    Restores exactly the schedule entries the write-off waived (tracked via
    waived_by_writeoff — untouched fee waivers are left alone), recomputes
    the outstanding balance from what's actually still owed, and moves the
    loan back to ACTIVE. The original write-off reason/approver are kept as
    history; a reinstatement reason is required alongside them.
    """
    loan = get_object_or_404(Loan, pk=pk, status=Loan.Status.WRITTEN_OFF)
    if not can_access_branch_object(request.user, loan):
        messages.error(request, "That loan belongs to a different branch.")
        return redirect("loans:list")

    reason = request.POST.get("reinstatement_reason", "").strip()
    if not reason:
        messages.error(request, "A reinstatement reason is required.")
        return redirect("loans:detail", pk=pk)

    today = date.today()
    with transaction.atomic():
        restored = LoanSchedule.objects.filter(loan=loan, waived_by_writeoff=True)
        for entry in restored:
            entry.status = LoanSchedule.Status.OVERDUE if entry.due_date < today else LoanSchedule.Status.PENDING
            entry.waived_by_writeoff = False
            entry.save(update_fields=["status", "waived_by_writeoff"])

        loan.status = Loan.Status.ACTIVE
        loan.reinstated_at = timezone.now()
        loan.reinstated_by = request.user
        loan.reinstatement_reason = reason
        # Recompute outstanding balance from what's actually still owed
        # across the restored (and any never-waived) unpaid entries.
        loan.outstanding_balance = LoanSchedule.objects.filter(
            loan=loan,
        ).exclude(status=LoanSchedule.Status.PAID).exclude(status=LoanSchedule.Status.WAIVED).aggregate(
            total=Sum("total_payment")
        )["total"] or Decimal("0")
        # Subtract any partial payments already recorded against those entries
        already_paid = LoanSchedule.objects.filter(loan=loan).exclude(
            status=LoanSchedule.Status.PAID
        ).exclude(status=LoanSchedule.Status.WAIVED).aggregate(total=Sum("amount_paid"))["total"] or Decimal("0")
        loan.outstanding_balance = loan.outstanding_balance - already_paid
        loan.save()

    try:
        LoanDisbursementAudit.objects.create(
            loan=loan,
            changed_by=request.user,
            old_disbursement_date=loan.disbursement_date,
            new_disbursement_date=loan.disbursement_date,
            action="reinstate",
            reason=reason,
        )
    except Exception:
        import logging
        logging.exception("Failed to create reinstatement audit for loan %s", loan.pk)

    messages.success(request, f"Loan {loan.loan_number} has been reinstated and is active again.")
    return redirect("loans:detail", pk=pk)


@_permission_required("can_approve_loans")
@require_POST
def loan_query(request, pk):
    """Request more information and return the application to draft for editing."""
    loan = get_object_or_404(Loan, pk=pk, status=Loan.Status.PENDING)
    reason = request.POST.get("review_reason", "").strip()
    if not reason:
        messages.error(request, "A reason is required to query this loan.")
        return redirect("loans:detail", pk=pk)

    loan.status = Loan.Status.DRAFT
    loan.reviewed_by = request.user
    loan.query_reason = reason
    loan.save(update_fields=["status", "reviewed_by", "query_reason"])

    try:
        LoanDisbursementAudit.objects.create(
            loan=loan,
            changed_by=request.user,
            old_disbursement_date=loan.disbursement_date,
            new_disbursement_date=loan.disbursement_date,
            action="query",
            reason=reason,
        )
    except Exception:
        import logging
        logging.exception("Failed to create query audit for loan %s", loan.pk)

    messages.success(request, f"More information requested for loan {loan.loan_number}.")
    return redirect("loans:detail", pk=pk)


@_permission_required("can_approve_loans")
@require_POST
def loan_reject(request, pk):
    loan = get_object_or_404(Loan, pk=pk, status=Loan.Status.PENDING)
    reason = request.POST.get("review_reason", request.POST.get("rejection_reason", "")).strip()
    if not reason:
        messages.error(request, "A rejection reason is required.")
        return redirect("loans:detail", pk=pk)

    loan.status = Loan.Status.REJECTED
    loan.reviewed_by = request.user
    loan.rejection_reason = reason
    loan.query_reason = ""
    loan.save()

    try:
        LoanDisbursementAudit.objects.create(
            loan=loan,
            changed_by=request.user,
            old_disbursement_date=loan.disbursement_date,
            new_disbursement_date=loan.disbursement_date,
            action="reject",
            reason=reason,
        )
    except Exception:
        import logging
        logging.exception("Failed to create rejection audit for loan %s", loan.pk)

    messages.success(request, f"Loan {loan.loan_number} rejected.")
    return redirect("loans:detail", pk=pk)


@_require_role("CEO")
@require_POST
def loan_draft_delete(request, pk):
    """Permanently delete a DRAFT loan application."""
    loan = get_object_or_404(Loan, pk=pk, status=Loan.Status.DRAFT)
    ref = loan.loan_number
    loan.delete()
    messages.success(request, f"Draft {ref} deleted.")
    return redirect("loans:list")


@_require_role("CEO")
@require_POST
def loan_recall(request, loan_id):
    """Pull a rejected/draft loan back into edit mode."""
    loan = get_object_or_404(Loan, pk=loan_id)
    if loan.status not in (Loan.Status.DRAFT, Loan.Status.REJECTED):
        messages.error(request, "Only draft or rejected applications can be recalled for editing.")
        return redirect("loans:detail", pk=loan.pk)
    loan.status = Loan.Status.DRAFT
    loan.rejection_reason = ""
    loan.query_reason = ""
    loan.save()
    messages.success(request, "Application recalled — you may now edit and resubmit the draft.")
    url = reverse("loans:apply_step2", kwargs={"client_id": loan.client.pk}) + f"?draft_id={loan.pk}"
    return redirect(url)


@login_required
def loan_schedule_print(request, pk):
    """Render a clean, print-ready schedule page (opens in new tab)."""
    loan = get_object_or_404(
        Loan.objects.select_related("client", "product", "applied_by", "reviewed_by"),
        pk=pk,
    )
    schedule = loan.schedule.select_related("paid_by_payment").order_by("period_number")
    from accounts.models import CompanySettings
    chosen_signatory = request.user if request.user.signature else None
    company_settings = CompanySettings.get()
    collateral_items = loan.collateral_items.all()
    guarantees = loan.guarantees.select_related("guarantor").all()
    return render(request, "loans/schedule_print.html", {
        "loan": loan,
        "schedule": schedule,
        "company_accounts": BankAccount.objects.filter(
            is_active=True,
            account_type__in=(
                BankAccount.AccountType.CURRENT,
                BankAccount.AccountType.SAVINGS,
                BankAccount.AccountType.MOBILE,
            ),
        ).order_by("account_type", "bank_name"),
        "total_cost_of_credit": loan.total_interest + loan.processing_fee,
        "company_settings": company_settings,
        "loan_terms_html": sanitize_loan_terms(company_settings.loan_terms_and_conditions),
        "collateral_items": collateral_items,
        "guarantees": guarantees,
        "selected_signatory": chosen_signatory,
    })


@login_required
def loan_schedule_download(request, pk):
    """Download the repayment schedule as a PDF."""
    from django.http import HttpResponse
    from common.pdf_utils import generate_loan_schedule_pdf

    loan = get_object_or_404(Loan.objects.select_related("branch"), pk=pk)
    chosen_signatory = request.user if request.user.signature else None
    from accounts.models import CompanySettings
    pdf_bytes = generate_loan_schedule_pdf(
        loan,
        signatory=chosen_signatory,
        loan_terms=sanitize_loan_terms(CompanySettings.get().loan_terms_and_conditions),
    )
    response = HttpResponse(pdf_bytes, content_type="application/pdf")
    response["Content-Disposition"] = (
        f'attachment; filename="Schedule-{loan.loan_number}.pdf"'
    )
    return response


@login_required
def schedule_preview_pdf(request, client_id):
    """
    Render the current application-stage loan schedule as a printable PDF.
    Step 2 supplies unsaved form values; later stages can rely on the saved
    draft values.
    """
    from django.http import HttpResponse, HttpResponseBadRequest

    from .utils import generate_schedule_preview_pdf

    client = get_object_or_404(Client, pk=client_id, is_active=True, is_blacklisted=False)

    try:
        draft = _get_schedule_preview_draft(request.GET, client_id=client.pk)
        product_id = int(request.GET.get("product") or (draft.product_id if draft else 0))
        principal_value = request.GET.get("principal") or (
            draft.principal_amount if draft else "0"
        )
        principal = Decimal(str(principal_value))
        term_months = int(
            request.GET.get("term_months") or (draft.term_months if draft else 0)
        )
        frequency = request.GET.get("frequency") or (
            draft.repayment_frequency if draft else Loan.RepaymentFrequency.MONTHLY
        )

        if (
            product_id <= 0
            or principal <= 0
            or term_months < 1
            or term_months > 60
            or frequency not in dict(Loan.RepaymentFrequency.choices)
        ):
            return HttpResponseBadRequest(
                "Select a product and valid repayment frequency, amount, and term before printing the schedule."
            )
        product = get_object_or_404(LoanProduct, pk=product_id, is_active=True)
        can_change_interest_method = request.user.can("can_change_loan_interest_method")
        interest_method = _resolve_loan_interest_method(
            product,
            request.GET,
            draft,
            can_change=can_change_interest_method,
        )
        if interest_method not in dict(LoanProduct.InterestMethod.choices):
            return HttpResponseBadRequest("Select a valid interest method.")

        if principal <= 0 or term_months <= 0:
            return HttpResponseBadRequest(
                "Select a product and enter a valid loan amount and term before printing the schedule."
            )

        # Mirror the calculation used to render the on-screen preview in
        # loan_apply_step2 so the PDF always matches what the user sees.
        fee_enabled, _penalty_enabled = _resolve_loan_fee_switches(
            product,
            request.GET,
            request.user.can("can_override_loan_fees"),
            draft,
        )
        schedule_rows, totals, fee_amount, _, fee_source = build_loan_schedule_context(
            principal=principal,
            product=product,
            term_months=term_months,
            frequency=frequency,
            start_date=date.today(),
            include_processing_fee=fee_enabled,
            interest_method=interest_method,
            allow_disabled_product_fee=fee_enabled,
        )

        pdf_bytes = generate_schedule_preview_pdf(
            client=client,
            product=product,
            principal=principal,
            term_months=term_months,
            frequency=frequency,
            schedule_rows=schedule_rows,
            totals=totals,
            processing_fee=fee_amount,
            fee_source=fee_source,
            interest_method_label=dict(LoanProduct.InterestMethod.choices)[interest_method],
        )
    except (InvalidOperation, ValueError, TypeError):
        return HttpResponseBadRequest(
            "Enter valid loan details above before printing the schedule."
        )

    response = HttpResponse(pdf_bytes, content_type="application/pdf")
    response["Content-Disposition"] = f'inline; filename="Schedule-Preview-{client.client_number}.pdf"'
    return response


# ------------------------------------------------------------------ #
# HTMX: live schedule preview                                          #
# ------------------------------------------------------------------ #

@login_required
def schedule_preview(request):
    """
    Called via HTMX when the user changes loan parameters.
    Returns only the schedule table partial.
    """
    try:
        product_id  = int(request.GET.get("product") or 0)
        principal   = Decimal(str(request.GET.get("principal", "0") or "0"))
        term_months = int(request.GET.get("term_months", 1) or 1)
        frequency   = request.GET.get("frequency", "MONTHLY")
    except (InvalidOperation, TypeError, ValueError):
        return render(request, "partials/schedule_table.html", {
            "schedule_rows": [],
            "error": "Enter a valid loan amount and term to preview the schedule.",
        })

    if product_id <= 0 or principal <= 0 or term_months < 1 or term_months > 60:
        return render(request, "partials/schedule_table.html", {
            "schedule_rows": [],
            "error": "Select a product and enter a positive loan amount and term to preview the schedule.",
        })
    if frequency not in dict(Loan.RepaymentFrequency.choices):
        return render(request, "partials/schedule_table.html", {
            "schedule_rows": [],
            "error": "Select a valid repayment frequency to preview the schedule.",
        })

    product = LoanProduct.objects.filter(pk=product_id, is_active=True).first()
    if product is None:
        return render(request, "partials/schedule_table.html", {
            "schedule_rows": [],
            "error": "Select an active loan product to preview the schedule.",
        })

    try:
        draft = _get_schedule_preview_draft(request.GET)
        interest_method = _resolve_loan_interest_method(
            product,
            request.GET,
            draft,
            can_change=request.user.can("can_change_loan_interest_method"),
        )
        if interest_method not in dict(LoanProduct.InterestMethod.choices):
            raise ValueError("Select a valid interest method to preview the schedule.")
        processing_fee_enabled, _penalty_enabled = _resolve_loan_fee_switches(
            product,
            request.GET,
            request.user.can("can_override_loan_fees"),
            draft,
        )
        schedule_rows, totals = generate_schedule(
            principal   = principal,
            annual_rate = product.interest_rate_monthly * 12,
            term_months = term_months,
            start_date  = date.today(),
            method      = interest_method,
            frequency   = frequency,
        )
        processing_fee = None
        processing_fee_percent = None
        processing_fee_rate_text = None
        fee_source = None

        # Prefer tiered office charge if available
        if product:
            processing_fee = (
                calculate_processing_fee_amount(
                    principal,
                    product=product,
                    allow_disabled_product_fee=processing_fee_enabled,
                )
                if processing_fee_enabled else Decimal("0")
            )
            processing_fee_percent = (
                resolve_processing_fee_rate(
                    product,
                    allow_disabled_product_fee=processing_fee_enabled,
                )
                if processing_fee_enabled else Decimal("0")
            )
            fee_source = "Company settings (range)" if (processing_fee and not processing_fee_percent) else (product.name if processing_fee_percent else "Company settings")
            processing_fee_rate_text = f"{processing_fee_percent}%" if processing_fee_percent else ("Fixed range" if processing_fee else "")

        return render(request, "partials/schedule_table.html", {
            "schedule_rows": schedule_rows,
            "totals":        totals,
            "principal":     principal,
            "processing_fee": processing_fee,
            "processing_fee_percent": processing_fee_percent,
            "processing_fee_rate_text": processing_fee_rate_text,
            "fee_source": fee_source,
            "nominal_apr": product.interest_rate_monthly * Decimal("12"),
            "total_cost_of_credit": totals["total_interest"] + (processing_fee or Decimal("0")),
        })
    except (InvalidOperation, TypeError, ValueError):
        return render(request, "partials/schedule_table.html", {
            "schedule_rows": [],
            "error": "Could not calculate the schedule from these loan details. Review the selected terms and try again.",
        })


# ------------------------------------------------------------------ #
# Extend a schedule entry due date
# ------------------------------------------------------------------ #


@_require_role("MANAGER", "CEO")
@require_POST
def schedule_extend(request, pk):
    """
    POST endpoint to extend a LoanSchedule.due_date with a required reason.
    Expects `new_due_date` (YYYY-MM-DD) and `reason` in POST data.
    """
    try:
        entry = get_object_or_404(LoanSchedule, pk=pk)
        new_due = request.POST.get("new_due_date", "").strip()
        reason = request.POST.get("reason", "").strip()
        if not new_due or not reason:
            messages.error(request, "New due date and reason are required to extend a schedule entry.")
            return redirect("loans:detail", pk=entry.loan.pk)

        # parse date
        try:
            new_date = date.fromisoformat(new_due)
        except Exception:
            messages.error(request, "Invalid date format. Use YYYY-MM-DD.")
            return redirect("loans:detail", pk=entry.loan.pk)

        # record extension
        from .models import LoanScheduleExtension

        extension = LoanScheduleExtension.objects.create(
            schedule_entry = entry,
            old_due_date = entry.due_date,
            new_due_date = new_date,
            reason = reason,
            extended_by = request.user,
        )

        # apply change to schedule entry
        entry.due_date = new_date
        entry.save()

        messages.success(request, f"Schedule entry period {entry.period_number} extended to {new_date}.")
        return redirect("loans:detail", pk=entry.loan.pk)

    except Exception as e:
        messages.error(request, f"Could not extend schedule entry: {e}")
        return redirect("loans:detail", pk=entry.loan.pk)


# ------------------------------------------------------------------ #
# Loan products CRUD (CEO configuration)                             #
# ------------------------------------------------------------------ #


@login_required
def loan_product_list(request):
    """
    List loan products.
    CEO can manage them; other roles typically view active products.
    """
    qs = LoanProduct.objects.all().order_by("name")

    q = request.GET.get("q", "").strip()
    if q:
        qs = qs.filter(name__icontains=q)

    status = request.GET.get("status", "")
    if status == "active":
        qs = qs.filter(is_active=True)
    elif status == "inactive":
        qs = qs.filter(is_active=False)

    # Default for non-CEO users: show active only.
    if not request.user.can("can_view_all_loan_products") and not status:
        qs = qs.filter(is_active=True)

    return render(
        request,
        "loans/product_list.html",
        {
            "products": qs,
            "q": q,
            "status": status,
            "is_ceo": request.user.can("can_view_all_loan_products"),
            "penalty_frequency_label": CompanySettings.get().get_penalty_frequency_display(),
        },
    )


@_require_role("CEO")
def loan_product_create(request):
    form_error = ""
    product_form_defaults = {
        "requires_guarantor": False,
        "requires_collateral": False,
        "penalty_enabled": True,
        "processing_fee_enabled": True,
        "is_active": True,
        "interest_method": LoanProduct.InterestMethod.FLAT_RATE,
    }
    if request.method == "POST":
        d = request.POST
        product_form_defaults.update({
            "name": d.get("name", ""),
            "description": d.get("description", ""),
            "interest_rate_monthly": d.get("interest_rate_monthly", ""),
            "interest_method": d.get("interest_method", ""),
            "default_repayment_frequency": d.get("default_repayment_frequency", ""),
            "min_amount": d.get("min_amount", ""),
            "max_amount": d.get("max_amount", ""),
            "min_term_months": d.get("min_term_months", ""),
            "max_term_months": d.get("max_term_months", ""),
            "penalty_rate_monthly": d.get("penalty_rate_monthly", ""),
            "processing_fee_percent": d.get("processing_fee_percent", "0"),
            "penalty_enabled": d.get("penalty_enabled") == "on",
            "processing_fee_enabled": d.get("processing_fee_enabled") == "on",
            "requires_guarantor": d.get("requires_guarantor") == "on",
            "requires_collateral": d.get("requires_collateral") == "on",
            "is_active": d.get("is_active") == "on",
        })
        try:
            product = LoanProduct(
                name=d["name"].strip(),
                description=d.get("description", "").strip(),
                interest_rate_monthly=Decimal(d["interest_rate_monthly"]),
                interest_method=d["interest_method"],
                default_repayment_frequency=d["default_repayment_frequency"],
                min_amount=Decimal(d["min_amount"]),
                max_amount=Decimal(d["max_amount"]),
                min_term_months=int(d["min_term_months"]),
                max_term_months=int(d["max_term_months"]),
                penalty_rate_monthly=Decimal(d["penalty_rate_monthly"]),
                penalty_enabled=(d.get("penalty_enabled") == "on"),
                processing_fee_percent=Decimal(d.get("processing_fee_percent") or "0"),
                processing_fee_enabled=(d.get("processing_fee_enabled") == "on"),
                requires_guarantor=(d.get("requires_guarantor") == "on"),
                requires_collateral=(d.get("requires_collateral") == "on"),
                is_active=(d.get("is_active") == "on"),
                created_by=request.user,
            )

            product.full_clean()
            product.save()

            messages.success(request, f"Loan product '{product.name}' created.")
            if request.headers.get("HX-Request") == "true":
                response = HttpResponse(status=204)
                response["HX-Redirect"] = reverse("loans:products")
                return response
            return redirect("loans:products")
        except Exception as e:
            form_error = f"Could not create product: {e}"

    context = {
        "title": "Create Loan Product",
        "action": "create",
        "product": None,
        "product_form_defaults": product_form_defaults,
        "interest_method_choices": LoanProduct.InterestMethod.choices,
        "frequency_choices": LoanProduct.RepaymentFrequency.choices,
        "penalty_frequency_label": CompanySettings.get().get_penalty_frequency_display(),
        "form_error": form_error,
    }
    template = (
        "loans/product_form_modal.html"
        if request.headers.get("HX-Request") == "true"
        else "loans/product_form.html"
    )
    return render(request, template, context)


@_require_role("CEO")
def loan_product_edit(request, pk: int):
    product = get_object_or_404(LoanProduct, pk=pk)
    form_error = ""

    if request.method == "POST":
        d = request.POST
        try:
            product.name = d["name"].strip()
            product.description = d.get("description", "").strip()
            product.interest_rate_monthly = Decimal(d["interest_rate_monthly"])
            product.interest_method = d["interest_method"]
            product.default_repayment_frequency = d["default_repayment_frequency"]
            product.min_amount = Decimal(d["min_amount"])
            product.max_amount = Decimal(d["max_amount"])
            product.min_term_months = int(d["min_term_months"])
            product.max_term_months = int(d["max_term_months"])
            product.penalty_rate_monthly = Decimal(d["penalty_rate_monthly"])
            product.penalty_enabled = (d.get("penalty_enabled") == "on")
            product.processing_fee_percent = Decimal(d.get("processing_fee_percent") or "0")
            product.processing_fee_enabled = (d.get("processing_fee_enabled") == "on")
            product.requires_guarantor = (d.get("requires_guarantor") == "on")
            product.requires_collateral = (d.get("requires_collateral") == "on")
            product.is_active = (d.get("is_active") == "on")
            product.full_clean()
            product.save()

            messages.success(request, f"Loan product '{product.name}' updated.")
            if request.headers.get("HX-Request") == "true":
                response = HttpResponse(status=204)
                response["HX-Redirect"] = reverse("loans:products")
                return response
            return redirect("loans:products")
        except Exception as e:
            error_message = f"Could not update product: {e}"
            if request.headers.get("HX-Request") == "true":
                form_error = error_message
            else:
                messages.error(request, error_message)

    context = {
        "title": f"Edit Loan Product — {product.name}",
        "action": "edit",
        "product": product,
        "product_form_defaults": {
            "name": product.name,
            "description": product.description,
            "interest_rate_monthly": product.interest_rate_monthly,
            "interest_method": product.interest_method,
            "default_repayment_frequency": product.default_repayment_frequency,
            "min_amount": product.min_amount,
            "max_amount": product.max_amount,
            "min_term_months": product.min_term_months,
            "max_term_months": product.max_term_months,
            "penalty_rate_monthly": product.penalty_rate_monthly,
            "penalty_enabled": product.penalty_enabled,
            "processing_fee_percent": product.processing_fee_percent,
            "processing_fee_enabled": product.processing_fee_enabled,
            "requires_guarantor": product.requires_guarantor,
            "requires_collateral": product.requires_collateral,
            "is_active": product.is_active,
        },
        "interest_method_choices": LoanProduct.InterestMethod.choices,
        "frequency_choices": LoanProduct.RepaymentFrequency.choices,
        "penalty_frequency_label": CompanySettings.get().get_penalty_frequency_display(),
        "form_error": form_error,
    }
    template = (
        "loans/product_form_modal.html"
        if request.headers.get("HX-Request") == "true"
        else "loans/product_form.html"
    )
    return render(request, template, context)


@login_required
@require_POST
def guarantor_quick_create(request):
    """Save a guarantor entered on the loan form and return it for selection.

    Returns JSON {id, text, existing}. If a guarantor with the same NIN already
    exists, that record is returned instead of creating a duplicate.
    """
    from django.http import JsonResponse
    d = request.POST
    first_name = d.get("first_name", "").strip()
    last_name = d.get("last_name", "").strip()
    phone = d.get("phone_primary", "").strip()
    address = d.get("physical_address", "").strip()
    nin = d.get("nin", "").strip().upper()

    errors = []
    if not first_name:
        errors.append("First name is required.")
    if not last_name:
        errors.append("Last name is required.")
    if not phone:
        errors.append("Phone number is required.")
    if not address:
        errors.append("Physical address is required.")
    if errors:
        return JsonResponse({"error": " ".join(errors)}, status=400)

    if nin:
        existing = Guarantor.objects.filter(nin=nin).first()
        if existing:
            return JsonResponse({"id": existing.pk, "text": f"{existing.full_name} — {existing.phone_primary}", "existing": True})

    try:
        guarantor = Guarantor.objects.create(
            first_name=first_name,
            last_name=last_name,
            other_names=d.get("other_names", "").strip(),
            guarantor_type=Guarantor.Type.INDIVIDUAL,
            nin=nin,
            phone_primary=phone,
            phone_secondary=d.get("phone_secondary", "").strip(),
            physical_address=address,
            district=d.get("district", "").strip() or "Kampala",
            employer_name=d.get("employer_name", "").strip(),
            job_title=d.get("job_title", "").strip(),
            monthly_income=d.get("monthly_income") or "0",
            notes="Added from a loan application.",
        )
    except Exception as exc:
        return JsonResponse({"error": f"Could not save guarantor: {exc}"}, status=400)

    return JsonResponse({"id": guarantor.pk, "text": f"{guarantor.full_name} — {guarantor.phone_primary}", "existing": False})