"""
loans/utils.py
==============

Interest calculation methods:

  FLAT_RATE        – Interest = Principal × monthly_rate × term
                     This total interest is split equally across all periods.
                     Each period: same principal chunk + same interest chunk.
                     Common in Ugandan microfinance (simpler for clients to understand).

  REDUCING_BALANCE – Each period's interest = outstanding_balance × rate adjusted
                     for the selected repayment frequency. Principal portion
                     increases as balance drops.
                     True amortisation — total interest is lower than flat rate.

  COMPOUND         – Annuity repayments using an effective compounded rate for
                     the selected repayment frequency.

  INTEREST_ONLY    – Periodic interest payments with principal due in the final
                     installment.

Usage
-----
    from loans.utils import generate_schedule

    schedule, totals = generate_schedule(
        principal=Decimal("2000000"),
        annual_rate=Decimal("60"),       # 60% per year = 5% per month
        term_months=6,
        start_date=date(2024, 1, 15),
        method="FLAT",
        frequency="MONTHLY",
    )
    # schedule  → list of dicts, one per period
    # totals    → dict with total_repayable, total_interest, effective_apr
"""

from decimal import Decimal, ROUND_HALF_UP
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta


# ------------------------------------------------------------------ #
# Helpers                                                              #
# ------------------------------------------------------------------ #

def _round(amount: Decimal, decimal_places: int = 2) -> Decimal:
    """Round using financial half-up rounding at the requested precision."""
    return amount.quantize(Decimal("1").scaleb(-decimal_places), rounding=ROUND_HALF_UP)


def _next_due_date(current: date, frequency: str, period: int) -> date:
    """
    Calculate the due date for a given period.
    Period 1 = first payment after start_date.
    """
    if frequency == "DAILY":
        return current + timedelta(days=period)
    elif frequency == "WEEKLY":
        return current + timedelta(weeks=period)
    elif frequency == "BIWEEKLY":
        return current + timedelta(weeks=period * 2)
    else:  # MONTHLY
        return current + relativedelta(months=period)


def _periods_for_term(term_months, frequency: str) -> int:
    """Convert a term in months to number of repayment periods.

    Accepts either an int or a Decimal for term_months (regenerate-schedule
    passes a Decimal for the remaining fractional-month term) and always
    returns a plain int, since callers use this directly as a range()
    bound.
    """
    if frequency == "DAILY":
        result = term_months * 30         # approx 30 days per month
    elif frequency == "WEEKLY":
        result = term_months * 4          # approx 4 weeks per month
    elif frequency == "BIWEEKLY":
        result = term_months * 2
    else:
        result = term_months
    return int(round(result))


# ------------------------------------------------------------------ #
# Main calculator                                                      #
# ------------------------------------------------------------------ #

def _parse_processing_fee_range_amount(principal: Decimal, ranges_text: str) -> Decimal:
    """Parse company-configured processing fee ranges and return the matching amount."""
    principal = Decimal(str(principal or "0"))
    if principal <= 0:
        return Decimal("0")

    for line in (ranges_text or "").splitlines():
        line = line.strip()
        if not line or ":" not in line:
            continue

        range_part, amount_part = line.split(":", 1)
        range_part = range_part.strip()
        amount_part = amount_part.strip()
        if not range_part or not amount_part:
            continue

        try:
            fee_amount = Decimal(amount_part)
        except Exception:
            continue

        if "-" in range_part:
            start_text, end_text = range_part.split("-", 1)
            start_text = start_text.strip()
            end_text = end_text.strip()

            min_amount = Decimal(start_text) if start_text else None
            max_amount = Decimal(end_text) if end_text else None

            if min_amount is not None and principal < min_amount:
                continue
            if max_amount is not None and principal > max_amount:
                continue
            return fee_amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    return Decimal("0")


def calculate_processing_fee_amount(
    principal,
    product=None,
    company_settings=None,
    allow_disabled_product_fee=False,
) -> Decimal:
    """Calculate the processing fee respecting CompanySettings.processing_fee_method.

    PERCENTAGE → default_processing_fee_percent (company) or product rate
    RANGE      → parse processing_fee_ranges text field
    """
    principal = Decimal(str(principal or "0"))
    if principal <= 0:
        return Decimal("0")
    if (
        product is not None
        and not getattr(product, "processing_fee_enabled", True)
        and not allow_disabled_product_fee
    ):
        return Decimal("0")

    if company_settings is None:
        try:
            from accounts.models import CompanySettings as SettingsModel
            company_settings = SettingsModel.get()
        except Exception:
            return Decimal("0")

    method = getattr(company_settings, "processing_fee_method", "PERCENTAGE") or "PERCENTAGE"

    if method == "RANGE":
        return _parse_processing_fee_range_amount(
            principal,
            getattr(company_settings, "processing_fee_ranges", "") or "",
        )

    rate = resolve_processing_fee_rate(
        product,
        company_settings,
        allow_disabled_product_fee=allow_disabled_product_fee,
    )
    return (principal * rate / Decimal("100")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def resolve_processing_fee_rate(
    product=None,
    company_settings=None,
    allow_disabled_product_fee=False,
) -> Decimal:
    """Return the processing fee percentage to use.

    Priority:
    1. Company settings default_processing_fee_percent (if set and method is PERCENTAGE)
    2. Product-level processing_fee_percent
    3. Zero
    """
    if (
        product is not None
        and not getattr(product, "processing_fee_enabled", True)
        and not allow_disabled_product_fee
    ):
        return Decimal("0")

    if company_settings is None:
        try:
            from accounts.models import CompanySettings as SettingsModel
            company_settings = SettingsModel.get()
        except Exception:
            company_settings = None

    # If company uses RANGE method, percentage rate is not applicable
    if company_settings and getattr(company_settings, "processing_fee_method", "PERCENTAGE") == "RANGE":
        return Decimal("0")

    company_rate = getattr(company_settings, "default_processing_fee_percent", None) if company_settings else None
    if company_rate and company_rate > Decimal("0"):
        return company_rate

    if product and getattr(product, "processing_fee_percent", None) not in (None, Decimal("0")):
        return product.processing_fee_percent

    return Decimal("0")




def _shift_past_holidays(d: date, holiday_dates: set) -> date:
    while d in holiday_dates:
        d = d + timedelta(days=1)
    return d


def _load_holiday_dates(schedule: list[dict]) -> set:
    """Expand the Holiday calendar (including recurring holidays) across
    every year touched by this schedule."""
    if not schedule:
        return set()
    from accounts.models import Holiday
    years = {row["due_date"].year for row in schedule}
    dates = set()
    for h in Holiday.objects.filter(is_active=True):
        if h.is_recurring:
            for y in years:
                try:
                    dates.add(h.date.replace(year=y))
                except ValueError:
                    pass  # e.g. a recurring Feb 29 holiday in a non-leap year
        else:
            dates.add(h.date)
    return dates


def generate_schedule(
    principal: Decimal,
    annual_rate: Decimal,
    term_months: int,
    start_date: date,
    method: str = "FLAT",
    frequency: str = "MONTHLY",
    company_settings=None,
    decimal_places: int = 2,
) -> tuple[list[dict], dict]:
    """
    Generate a full amortization schedule.

    Parameters
    ----------
    principal    : loan principal in UGX
    annual_rate  : annual interest rate as a percentage (e.g. 60 for 60%/year)
    term_months  : loan term in months
    start_date   : disbursement date (first due date is calculated from this)
    method       : "FLAT", "REDUCING", "COMPOUND", or "INTEREST_ONLY"
    frequency    : "DAILY", "WEEKLY", "BIWEEKLY", or "MONTHLY"
    decimal_places : Monetary rounding precision (defaults to 2).
    company_settings : CompanySettings instance (fetched lazily if omitted).
        When adjust_due_dates_for_holidays is on, due dates landing on a
        configured holiday are pushed to the next working day. This is a
        pure date shift after the schedule is built — it doesn't change
        the interest/principal math for any period.

    Returns
    -------
    (schedule, totals)

    schedule : list of dicts with keys:
        period_number, due_date, opening_balance,
        principal_due, interest_due, total_payment, closing_balance

    totals : dict with keys:
        total_repayable, total_interest, effective_apr
    """
    # Convert annual rate to monthly rate (decimal, not percentage)
    monthly_rate = (annual_rate / Decimal("100")) / Decimal("12")

    num_periods = _periods_for_term(term_months, frequency)

    if method == "FLAT":
        schedule, totals = _flat_rate_schedule(
            principal, monthly_rate, term_months, num_periods, start_date, frequency,
            decimal_places,
        )
    elif method == "COMPOUND":
        schedule, totals = _compound_schedule(
            principal, monthly_rate, term_months, num_periods, start_date, frequency,
            decimal_places,
        )
    elif method == "INTEREST_ONLY":
        schedule, totals = _interest_only_schedule(
            principal, monthly_rate, num_periods, start_date, frequency, decimal_places
        )
    else:  # REDUCING
        schedule, totals = _reducing_balance_schedule(
            principal, monthly_rate, term_months, num_periods, start_date, frequency,
            decimal_places,
        )

    if company_settings is None:
        try:
            from accounts.models import CompanySettings as SettingsModel
            company_settings = SettingsModel.get()
        except Exception:
            company_settings = None

    if company_settings is not None and getattr(company_settings, "adjust_due_dates_for_holidays", False):
        holiday_dates = _load_holiday_dates(schedule)
        if holiday_dates:
            for row in schedule:
                row["due_date"] = _shift_past_holidays(row["due_date"], holiday_dates)

    return schedule, totals


def build_loan_schedule_context(
    principal: Decimal,
    product,
    term_months: int,
    frequency: str,
    start_date: date | None = None,
    include_processing_fee: bool = True,
    company_settings=None,
    interest_rate_monthly: Decimal | None = None,
    interest_method: str | None = None,
    allow_disabled_product_fee: bool = False,
) -> tuple[list[dict], dict, Decimal, Decimal, str]:
    """Build a schedule and the fee/totals context used across the app.

    ``product`` is still used for amount/term limits, the processing-fee
    calculation, and its display name. But the *interest rate and method*
    used for the schedule come from ``interest_rate_monthly`` /
    ``interest_method`` when they're supplied — pass a loan's own
    snapshotted fields here for any post-application regeneration
    (approve, reschedule, regenerate) so an in-flight or active loan's
    schedule can't drift if the product is edited later. Leave them
    unset only while a loan is still DRAFT/PENDING and its terms are
    meant to track the currently-selected product.

    The processing fee is charged separately from the repayment schedule. The
    schedule totals therefore represent principal + interest only. """
    principal = Decimal(str(principal or "0"))
    start_date = start_date or date.today()

    if company_settings is None:
        try:
            from accounts.models import CompanySettings as SettingsModel
            company_settings = SettingsModel.get()
        except Exception:
            company_settings = None

    rate = interest_rate_monthly if interest_rate_monthly is not None else getattr(product, "interest_rate_monthly", "0")
    annual_rate = Decimal(str(rate or "0")) * Decimal("12")
    method = interest_method or getattr(product, "interest_method", "FLAT")

    schedule_rows, totals = generate_schedule(
        principal=principal,
        annual_rate=annual_rate,
        term_months=term_months,
        start_date=start_date,
        method=method,
        frequency=frequency,
        company_settings=company_settings,
    )

    if include_processing_fee:
        processing_fee = calculate_processing_fee_amount(
            principal,
            product=product,
            company_settings=company_settings,
            allow_disabled_product_fee=allow_disabled_product_fee,
        )
        fee_percent = resolve_processing_fee_rate(
            product,
            company_settings,
            allow_disabled_product_fee=allow_disabled_product_fee,
        )
        product_name = getattr(product, "name", "") or "Product"
        fee_source = (
            "Company settings (range)"
            if (processing_fee and not fee_percent)
            else (product_name if fee_percent else "Company settings")
        )
    else:
        processing_fee = Decimal("0")
        fee_percent = Decimal("0")
        fee_source = ""

    totals = dict(totals)
    totals["processing_fee"] = processing_fee
    totals["total_repayable_exclusive"] = totals.get("total_repayable", Decimal("0"))
    # Processing fee is charged separately; total repayable measures principal + interest only.
    totals["total_repayable_inclusive"] = totals["total_repayable_exclusive"]
    totals["grand_total"] = totals["total_repayable_inclusive"]
    return schedule_rows, totals, processing_fee, fee_percent, fee_source


def _flat_rate_schedule(
    principal, monthly_rate, term_months, num_periods, start_date, frequency,
    decimal_places=2,
):
    """
    Flat rate: total interest is fixed, split equally across all periods.
    Equal total payment every period (simple and predictable for clients).
    """
    total_interest   = _round(principal * monthly_rate * Decimal(str(term_months)), decimal_places)
    total_repayable  = _round(principal + total_interest, decimal_places)
    period_principal = _round(principal / Decimal(str(num_periods)), decimal_places)
    period_interest  = _round(total_interest / Decimal(str(num_periods)), decimal_places)
    period_payment   = _round(period_principal + period_interest, decimal_places)

    schedule           = []
    running_total_paid = Decimal("0")
    running_total_p    = Decimal("0")
    running_total_i    = Decimal("0")

    for i in range(1, num_periods + 1):
        due_date        = _next_due_date(start_date, frequency, i)
        # Opening balance = full amount owed at start of this period
        opening_balance = _round(total_repayable - running_total_paid, decimal_places)

        # Last period: absorb any rounding remainders
        if i == num_periods:
            p        = principal - running_total_p
            interest = total_interest - running_total_i
        else:
            p        = period_principal
            interest = period_interest

        p        = _round(p, decimal_places)
        interest = _round(interest, decimal_places)
        payment  = _round(p + interest, decimal_places)
        closing  = _round(opening_balance - payment, decimal_places)

        schedule.append({
            "period_number":   i,
            "due_date":        due_date,
            "opening_balance": opening_balance,
            "principal_due":   p,
            "interest_due":    interest,
            "total_payment":   payment,
            "closing_balance": max(closing, Decimal("0")),
        })

        running_total_paid += payment
        running_total_p    += p
        running_total_i    += interest

    total_repayable = _round(sum(row["total_payment"] for row in schedule), decimal_places)
    total_interest = _round(sum(row["interest_due"] for row in schedule), decimal_places)
    totals = {
        "total_repayable": total_repayable,
        "total_interest":  total_interest,
        "effective_apr":   _round(monthly_rate * Decimal("12") * Decimal("100")),
    }
    return schedule, totals


def _reducing_balance_schedule(
    principal, monthly_rate, term_months, num_periods, start_date, frequency,
    decimal_places=2,
):
    """
    Reducing balance: interest calculated on outstanding balance each period.
    Higher early interest, lower later. Total interest < flat rate equivalent.
    """
    # Calculate fixed period payment using annuity formula:
    # PMT = P × r / (1 - (1 + r)^-n)
    # where r = period rate, n = number of periods
    periods_per_month = {"DAILY": 30, "WEEKLY": 4, "BIWEEKLY": 2}.get(frequency, 1)
    period_rate = monthly_rate / Decimal(periods_per_month)

    if period_rate == 0:
        period_payment = _round(principal / Decimal(str(num_periods)), decimal_places)
    else:
        r   = period_rate
        n   = Decimal(str(num_periods))
        pmt = principal * r / (1 - (1 + r) ** (-n))
        period_payment = _round(pmt, decimal_places)

    schedule           = []
    balance            = principal
    total_interest     = Decimal("0")
    running_total_paid = Decimal("0")

    for i in range(1, num_periods + 1):
        due_date = _next_due_date(start_date, frequency, i)
        interest = _round(balance * period_rate, decimal_places)

        if i == num_periods:
            p       = balance
            payment = _round(p + interest, decimal_places)
        else:
            payment = period_payment
            p       = _round(payment - interest, decimal_places)

        p               = _round(p, decimal_places)
        opening_balance = _round(balance + interest, decimal_places)
        closing         = _round(opening_balance - payment, decimal_places)

        schedule.append({
            "period_number":   i,
            "due_date":        due_date,
            "opening_balance": opening_balance,
            "principal_due":   p,
            "interest_due":    interest,
            "total_payment":   payment,
            "closing_balance": max(closing, Decimal("0")),
        })

        balance            = max(_round(balance - p, decimal_places), Decimal("0"))
        total_interest    += interest
        running_total_paid += payment

    total_repayable = _round(running_total_paid, decimal_places)
    total_interest = _round(total_interest, decimal_places)

    totals = {
        "total_repayable": total_repayable,
        "total_interest":  total_interest,
        "effective_apr":   _round(monthly_rate * Decimal("12") * Decimal("100")),
    }
    return schedule, totals


def _compound_schedule(
    principal, monthly_rate, term_months, num_periods, start_date, frequency,
    decimal_places=2,
):
    """Build amortizing installments using an effective compounded period rate."""
    periods_per_month = {"DAILY": 30, "WEEKLY": 4, "BIWEEKLY": 2}.get(frequency, 1)
    period_rate = (Decimal("1") + monthly_rate) ** (
        Decimal("1") / Decimal(periods_per_month)
    ) - Decimal("1")

    if period_rate == 0:
        period_payment = _round(principal / Decimal(str(num_periods)), decimal_places)
    else:
        period_count = Decimal(str(num_periods))
        period_payment = _round(
            principal * period_rate / (Decimal("1") - (Decimal("1") + period_rate) ** (-period_count)),
            decimal_places,
        )

    schedule = []
    balance = principal
    total_interest = Decimal("0")
    for period in range(1, num_periods + 1):
        interest = _round(balance * period_rate, decimal_places)
        principal_due = balance if period == num_periods else _round(
            period_payment - interest, decimal_places
        )
        payment = _round(principal_due + interest, decimal_places)
        opening_balance = _round(balance + interest, decimal_places)
        balance = max(_round(balance - principal_due, decimal_places), Decimal("0"))

        schedule.append({
            "period_number": period,
            "due_date": _next_due_date(start_date, frequency, period),
            "opening_balance": opening_balance,
            "principal_due": principal_due,
            "interest_due": interest,
            "total_payment": payment,
            "closing_balance": balance,
        })
        total_interest += interest

    totals = {
        "total_repayable": _round(sum(row["total_payment"] for row in schedule), decimal_places),
        "total_interest": _round(total_interest, decimal_places),
        "effective_apr": _round(monthly_rate * Decimal("12") * Decimal("100")),
    }
    return schedule, totals


def _interest_only_schedule(
    principal, monthly_rate, num_periods, start_date, frequency, decimal_places=2
):
    """Collect interest each period and repay all principal in the final period."""
    periods_per_month = {"DAILY": 30, "WEEKLY": 4, "BIWEEKLY": 2}.get(frequency, 1)
    period_rate = monthly_rate / Decimal(periods_per_month)
    interest_per_period = _round(principal * period_rate, decimal_places)
    schedule = []

    for period in range(1, num_periods + 1):
        principal_due = principal if period == num_periods else Decimal("0")
        payment = _round(principal_due + interest_per_period, decimal_places)
        schedule.append({
            "period_number": period,
            "due_date": _next_due_date(start_date, frequency, period),
            "opening_balance": principal,
            "principal_due": principal_due,
            "interest_due": interest_per_period,
            "total_payment": payment,
            "closing_balance": max(
                _round(principal - principal_due, decimal_places), Decimal("0")
            ),
        })

    total_interest = _round(interest_per_period * num_periods, decimal_places)
    totals = {
        "total_repayable": _round(principal + total_interest, decimal_places),
        "total_interest": total_interest,
        "effective_apr": _round(monthly_rate * Decimal("12") * Decimal("100")),
    }
    return schedule, totals


# ------------------------------------------------------------------ #
# Eligibility calculator                                               #
# ------------------------------------------------------------------ #

def calculate_eligibility(client, product) -> dict:
    """
    Assess how much a client can borrow based on income and collateral.

    Rules
    -----
    * Income cap  : max loan = monthly_income × 3  (conservative microfinance ratio)
    * Product cap : capped further by product.max_amount
    * Minimum     : product.min_amount  OR  total declared collateral value (whichever is higher)
    * Risk flags  : active loans reduce the income cap by the outstanding balance

    Returns a dict with:
        income_based_max   – raw income × 3
        active_debt        – sum of outstanding balances on active loans
        net_eligible_max   – income_based_max − active_debt, capped by product
        product_min        – product.min_amount
        eligible           – True if net_eligible_max >= product.min_amount
        flags              – list of warning strings
    """
    from decimal import Decimal

    income = Decimal(str(client.monthly_income or 0))
    income_based_max = income * Decimal("3")

    # Sum outstanding balances on active loans
    active_loans = client.loans.filter(status__in=["ACTIVE", "APPROVED"])
    active_debt  = sum((l.outstanding_balance for l in active_loans), Decimal("0"))

    net_max = max(income_based_max - active_debt, Decimal("0"))
    net_max = min(net_max, product.max_amount)   # never exceed product ceiling

    flags = []
    if income == 0:
        flags.append("No income recorded — eligibility cannot be confirmed.")
    if active_debt > 0:
        flags.append(f"Client has UGX {active_debt:,.0f} outstanding on active loan(s).")
    if net_max < product.min_amount:
        flags.append(
            f"Net eligible amount (UGX {net_max:,.0f}) is below the product minimum "
            f"(UGX {product.min_amount:,.0f})."
        )

    return {
        "income_based_max": income_based_max,
        "active_debt":      active_debt,
        "net_eligible_max": net_max,
        "product_min":      product.min_amount,
        "eligible":         net_max >= product.min_amount,
        "flags":            flags,
    }


def collateral_minimum(collateral_items: list[dict]) -> Decimal:
    """
    Given a list of {description, estimated_value} dicts,
    return the total estimated collateral value.
    This is used as the floor for the minimum loan amount:
        min_borrow = max(product.min_amount, total_collateral_value × 0.5)
    The 50% haircut is standard microfinance practice.
    """
    total = sum(
        Decimal(str(item.get("estimated_value") or 0))
        for item in collateral_items
    )
    return _round(total * Decimal("0.5"))


def calculate_penalty(
    overdue_amount: Decimal,
    penalty_rate: Decimal,
    days_overdue: int,
    frequency: str = "MONTHLY",
    periods_already_assessed: int = 0,
) -> Decimal:
    """
    Calculate newly accrued penalty per overdue day or started 30-day period.
    """
    periods_overdue = penalty_periods_elapsed(days_overdue, frequency)
    new_periods = max(periods_overdue - periods_already_assessed, 0)
    rate = penalty_rate / Decimal("100")
    return _round(overdue_amount * rate * Decimal(str(new_periods)))


def penalty_periods_elapsed(days_overdue: int, frequency: str) -> int:
    """Count daily periods or started 30-day periods elapsed while overdue."""
    days_overdue = max(days_overdue, 0)
    if frequency == "DAILY":
        return days_overdue
    elif frequency == "MONTHLY":
        return (days_overdue + 29) // 30
    raise ValueError("Penalty frequency must be DAILY or MONTHLY.")


# ------------------------------------------------------------------ #
# PDF generation (schedule preview, pre-approval)                    #
# ------------------------------------------------------------------ #

FREQUENCY_LABELS = {
    "DAILY":    "Daily",
    "WEEKLY":   "Weekly",
    "BIWEEKLY": "Bi-Weekly",
    "MONTHLY":  "Monthly",
}


def generate_schedule_preview_pdf(
    client,
    product,
    principal: Decimal,
    term_months: int,
    frequency: str,
    schedule_rows: list,
    totals: dict,
    processing_fee=None,
    fee_source=None,
    interest_method_label=None,
) -> bytes:
    """
    Render an amortization schedule *preview* (not yet an approved/disbursed
    loan) as a PDF using reportlab. Used from the loan-application wizard so
    the client can be handed a printable schedule before the loan is saved.
    """
    import io
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import mm
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(
        buffer,
        pagesize=A4,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        title="Loan Schedule Preview",
    )

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("PreviewTitle", parent=styles["Title"], fontSize=16, spaceAfter=2)
    sub_style = ParagraphStyle(
        "PreviewSub", parent=styles["Normal"], fontSize=9, textColor=colors.HexColor("#666666")
    )

    elements = [
        Paragraph("Loan Repayment Schedule — Preview", title_style),
        Paragraph(
            "Indicative schedule based on the details entered. Figures are subject to change "
            "until the loan is approved and disbursed.",
            sub_style,
        ),
        Spacer(1, 10),
    ]

    freq_label = FREQUENCY_LABELS.get((frequency or "").upper(), (frequency or "").title())

    meta_rows = [
        ["Client:", getattr(client, "full_name", ""), "Client No.:", getattr(client, "client_number", "")],
        [
            "Product:", product.name, "Interest Method:",
            interest_method_label or product.get_interest_method_display(),
        ],
        ["Principal:", f"UGX {Decimal(principal):,.0f}", "Term:", f"{term_months} month(s)"],
        ["Frequency:", freq_label, "Monthly Rate:", f"{product.interest_rate_monthly}%"],
    ]
    if processing_fee is not None:
        meta_rows.append(
            ["Processing Fee:", f"UGX {Decimal(processing_fee):,.0f}", "Fee Source:", fee_source or "—"]
        )

    meta_table = Table(meta_rows, colWidths=[28 * mm, 60 * mm, 32 * mm, 50 * mm])
    meta_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    elements.append(meta_table)
    elements.append(Spacer(1, 14))

    header = ["#", "Due Date", "Opening Bal.", "Principal", "Interest", "Payment", "Closing Bal."]
    table_data = [header]
    for row in schedule_rows:
        table_data.append([
            str(row["period_number"]),
            row["due_date"].strftime("%d %b %Y"),
            f"{row['opening_balance']:,.0f}",
            f"{row['principal_due']:,.0f}",
            f"{row['interest_due']:,.0f}",
            f"{row['total_payment']:,.0f}",
            f"{row['closing_balance']:,.0f}",
        ])

    schedule_table = Table(
        table_data,
        colWidths=[10 * mm, 26 * mm, 28 * mm, 26 * mm, 24 * mm, 26 * mm, 28 * mm],
        repeatRows=1,
    )
    schedule_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2563eb")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ALIGN", (2, 1), (-1, -1), "RIGHT"),
        ("ALIGN", (0, 0), (1, -1), "CENTER"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f5f7fb")]),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elements.append(schedule_table)
    elements.append(Spacer(1, 12))

    total_interest = totals.get("total_interest", Decimal("0"))
    total_repayable = totals.get("total_repayable", Decimal("0"))
    fee_amount = processing_fee or Decimal("0")
    grand_total = Decimal(total_repayable) + Decimal(fee_amount)

    totals_rows = [
        ["Total Interest:", f"UGX {Decimal(total_interest):,.0f}"],
        ["Total Principal + Interest:", f"UGX {Decimal(total_repayable):,.0f}"],
    ]
    if processing_fee:
        totals_rows.append(["Processing Fee:", f"UGX {Decimal(fee_amount):,.0f}"])
        totals_rows.append(["Grand Total Repayable:", f"UGX {grand_total:,.0f}"])

    totals_table = Table(totals_rows, colWidths=[60 * mm, 40 * mm])
    totals_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]))
    elements.append(totals_table)

    doc.build(elements)
    pdf_bytes = buffer.getvalue()
    buffer.close()
    return pdf_bytes

# ------------------------------------------------------------------ #
# Regenerate-schedule snapshot / restore helpers                       #
# ------------------------------------------------------------------ #
#
# Used by loans.views.loan_regenerate_schedule / loan_undo_regenerate_schedule
# together with the LoanScheduleSnapshot model. Kept here rather than
# inline in the view so the exact shape of what gets saved/restored has
# one canonical definition.

_SCHEDULE_ROW_FIELDS = [
    "period_number", "due_date", "opening_balance", "principal_due",
    "interest_due", "penalty_due", "fee_due", "total_payment",
    "closing_balance", "amount_paid", "paid_date", "status",
    "waived_by_writeoff", "notes",
]

_LOAN_SNAPSHOT_FIELDS = [
    "disbursement_date", "first_repayment_date", "maturity_date",
    "total_repayable", "total_interest", "outstanding_balance",
]


def _to_jsonable(value):
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "isoformat"):  # date/datetime
        return value.isoformat()
    return value


def _from_jsonable(value, field_name):
    if value is None:
        return None
    if field_name in (
        "opening_balance", "principal_due", "interest_due", "penalty_due",
        "fee_due", "total_payment", "closing_balance", "amount_paid",
        "total_repayable", "total_interest", "outstanding_balance",
    ):
        return Decimal(str(value))
    if field_name in ("due_date", "paid_date", "disbursement_date",
                       "first_repayment_date", "maturity_date"):
        return date.fromisoformat(value)
    return value


def serialize_schedule_row(row):
    """LoanSchedule instance -> plain JSON-safe dict (includes paid_by_payment_id)."""
    data = {f: _to_jsonable(getattr(row, f)) for f in _SCHEDULE_ROW_FIELDS}
    data["paid_by_payment_id"] = row.paid_by_payment_id
    return data


def deserialize_schedule_row(loan, data):
    """Plain dict (as produced by serialize_schedule_row) -> unsaved LoanSchedule instance."""
    from loans.models import LoanSchedule
    kwargs = {f: _from_jsonable(data.get(f), f) for f in _SCHEDULE_ROW_FIELDS}
    kwargs["loan"] = loan
    kwargs["paid_by_payment_id"] = data.get("paid_by_payment_id")
    return LoanSchedule(**kwargs)


def serialize_loan_snapshot_fields(loan):
    """Loan instance -> plain JSON-safe dict of the fields a regenerate touches."""
    return {f: _to_jsonable(getattr(loan, f)) for f in _LOAN_SNAPSHOT_FIELDS}


def restore_loan_snapshot_fields(loan, data):
    """Apply a serialize_loan_snapshot_fields() dict back onto a loan instance (not saved)."""
    for f in _LOAN_SNAPSHOT_FIELDS:
        if f in data:
            setattr(loan, f, _from_jsonable(data[f], f))